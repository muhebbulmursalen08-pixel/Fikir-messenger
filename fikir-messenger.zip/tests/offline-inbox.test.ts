import { describe, expect, it } from "vitest";
import { getOfflineInboxMessageCount, getOfflineInboxSenderNames, hasOfflineInboxActivity } from "../lib/offline-inbox";

describe("offline inbox summary helpers", () => {
  const summary = {
    directMessages: [
      { senderName: "সাইফ", senderUsername: "saif" },
      { senderName: "", senderUsername: "farah" },
    ],
    groupMessages: [
      { senderName: "সাইফ", senderUsername: "saif" },
      { senderName: null, senderUsername: null },
    ],
    missedCalls: [{ id: 1 }],
  };

  it("counts direct and group messages together", () => {
    expect(getOfflineInboxMessageCount(summary)).toBe(4);
    expect(getOfflineInboxMessageCount(undefined)).toBe(0);
  });

  it("uses unique readable names with a safe fallback and maximum", () => {
    expect(getOfflineInboxSenderNames(summary)).toEqual(["সাইফ", "farah", "ফিকির ব্যবহারকারী"]);
    expect(getOfflineInboxSenderNames(summary, 2)).toEqual(["সাইফ", "farah"]);
  });

  it("detects either unread message activity or missed calls", () => {
    expect(hasOfflineInboxActivity(summary)).toBe(true);
    expect(hasOfflineInboxActivity({ directMessages: [], groupMessages: [], missedCalls: [{ id: 2 }] })).toBe(true);
    expect(hasOfflineInboxActivity({ directMessages: [], groupMessages: [], missedCalls: [] })).toBe(false);
  });
});
