import { RoomServiceClient } from "livekit-server-sdk";
import { describe, expect, it } from "vitest";

function toHttpUrl(websocketUrl: string) {
  return websocketUrl
    .replace(/^wss:/, "https:")
    .replace(/^ws:/, "http:")
    .replace(/\/+$/, "");
}

describe("LiveKit credentials", () => {
  it(
    "authenticates a lightweight active-room query without exposing server secrets",
    async () => {
      const websocketUrl = process.env.LIVEKIT_URL ?? "";
      const apiKey = process.env.LIVEKIT_API_KEY ?? "";
      const apiSecret = process.env.LIVEKIT_API_SECRET ?? "";

      expect(websocketUrl).toMatch(/^wss:\/\/.+\.livekit\.cloud$/);
      expect(apiKey).toMatch(/^API/);
      expect(apiSecret.length).toBeGreaterThan(20);

      const roomService = new RoomServiceClient(
        toHttpUrl(websocketUrl),
        apiKey,
        apiSecret,
      );
      const rooms = await roomService.listRooms();

      expect(Array.isArray(rooms)).toBe(true);
    },
    20_000,
  );
});
