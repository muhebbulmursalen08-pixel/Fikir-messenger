import { describe, expect, it } from "vitest";
import { getChatAttachmentFilename, getChatAttachmentMimeType } from "../lib/chat-attachment-saving";

describe("chat attachment saving helpers", () => {
  it("keeps a readable uploaded filename and removes its timestamp prefix", () => {
    expect(getChatAttachmentFilename("https://files.example/1710000000-meeting%20notes.pdf?token=one", "file")).toBe("meeting notes.pdf");
  });

  it("uses a stable fallback filename when an attachment URL has no filename", () => {
    expect(getChatAttachmentFilename("https://files.example/", "voice")).toBe("fikir-voice-message.m4a");
  });

  it("provides appropriate system-sharing mime types", () => {
    expect(getChatAttachmentMimeType("image")).toBe("image/jpeg");
    expect(getChatAttachmentMimeType("voice")).toBe("audio/m4a");
    expect(getChatAttachmentMimeType("file")).toBe("application/octet-stream");
  });
});
