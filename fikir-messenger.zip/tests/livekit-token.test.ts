import { decodeJwt } from "jose";
import { describe, expect, it } from "vitest";
import { getLiveKitRoomName, issueLiveKitCallToken } from "../server/livekit";

describe("LiveKit call tokens", () => {
  it("scopes a short-lived token to exactly one direct-call room", async () => {
    const result = await issueLiveKitCallToken(
      { id: 718, groupId: null },
      { id: 42, name: "Fikir User", username: "fikir.user", avatarUrl: null },
    );
    const claims = decodeJwt(result.token) as {
      exp?: number;
      video?: { room?: string; roomJoin?: boolean; canPublish?: boolean; canSubscribe?: boolean };
    };

    expect(result.roomName).toBe("fikir-direct-call-718");
    expect(getLiveKitRoomName({ id: 14, groupId: 5 })).toBe("fikir-group-call-14");
    expect(claims.video).toMatchObject({
      room: result.roomName,
      roomJoin: true,
      canPublish: true,
      canSubscribe: true,
    });
    expect((claims.exp ?? 0) - Math.floor(Date.now() / 1000)).toBeLessThanOrEqual(10 * 60);
  });
});
