import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const screenSource = readFileSync("app/(tabs)/index.tsx", "utf8");
const configSource = readFileSync("app.config.ts", "utf8");

describe("Fikir Messenger local-first features", () => {
  it("persists messages and provides edit, delete, and time-limited restore flows", () => {
    expect(screenSource).toContain("AsyncStorage.setItem");
    expect(screenSource).toContain("const undoWindowMs = 12_000");
    expect(screenSource).toContain("const deleteMessage");
    expect(screenSource).toContain("const restoreMessage");
    expect(screenSource).toContain("editedAt");
    expect(screenSource).toContain("status === \"seen\"");
  });

  it("supports local image, file, and voice-message actions", () => {
    expect(screenSource).toContain("launchImageLibraryAsync");
    expect(screenSource).toContain("launchCameraAsync");
    expect(screenSource).toContain("DocumentPicker.getDocumentAsync");
    expect(screenSource).toContain("MediaLibrary.saveToLibraryAsync");
    expect(screenSource).toContain("useAudioRecorder");
    expect(screenSource).toContain("sendVoice");
  });

  it("ships Bengali by default with Arabic, Urdu, Persian, and English translations", () => {
    expect(screenSource).toContain("bn: { chats: \"চ্যাট\"");
    expect(screenSource).toContain("ar: { chats: \"الدردشات\"");
    expect(screenSource).toContain("ur: { chats: \"چیٹس\"");
    expect(screenSource).toContain("fa: { chats: \"گفتگوها\"");
    expect(screenSource).toContain("en: { chats: \"Chats\"");
    expect(screenSource).toContain("const [language, setLanguage] = useState<Language>(\"bn\")");
  });

  it("declares the native permissions required for local media use", () => {
    expect(configSource).toContain("expo-image-picker");
    expect(configSource).toContain("expo-media-library");
    expect(configSource).toContain("microphonePermission");
  });
});
