import { describe, expect, it } from "vitest";

import { getDirectReceiptLabel, getGroupReceiptLabel, getPresenceLabel } from "../lib/chat-status";

describe("chat status helpers", () => {
  it("maps direct-message receipt states to Bengali labels", () => {
    expect(getDirectReceiptLabel("sent")).toBe("পাঠানো ✓");
    expect(getDirectReceiptLabel("delivered")).toBe("পৌঁছেছে ✓✓");
    expect(getDirectReceiptLabel("seen")).toBe("দেখেছে ✓✓");
  });

  it("summarizes a group seen receipt without exposing member identities", () => {
    expect(getGroupReceiptLabel({ seenCount: 2, recipientCount: 4 })).toBe("দেখেছে 2/4");
    expect(getGroupReceiptLabel(null)).toBe("পাঠানো হয়েছে");
  });

  it("distinguishes online from offline presence", () => {
    expect(getPresenceLabel({ online: true, lastSeenAt: null })).toBe("● অনলাইন");
    expect(getPresenceLabel({ online: false, lastSeenAt: null })).toBe("অফলাইন");
  });
});
