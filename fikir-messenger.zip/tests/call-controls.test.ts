import { describe, expect, it } from "vitest";

import { formatCallDuration, getAudioOutputLabel, getNextAudioOutput } from "../lib/call-controls";

describe("call control helpers", () => {
  it("formats short and hour-long call durations", () => {
    expect(formatCallDuration(0)).toBe("00:00");
    expect(formatCallDuration(65)).toBe("01:05");
    expect(formatCallDuration(3661)).toBe("01:01:01");
  });

  it("selects speaker first and then an available alternate Android route", () => {
    expect(getNextAudioOutput(null, ["speaker", "earpiece"], "android")).toBe("speaker");
    expect(getNextAudioOutput("speaker", ["speaker", "earpiece"], "android")).toBe("earpiece");
  });

  it("uses iOS-supported route names and reports Bengali labels", () => {
    expect(getNextAudioOutput(null, ["default", "force_speaker"], "ios")).toBe("force_speaker");
    expect(getNextAudioOutput("force_speaker", ["default", "force_speaker"], "ios")).toBe("default");
    expect(getAudioOutputLabel("bluetooth")).toBe("ব্লুটুথ");
  });

  it("does not offer a route when the requested alternate is unavailable", () => {
    expect(getNextAudioOutput("speaker", ["speaker"], "android")).toBeNull();
  });
});
