import { describe, expect, it } from "vitest";
import { formatUnreadBadgeCount, getUnreadConversationTotal } from "../lib/chat-unread-badge";

describe("chat unread badge helpers", () => {
  it("formats a compact Bengali unread count", () => {
    expect(formatUnreadBadgeCount(0)).toBe("");
    expect(formatUnreadBadgeCount(12)).toBe("১২");
    expect(formatUnreadBadgeCount(100)).toBe("৯৯+");
  });

  it("safely totals unread conversation counts", () => {
    expect(getUnreadConversationTotal([{ unreadCount: 2 }, { unreadCount: 4 }, { unreadCount: -2 }])).toBe(6);
    expect(getUnreadConversationTotal(undefined)).toBe(0);
  });
});
