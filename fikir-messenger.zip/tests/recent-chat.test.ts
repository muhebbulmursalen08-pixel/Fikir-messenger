import { describe, expect, it } from "vitest";
import { getRecentMessagePreview, matchesRecentConversationSearch } from "../lib/recent-chat";

describe("getRecentMessagePreview", () => {
  it("shows cleaned text content", () => {
    expect(getRecentMessagePreview({ body: "  আসসালামু\nআলাইকুম  ", kind: "text" })).toBe("আসসালামু আলাইকুম");
  });

  it("uses a Bengali attachment label when no text exists", () => {
    expect(getRecentMessagePreview({ body: "", kind: "voice" })).toBe("ভয়েস বার্তা পাঠিয়েছেন");
  });

  it("includes the sender name for group previews only when requested", () => {
    expect(getRecentMessagePreview({ body: "সভা শুরু", kind: "text", senderName: "রহিম", includeSender: true })).toBe("রহিম: সভা শুরু");
  });
});

describe("matchesRecentConversationSearch", () => {
  const conversation = { name: "রহিম উদ্দিন", username: "rahim", preview: "আগামীকাল দেখা হবে" };

  it("matches a name or username without case sensitivity", () => {
    expect(matchesRecentConversationSearch(conversation, "রহিম")).toBe(true);
    expect(matchesRecentConversationSearch(conversation, "RAHIM")).toBe(true);
  });

  it("matches last-message content and returns no match for unrelated text", () => {
    expect(matchesRecentConversationSearch(conversation, "দেখা")).toBe(true);
    expect(matchesRecentConversationSearch(conversation, "করিম")).toBe(false);
  });

  it("keeps every conversation visible for an empty search", () => {
    expect(matchesRecentConversationSearch(conversation, "   ")).toBe(true);
  });
});
