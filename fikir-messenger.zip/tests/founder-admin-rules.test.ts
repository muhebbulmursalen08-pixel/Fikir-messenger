import { describe, expect, it } from "vitest";

import { canFounderBanUser, hasFounderUpdateContent } from "../server/admin-rules";
import { parseFounderUpdateImages } from "../server/db";

describe("Founder update publishing rules", () => {
  it("accepts a long text, image-only, or link-only founder update", () => {
    expect(hasFounderUpdateContent("নতুন সংস্করণ প্রকাশিত হয়েছে 🎉", 0, null)).toBe(true);
    expect(hasFounderUpdateContent("", 1, null)).toBe(true);
    expect(hasFounderUpdateContent("   ", 0, "https://example.com/fikir-update")).toBe(true);
    expect(hasFounderUpdateContent("", 0, null, true)).toBe(true);
  });

  it("rejects an update that has no text, image, or link", () => {
    expect(hasFounderUpdateContent("   ", 0, null)).toBe(false);
    expect(hasFounderUpdateContent("", 0, "   ")).toBe(false);
  });

  it("recovers only valid stored image URL arrays", () => {
    expect(parseFounderUpdateImages('["https://cdn.example/f1.jpg", "https://cdn.example/f2.webp"]')).toEqual([
      "https://cdn.example/f1.jpg",
      "https://cdn.example/f2.webp",
    ]);
    expect(parseFounderUpdateImages("not-json")).toEqual([]);
    expect(parseFounderUpdateImages('["https://cdn.example/f1.jpg", 9]')).toEqual([]);
  });
});

describe("Founder ban protection rules", () => {
  it("allows a founder to ban an ordinary user only", () => {
    expect(canFounderBanUser({ actorId: 10, targetId: 42, targetRole: "user", targetEmail: "member@gmail.com" })).toBe(true);
  });

  it("prevents self-bans and bans of any recognized founder identity", () => {
    expect(canFounderBanUser({ actorId: 10, targetId: 10, targetRole: "founder", targetEmail: "muhebbulmursalenm@gmail.com" })).toBe(false);
    expect(canFounderBanUser({ actorId: 10, targetId: 88, targetRole: "founder", targetEmail: "other@example.com" })).toBe(false);
    expect(canFounderBanUser({ actorId: 10, targetId: 89, targetRole: "user", targetEmail: "MUHEBBULMURSALEN08@GMAIL.COM" })).toBe(false);
  });
});
