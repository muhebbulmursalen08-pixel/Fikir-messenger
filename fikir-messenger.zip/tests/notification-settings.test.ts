import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = vi.hoisted(() => ({
  multiGet: vi.fn(),
  multiSet: vi.fn(),
}));

const channels = vi.hoisted(() => ({
  deleteNotificationChannelAsync: vi.fn(),
  setNotificationChannelAsync: vi.fn(),
}));

vi.mock("@react-native-async-storage/async-storage", () => ({ default: storage }));
vi.mock("react-native", () => ({ Platform: { OS: "android" } }));
vi.mock("expo-notifications", () => ({
  AndroidImportance: { HIGH: 4, MAX: 5 },
  AndroidNotificationVisibility: { PUBLIC: 1 },
  ...channels,
}));

import {
  configureAndroidNotificationChannels,
  DEFAULT_NOTIFICATION_SETTINGS,
  getNotificationSettings,
  saveNotificationSettings,
} from "../lib/notification-settings";

describe("notification settings", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("defaults sound and vibration to enabled when a device has no saved preferences", async () => {
    storage.multiGet.mockResolvedValue([
      ["notification_sound_enabled", null],
      ["notification_vibration_enabled", null],
    ]);

    await expect(getNotificationSettings()).resolves.toEqual(DEFAULT_NOTIFICATION_SETTINGS);
  });

  it("reads each locally saved toggle independently", async () => {
    storage.multiGet.mockResolvedValue([
      ["notification_sound_enabled", "false"],
      ["notification_vibration_enabled", "true"],
    ]);

    await expect(getNotificationSettings()).resolves.toEqual({ soundEnabled: false, vibrationEnabled: true });
  });

  it("writes both toggle preferences together", async () => {
    await saveNotificationSettings({ soundEnabled: false, vibrationEnabled: false });

    expect(storage.multiSet).toHaveBeenCalledWith([
      ["notification_sound_enabled", "false"],
      ["notification_vibration_enabled", "false"],
    ]);
  });

  it("recreates app-owned Android channels with sound and vibration disabled", async () => {
    channels.deleteNotificationChannelAsync.mockResolvedValue(undefined);
    channels.setNotificationChannelAsync.mockResolvedValue(undefined);

    await configureAndroidNotificationChannels(
      { soundEnabled: false, vibrationEnabled: false },
      { resetExistingChannels: true },
    );

    expect(channels.deleteNotificationChannelAsync).toHaveBeenCalledTimes(6);
    expect(channels.setNotificationChannelAsync).toHaveBeenCalledWith(
      "messages",
      expect.objectContaining({ sound: null, vibrationPattern: null }),
    );
    expect(channels.setNotificationChannelAsync).toHaveBeenCalledWith(
      "audio-calls",
      expect.objectContaining({ sound: null, vibrationPattern: null }),
    );
    expect(channels.setNotificationChannelAsync).toHaveBeenCalledWith(
      "video-calls",
      expect.objectContaining({ sound: null, vibrationPattern: null }),
    );
  });
});
