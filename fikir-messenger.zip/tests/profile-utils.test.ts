import { describe, expect, it } from "vitest";

import { isUsernameFormatValid, normalizeUsername } from "../lib/profile-utils";

describe("profile username helpers", () => {
  it("normalizes whitespace, case, and an optional at-sign", () => {
    expect(normalizeUsername("  @Fikir.Member  ")).toBe("fikir.member");
  });

  it("accepts only the supported unique username character set and length", () => {
    expect(isUsernameFormatValid("fikir.member_2026")).toBe(true);
    expect(isUsernameFormatValid("ab")).toBe(false);
    expect(isUsernameFormatValid("ফিকির")).toBe(false);
    expect(isUsernameFormatValid("name with spaces")).toBe(false);
  });
});
