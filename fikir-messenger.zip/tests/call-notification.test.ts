import { describe, expect, it } from "vitest";

import { getGroupCallRecipientIds, getIncomingCallPushOptions } from "../server/call-notification";

describe("group call notification recipients", () => {
  it("notifies only unique active group members other than the caller", () => {
    expect(getGroupCallRecipientIds([
      { membership: { state: "active" }, user: { id: 7 } },
      { membership: { state: "pending" }, user: { id: 8 } },
      { membership: { state: "removed" }, user: { id: 9 } },
      { membership: { state: "active" }, user: { id: 10 } },
      { membership: { state: "active" }, user: { id: 10 } },
    ], 7)).toEqual([10]);
  });

  it("uses distinct short-lived high-priority alerts for audio and video calls", () => {
    expect(getIncomingCallPushOptions("audio")).toEqual({
      channelId: "audio-calls",
      categoryId: "incoming_call",
      priority: "high",
      ttl: 60,
      sound: "audio_call_ring.wav",
    });
    expect(getIncomingCallPushOptions("video")).toEqual({
      channelId: "video-calls",
      categoryId: "incoming_call",
      priority: "high",
      ttl: 60,
      sound: "video_call_ring.wav",
    });
  });
});
