import { describe, expect, it } from "vitest";

import { filterAdminDashboardUsers, formatAdminLastActive, getAdminUserStatus, sortAdminDashboardUsers } from "../lib/admin-dashboard";

const users = [
  { id: 1, name: "মালিক", username: "owner", email: "owner@gmail.com" },
  { id: 2, name: "রফিক আহমদ", username: "rafiq", email: "rafiq@gmail.com" },
  { id: 3, name: "করিম", username: "karim", email: "karim@example.com" },
  { id: 4, name: "সাবা", username: "saba", email: "saba@gmail.com" },
];

describe("admin dashboard helpers", () => {
  it("keeps a user's ban and personal-block state distinct", () => {
    expect(getAdminUserStatus(2, new Set([2]), new Set([3]))).toEqual({ isBanned: true, isBlocked: false, isRegular: false });
    expect(getAdminUserStatus(3, new Set([2]), new Set([3]))).toEqual({ isBanned: false, isBlocked: true, isRegular: false });
    expect(getAdminUserStatus(4, new Set([2]), new Set([3]))).toEqual({ isBanned: false, isBlocked: false, isRegular: true });
  });

  it("excludes the current founder and filters by Bengali name, username, Gmail email, and status", () => {
    const banned = new Set([2]);
    const blocked = new Set([3]);
    expect(filterAdminDashboardUsers(users, 1, "", "all", banned, blocked).map((user) => user.id)).toEqual([2, 3, 4]);
    expect(filterAdminDashboardUsers(users, 1, "রফিক", "all", banned, blocked).map((user) => user.id)).toEqual([2]);
    expect(filterAdminDashboardUsers(users, 1, "RAFIQ@GMAIL.COM", "all", banned, blocked).map((user) => user.id)).toEqual([2]);
    expect(filterAdminDashboardUsers(users, 1, "example.com", "all", banned, blocked).map((user) => user.id)).toEqual([3]);
    expect(filterAdminDashboardUsers(users, 1, "saba", "regular", banned, blocked).map((user) => user.id)).toEqual([4]);
    expect(filterAdminDashboardUsers(users, 1, "", "blocked", banned, blocked).map((user) => user.id)).toEqual([3]);
    expect(filterAdminDashboardUsers(users, 1, "", "banned", banned, blocked).map((user) => user.id)).toEqual([2]);
  });

  it("formats the server-recorded last active timestamp in Bangladesh date and time format", () => {
    const label = formatAdminLastActive("2026-08-21T00:30:00.000Z");
    expect(label).toContain("২০২৬");
    expect(label).toContain("৬:৩০");
    expect(formatAdminLastActive(null)).toBe("উপস্থিতির তথ্য নেই");
  });

  it("orders users by last active time without changing the filtered source list", () => {
    const activityUsers = [
      { ...users[1], lastActiveAt: "2026-08-20T19:30:00.000Z" },
      { ...users[2], lastActiveAt: null },
      { ...users[3], lastActiveAt: "2026-08-21T00:30:00.000Z" },
      { id: 5, name: "নাসির", username: "nasir", email: "nasir@gmail.com", lastActiveAt: "not-a-date" },
    ];
    expect(sortAdminDashboardUsers(activityUsers, "recent").map((user) => user.id)).toEqual([4, 2, 3, 5]);
    expect(sortAdminDashboardUsers(activityUsers, "oldest").map((user) => user.id)).toEqual([2, 4, 3, 5]);
    expect(activityUsers.map((user) => user.id)).toEqual([2, 3, 4, 5]);
  });

  it("keeps currently online users ahead of every last-active sorting option", () => {
    const activityUsers = [
      { ...users[1], lastActiveAt: "2026-08-21T04:30:00.000Z" },
      { ...users[2], lastActiveAt: "2026-08-19T12:00:00.000Z", isOnline: true },
      { ...users[3], lastActiveAt: "2026-08-20T15:00:00.000Z", isOnline: true },
    ];
    expect(sortAdminDashboardUsers(activityUsers, "recent").map((user) => user.id)).toEqual([4, 3, 2]);
    expect(sortAdminDashboardUsers(activityUsers, "oldest").map((user) => user.id)).toEqual([3, 4, 2]);
  });
});
