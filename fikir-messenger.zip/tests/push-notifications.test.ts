import { describe, expect, it } from "vitest";

import { isExpoPushToken, normalizeExpoPushTokens } from "../lib/push-notifications";

describe("Push token registration validation", () => {
  it("accepts valid Expo token formats after trimming device-provided whitespace", () => {
    expect(isExpoPushToken(" ExpoPushToken[android_Device-01] ")).toBe(true);
    expect(isExpoPushToken("ExponentPushToken[iosDevice_02]")).toBe(true);
  });

  it("rejects blank, malformed, and oversized values before server storage", () => {
    expect(isExpoPushToken("")).toBe(false);
    expect(isExpoPushToken("not-a-push-token")).toBe(false);
    expect(isExpoPushToken(`ExpoPushToken[${"a".repeat(300)}]`)).toBe(false);
  });

  it("normalizes a device list so repeat registration never produces duplicate delivery targets", () => {
    expect(normalizeExpoPushTokens([
      " ExpoPushToken[android_Device-01] ",
      "ExpoPushToken[android_Device-01]",
      "invalid-token",
      "ExponentPushToken[iosDevice_02]",
    ])).toEqual(["ExpoPushToken[android_Device-01]", "ExponentPushToken[iosDevice_02]"]);
  });
});
