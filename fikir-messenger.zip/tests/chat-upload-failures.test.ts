import { describe, expect, it } from "vitest";

import {
  CHAT_ATTACHMENT_MAX_BYTES,
  classifyChatUploadError,
  isChatAttachmentTooLarge,
} from "../lib/chat-upload-failures";

describe("chat upload failure classification", () => {
  it("separates server validation failures by file size and file type", () => {
    expect(classifyChatUploadError({ data: { code: "PAYLOAD_TOO_LARGE" } })).toMatchObject({
      kind: "file",
      label: "ফাইলের আকার বেশি",
      retryable: false,
    });
    expect(classifyChatUploadError({ shape: { data: { code: "BAD_REQUEST" } } })).toMatchObject({
      kind: "file",
      label: "ফাইলের ধরন সমর্থিত নয়",
      retryable: false,
    });
  });

  it("separates network, permission, and server errors", () => {
    expect(classifyChatUploadError(new Error("Network request failed"))).toMatchObject({ kind: "network", retryable: true });
    expect(classifyChatUploadError(new Error("E_PERMISSIONS_MISSING"))).toMatchObject({ kind: "permission", retryable: false });
    expect(classifyChatUploadError({ data: { code: "INTERNAL_SERVER_ERROR" } })).toMatchObject({ kind: "server", retryable: true });
  });

  it("checks the same 10 MB limit locally before sending", () => {
    expect(isChatAttachmentTooLarge(CHAT_ATTACHMENT_MAX_BYTES)).toBe(false);
    expect(isChatAttachmentTooLarge(CHAT_ATTACHMENT_MAX_BYTES + 1)).toBe(true);
  });
});
