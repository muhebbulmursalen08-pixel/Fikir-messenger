import { describe, expect, it } from "vitest";

import { isFounderEmail } from "../server/db";

describe("Founder email authorization", () => {
  it("recognizes every owner-approved Gmail address, including the sixth account", () => {
    expect(isFounderEmail("muhebbulmursalenm@gmail.com")).toBe(true);
    expect(isFounderEmail("muhebbulmursalen2@gmail.com")).toBe(true);
    expect(isFounderEmail("murchalinmia016@gmail.com")).toBe(true);
    expect(isFounderEmail("muhebbulmursalen04@gmail.com")).toBe(true);
    expect(isFounderEmail("muhebbulmursalen05@gmail.com")).toBe(true);
    expect(isFounderEmail("muhebbulmursalen08@gmail.com")).toBe(true);
  });

  it("matches the authenticated Gmail address after trimming and lowercasing, not the profile name", () => {
    expect(isFounderEmail("  MUHEBBULMURSALEN08@GMAIL.COM  ")).toBe(true);
    expect(isFounderEmail("Mawlana Mohammad Muhibbul Mursalin")).toBe(false);
    expect(isFounderEmail("unapproved.account@gmail.com")).toBe(false);
  });
});
