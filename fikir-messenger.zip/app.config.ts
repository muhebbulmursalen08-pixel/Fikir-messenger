import "./scripts/load-env.js";
import type { ExpoConfig } from "expo/config";

const rawBundleId = "space.manus.fikir.messenger.t20260820021039";
const bundleId = rawBundleId
  .replace(/[-_]/g, ".")
  .replace(/[^a-zA-Z0-9.]/g, "")
  .replace(/\.+/g, ".")
  .replace(/^\.+|\.+$/g, "")
  .toLowerCase()
  .split(".")
  .map((segment) => (/^[a-zA-Z]/.test(segment) ? segment : `x${segment}`))
  .join(".");
const timestamp = bundleId.split(".").pop()?.replace(/^t/, "") ?? "";

const env = {
  appName: "ফিকির মেসেঞ্জার",
  appSlug: "fikir-messenger",
  logoUrl: "/manus-storage/fikir-messenger-icon_c9675644.png",
  scheme: `manus${timestamp}`,
  iosBundleId: bundleId,
  androidPackage: bundleId,
};

const config: ExpoConfig = {
  name: env.appName,
  slug: env.appSlug,
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: env.scheme,
  userInterfaceStyle: "automatic",
  newArchEnabled: true,
  ios: {
    supportsTablet: true,
    bundleIdentifier: env.iosBundleId,
    infoPlist: {
      ITSAppUsesNonExemptEncryption: false,
      NSMicrophoneUsageDescription: "ফিকির মেসেঞ্জারে অডিও কলে কথা বলার জন্য মাইক্রোফোন ব্যবহার করা হয়।",
      NSCameraUsageDescription: "ফিকির মেসেঞ্জারে ভিডিও কলে অংশ নিতে ক্যামেরা ব্যবহার করা হয়।",
    },
  },
  android: {
    adaptiveIcon: {
      backgroundColor: "#0B4F9C",
      foregroundImage: "./assets/images/android-icon-foreground.png",
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    edgeToEdgeEnabled: true,
    softwareKeyboardLayoutMode: "resize",
    predictiveBackGestureEnabled: false,
    package: env.androidPackage,
    permissions: [
      "POST_NOTIFICATIONS",
      "RECORD_AUDIO",
      "CAMERA",
      "MODIFY_AUDIO_SETTINGS",
      "USE_FULL_SCREEN_INTENT",
      "FOREGROUND_SERVICE",
      "FOREGROUND_SERVICE_PHONE_CALL",
      "FOREGROUND_SERVICE_MICROPHONE",
      "FOREGROUND_SERVICE_CAMERA",
    ],
    intentFilters: [
      {
        action: "VIEW",
        autoVerify: true,
        data: [{ scheme: env.scheme, host: "*" }],
        category: ["BROWSABLE", "DEFAULT"],
      },
    ],
  },
  web: { bundler: "metro", output: "static", favicon: "./assets/images/favicon.png" },
  plugins: [
    "expo-router",
    "@livekit/react-native-expo-plugin",
    "@config-plugins/react-native-webrtc",
    [
      "expo-image-picker",
      {
        photosPermission: "Allow $(PRODUCT_NAME) to choose photos to share in messages.",
        cameraPermission: "Allow $(PRODUCT_NAME) to take photos to share in messages.",
      },
    ],
    [
      "expo-media-library",
      {
        photosPermission: "Allow $(PRODUCT_NAME) to save shared images to your gallery.",
        savePhotosPermission: "Allow $(PRODUCT_NAME) to save shared images to your gallery.",
      },
    ],
    ["expo-audio", { microphonePermission: "Allow $(PRODUCT_NAME) to access your microphone." }],
    ["expo-video", { supportsBackgroundPlayback: true, supportsPictureInPicture: true }],
    [
      "expo-notifications",
      {
        icon: "./assets/images/android-icon-monochrome.png",
        color: "#0B4F9C",
        sounds: [
          "./assets/sounds/message_alert.wav",
          "./assets/sounds/audio_call_ring.wav",
          "./assets/sounds/video_call_ring.wav",
        ],
      },
    ],
    [
      "expo-splash-screen",
      {
        image: "./assets/images/splash-icon.png",
        imageWidth: 200,
        resizeMode: "contain",
        backgroundColor: "#0B4F9C",
        dark: { backgroundColor: "#071729" },
      },
    ],
    ["expo-build-properties", { android: { buildArchs: ["armeabi-v7a", "arm64-v8a"], minSdkVersion: 24 } }],
  ],
  experiments: { typedRoutes: true, reactCompiler: true },
};

export default config;
