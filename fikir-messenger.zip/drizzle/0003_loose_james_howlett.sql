CREATE TABLE `groupMessageReceipts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageId` int NOT NULL,
	`userId` int NOT NULL,
	`seenAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `groupMessageReceipts_id` PRIMARY KEY(`id`),
	CONSTRAINT `group_message_receipt_unique` UNIQUE(`messageId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `userPresence` (
	`userId` int NOT NULL,
	`isOnline` boolean NOT NULL DEFAULT false,
	`lastActiveAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPresence_userId` PRIMARY KEY(`userId`)
);
--> statement-breakpoint
CREATE INDEX `group_message_receipt_message_idx` ON `groupMessageReceipts` (`messageId`);--> statement-breakpoint
CREATE INDEX `group_message_receipt_user_idx` ON `groupMessageReceipts` (`userId`,`seenAt`);--> statement-breakpoint
CREATE INDEX `user_presence_active_idx` ON `userPresence` (`lastActiveAt`);