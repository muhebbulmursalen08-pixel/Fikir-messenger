CREATE TABLE `founderUpdates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`authorId` int NOT NULL,
	`body` text NOT NULL,
	`imageUrls` text,
	`linkUrl` text,
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`scheduledFor` timestamp,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `founderUpdates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userBans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bannedBy` int NOT NULL,
	`reason` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`bannedAt` timestamp NOT NULL DEFAULT (now()),
	`unbannedAt` timestamp,
	CONSTRAINT `userBans_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_bans_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `userBlocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`blockerId` int NOT NULL,
	`blockedUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userBlocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_block_unique` UNIQUE(`blockerId`,`blockedUserId`)
);
--> statement-breakpoint
CREATE TABLE `userReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reporterId` int NOT NULL,
	`reportedUserId` int NOT NULL,
	`reason` text NOT NULL,
	`status` enum('open','reviewed','resolved') NOT NULL DEFAULT 'open',
	`reviewedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `userReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `founder_updates_status_published_idx` ON `founderUpdates` (`status`,`publishedAt`);--> statement-breakpoint
CREATE INDEX `founder_updates_author_updated_idx` ON `founderUpdates` (`authorId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `user_bans_active_banned_idx` ON `userBans` (`isActive`,`bannedAt`);--> statement-breakpoint
CREATE INDEX `user_blocks_blocked_idx` ON `userBlocks` (`blockedUserId`);--> statement-breakpoint
CREATE INDEX `user_reports_status_created_idx` ON `userReports` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `user_reports_reported_idx` ON `userReports` (`reportedUserId`,`createdAt`);