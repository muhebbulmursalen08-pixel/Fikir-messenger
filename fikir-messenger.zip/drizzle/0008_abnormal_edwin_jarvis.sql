ALTER TABLE `callSessions` MODIFY COLUMN `status` enum('requested','active','declined','missed','ended') NOT NULL DEFAULT 'requested';--> statement-breakpoint
ALTER TABLE `callSessions` ADD `missedAt` timestamp;--> statement-breakpoint
ALTER TABLE `callSessions` ADD `missedSeenAt` timestamp;--> statement-breakpoint
CREATE INDEX `call_sessions_recipient_status_idx` ON `callSessions` (`recipientId`,`status`,`createdAt`);