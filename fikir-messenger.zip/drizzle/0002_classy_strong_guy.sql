CREATE TABLE `callSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`initiatorId` int NOT NULL,
	`recipientId` int,
	`groupId` int,
	`kind` enum('audio','video') NOT NULL,
	`status` enum('requested','active','declined','ended') NOT NULL DEFAULT 'requested',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`acceptedAt` timestamp,
	`endedAt` timestamp,
	CONSTRAINT `callSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `call_sessions_direct_idx` ON `callSessions` (`initiatorId`,`recipientId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `call_sessions_group_idx` ON `callSessions` (`groupId`,`status`,`createdAt`);