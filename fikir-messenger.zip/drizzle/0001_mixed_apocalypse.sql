CREATE TABLE `groupMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`groupId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('owner','admin','moderator','member') NOT NULL DEFAULT 'member',
	`state` enum('active','pending','invited','removed') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `groupMembers_id` PRIMARY KEY(`id`),
	CONSTRAINT `group_member_unique` UNIQUE(`groupId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `groups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`handle` varchar(40) NOT NULL,
	`description` text,
	`imageUrl` text,
	`privacy` enum('public','private','approval') NOT NULL DEFAULT 'public',
	`isAnnouncementsOnly` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `groups_id` PRIMARY KEY(`id`),
	CONSTRAINT `groups_handle_unique` UNIQUE(`handle`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`senderId` int NOT NULL,
	`recipientId` int,
	`groupId` int,
	`body` text NOT NULL,
	`kind` enum('text','image','file','voice') NOT NULL DEFAULT 'text',
	`attachmentUrl` text,
	`status` enum('sent','delivered','seen') NOT NULL DEFAULT 'sent',
	`editedAt` timestamp,
	`deletedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`authorId` int NOT NULL,
	`groupId` int,
	`body` text NOT NULL,
	`linkUrl` text,
	`visibility` enum('profile','community','founder') NOT NULL DEFAULT 'profile',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `posts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','founder') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `username` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bio` text;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_username_unique` UNIQUE(`username`);--> statement-breakpoint
CREATE INDEX `group_members_user_idx` ON `groupMembers` (`userId`);--> statement-breakpoint
CREATE INDEX `group_members_group_state_idx` ON `groupMembers` (`groupId`,`state`);--> statement-breakpoint
CREATE INDEX `groups_owner_idx` ON `groups` (`ownerId`);--> statement-breakpoint
CREATE INDEX `groups_privacy_idx` ON `groups` (`privacy`);--> statement-breakpoint
CREATE INDEX `messages_direct_idx` ON `messages` (`senderId`,`recipientId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `messages_group_idx` ON `messages` (`groupId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `messages_recipient_idx` ON `messages` (`recipientId`,`status`);--> statement-breakpoint
CREATE INDEX `posts_author_idx` ON `posts` (`authorId`);--> statement-breakpoint
CREATE INDEX `posts_group_idx` ON `posts` (`groupId`);--> statement-breakpoint
CREATE INDEX `posts_visibility_created_idx` ON `posts` (`visibility`,`createdAt`);--> statement-breakpoint
CREATE INDEX `users_email_idx` ON `users` (`email`);