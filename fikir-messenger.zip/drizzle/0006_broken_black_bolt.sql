CREATE TABLE `founderUpdateReactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`updateId` int NOT NULL,
	`userId` int NOT NULL,
	`emoji` varchar(16) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `founderUpdateReactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `founder_update_reaction_user_unique` UNIQUE(`updateId`,`userId`)
);
--> statement-breakpoint
ALTER TABLE `founderUpdates` ADD `voiceUrl` text;--> statement-breakpoint
ALTER TABLE `founderUpdates` ADD `voiceDurationSeconds` int;--> statement-breakpoint
CREATE INDEX `founder_update_reactions_update_created_idx` ON `founderUpdateReactions` (`updateId`,`createdAt`);