CREATE TABLE `chatActivities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorId` int NOT NULL,
	`recipientId` int,
	`groupId` int,
	`activity` enum('typing','uploading_image','uploading_file','recording_voice') NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chatActivities_id` PRIMARY KEY(`id`),
	CONSTRAINT `chat_activity_actor_target_unique` UNIQUE(`actorId`,`recipientId`,`groupId`)
);
--> statement-breakpoint
CREATE TABLE `postReactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`postId` int NOT NULL,
	`userId` int NOT NULL,
	`emoji` varchar(16) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `postReactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `post_reaction_user_unique` UNIQUE(`postId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `userFollows` (
	`id` int AUTO_INCREMENT NOT NULL,
	`followerId` int NOT NULL,
	`followingId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userFollows_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_follow_unique` UNIQUE(`followerId`,`followingId`)
);
--> statement-breakpoint
ALTER TABLE `posts` ADD `imageUrls` text;--> statement-breakpoint
ALTER TABLE `posts` ADD `voiceUrl` text;--> statement-breakpoint
ALTER TABLE `posts` ADD `voiceDurationSeconds` int;--> statement-breakpoint
CREATE INDEX `chat_activity_target_updated_idx` ON `chatActivities` (`recipientId`,`groupId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `post_reactions_post_created_idx` ON `postReactions` (`postId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `user_follows_following_idx` ON `userFollows` (`followingId`);