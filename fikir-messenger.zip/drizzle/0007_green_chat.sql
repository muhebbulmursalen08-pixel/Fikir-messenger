CREATE TABLE `founderUpdateViewers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`updateId` int NOT NULL,
	`userId` int NOT NULL,
	`viewedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `founderUpdateViewers_id` PRIMARY KEY(`id`),
	CONSTRAINT `founder_update_viewer_unique` UNIQUE(`updateId`,`userId`)
);
--> statement-breakpoint
CREATE INDEX `founder_update_viewers_update_viewed_idx` ON `founderUpdateViewers` (`updateId`,`viewedAt`);