import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Authenticated account and editable public-profile data. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  username: varchar("username", { length: 32 }),
  avatarUrl: text("avatarUrl"),
  bio: text("bio"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "founder"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("users_username_unique").on(table.username),
  index("users_email_idx").on(table.email),
]);

/** A long-form post or a link published on a user profile, in a group, or by the founder. */
export const posts = mysqlTable("posts", {
  id: int("id").autoincrement().primaryKey(),
  authorId: int("authorId").notNull(),
  groupId: int("groupId"),
  body: text("body").notNull(),
  imageUrls: text("imageUrls"),
  voiceUrl: text("voiceUrl"),
  voiceDurationSeconds: int("voiceDurationSeconds"),
  linkUrl: text("linkUrl"),
  visibility: mysqlEnum("visibility", ["profile", "community", "founder"]).default("profile").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("posts_author_idx").on(table.authorId),
  index("posts_group_idx").on(table.groupId),
  index("posts_visibility_created_idx").on(table.visibility, table.createdAt),
]);

/** A single reaction per user on a public community post. */
export const postReactions = mysqlTable("postReactions", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  emoji: varchar("emoji", { length: 16 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("post_reaction_user_unique").on(table.postId, table.userId),
  index("post_reactions_post_created_idx").on(table.postId, table.createdAt),
]);

/** Follow relationships used to prioritise followed authors in the community feed. */
export const userFollows = mysqlTable("userFollows", {
  id: int("id").autoincrement().primaryKey(),
  followerId: int("followerId").notNull(),
  followingId: int("followingId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("user_follow_unique").on(table.followerId, table.followingId),
  index("user_follows_following_idx").on(table.followingId),
]);

/** Short-lived presence for WhatsApp-style typing/uploading/recording indicators. */
export const chatActivities = mysqlTable("chatActivities", {
  id: int("id").autoincrement().primaryKey(),
  actorId: int("actorId").notNull(),
  recipientId: int("recipientId"),
  groupId: int("groupId"),
  activity: mysqlEnum("activity", ["typing", "uploading_image", "uploading_file", "recording_voice"]).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("chat_activity_actor_target_unique").on(table.actorId, table.recipientId, table.groupId),
  index("chat_activity_target_updated_idx").on(table.recipientId, table.groupId, table.updatedAt),
]);

/** Founder-owned public updates. Drafts remain founder-only until manually published. */
export const founderUpdates = mysqlTable("founderUpdates", {
  id: int("id").autoincrement().primaryKey(),
  authorId: int("authorId").notNull(),
  body: text("body").notNull(),
  imageUrls: text("imageUrls"),
  voiceUrl: text("voiceUrl"),
  voiceDurationSeconds: int("voiceDurationSeconds"),
  linkUrl: text("linkUrl"),
  status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
  scheduledFor: timestamp("scheduledFor"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("founder_updates_status_published_idx").on(table.status, table.publishedAt),
  index("founder_updates_author_updated_idx").on(table.authorId, table.updatedAt),
]);

/** One visible emoji reaction per user for each published founder update. */
export const founderUpdateReactions = mysqlTable("founderUpdateReactions", {
  id: int("id").autoincrement().primaryKey(),
  updateId: int("updateId").notNull(),
  userId: int("userId").notNull(),
  emoji: varchar("emoji", { length: 16 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("founder_update_reaction_user_unique").on(table.updateId, table.userId),
  index("founder_update_reactions_update_created_idx").on(table.updateId, table.createdAt),
]);

/** First-view receipts let founders measure reach without exposing viewer identities to regular users. */
export const founderUpdateViewers = mysqlTable("founderUpdateViewers", {
  id: int("id").autoincrement().primaryKey(),
  updateId: int("updateId").notNull(),
  userId: int("userId").notNull(),
  viewedAt: timestamp("viewedAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("founder_update_viewer_unique").on(table.updateId, table.userId),
  index("founder_update_viewers_update_viewed_idx").on(table.updateId, table.viewedAt),
]);

/** A user-submitted safety report, reviewable only by founder accounts. */
export const userReports = mysqlTable("userReports", {
  id: int("id").autoincrement().primaryKey(),
  reporterId: int("reporterId").notNull(),
  reportedUserId: int("reportedUserId").notNull(),
  reason: text("reason").notNull(),
  status: mysqlEnum("status", ["open", "reviewed", "resolved"]).default("open").notNull(),
  reviewedBy: int("reviewedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
}, (table) => [
  index("user_reports_status_created_idx").on(table.status, table.createdAt),
  index("user_reports_reported_idx").on(table.reportedUserId, table.createdAt),
]);

/** A private, per-user direct-message block. */
export const userBlocks = mysqlTable("userBlocks", {
  id: int("id").autoincrement().primaryKey(),
  blockerId: int("blockerId").notNull(),
  blockedUserId: int("blockedUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("user_block_unique").on(table.blockerId, table.blockedUserId),
  index("user_blocks_blocked_idx").on(table.blockedUserId),
]);

/** A founder-issued account ban. Inactive records preserve the moderation audit trail. */
export const userBans = mysqlTable("userBans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bannedBy: int("bannedBy").notNull(),
  reason: text("reason").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  bannedAt: timestamp("bannedAt").defaultNow().notNull(),
  unbannedAt: timestamp("unbannedAt"),
}, (table) => [
  uniqueIndex("user_bans_user_unique").on(table.userId),
  index("user_bans_active_banned_idx").on(table.isActive, table.bannedAt),
]);

/** A member-managed space for discussion, announcements, and shared posts. */
export const groups = mysqlTable("groups", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  handle: varchar("handle", { length: 40 }).notNull().unique(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  privacy: mysqlEnum("privacy", ["public", "private", "approval"]).default("public").notNull(),
  isAnnouncementsOnly: boolean("isAnnouncementsOnly").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("groups_owner_idx").on(table.ownerId),
  index("groups_privacy_idx").on(table.privacy),
]);

/** A user's role and membership state within a group. */
export const groupMembers = mysqlTable("groupMembers", {
  id: int("id").autoincrement().primaryKey(),
  groupId: int("groupId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["owner", "admin", "moderator", "member"]).default("member").notNull(),
  state: mysqlEnum("state", ["active", "pending", "invited", "removed"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("group_member_unique").on(table.groupId, table.userId),
  index("group_members_user_idx").on(table.userId),
  index("group_members_group_state_idx").on(table.groupId, table.state),
]);

/** A direct or group message that is delivered from the server to authorised recipients. */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  recipientId: int("recipientId"),
  groupId: int("groupId"),
  body: text("body").notNull(),
  kind: mysqlEnum("kind", ["text", "image", "file", "voice"]).default("text").notNull(),
  attachmentUrl: text("attachmentUrl"),
  status: mysqlEnum("status", ["sent", "delivered", "seen"]).default("sent").notNull(),
  editedAt: timestamp("editedAt"),
  deletedAt: timestamp("deletedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("messages_direct_idx").on(table.senderId, table.recipientId, table.createdAt),
  index("messages_group_idx").on(table.groupId, table.createdAt),
  index("messages_recipient_idx").on(table.recipientId, table.status),
]);

/** Most recent authenticated activity used to show online, offline, and last-seen state. */
export const userPresence = mysqlTable("userPresence", {
  userId: int("userId").primaryKey(),
  isOnline: boolean("isOnline").default(false).notNull(),
  lastActiveAt: timestamp("lastActiveAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("user_presence_active_idx").on(table.lastActiveAt),
]);

/** A device-specific Expo Push Token registered by an authenticated mobile user. */
export const pushTokens = mysqlTable("pushTokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  token: varchar("token", { length: 255 }).notNull(),
  platform: mysqlEnum("platform", ["android", "ios"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("push_token_user_token_unique").on(table.userId, table.token),
  index("push_tokens_user_idx").on(table.userId, table.updatedAt),
]);

/** Per-member group message seen receipts. Receipts are never created for a message sender. */
export const groupMessageReceipts = mysqlTable("groupMessageReceipts", {
  id: int("id").autoincrement().primaryKey(),
  messageId: int("messageId").notNull(),
  userId: int("userId").notNull(),
  seenAt: timestamp("seenAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("group_message_receipt_unique").on(table.messageId, table.userId),
  index("group_message_receipt_message_idx").on(table.messageId),
  index("group_message_receipt_user_idx").on(table.userId, table.seenAt),
]);

/** A permission-checked request or active session for a future direct or group audio/video connection. */
export const callSessions = mysqlTable("callSessions", {
  id: int("id").autoincrement().primaryKey(),
  initiatorId: int("initiatorId").notNull(),
  recipientId: int("recipientId"),
  groupId: int("groupId"),
  kind: mysqlEnum("kind", ["audio", "video"]).notNull(),
  status: mysqlEnum("status", ["requested", "active", "declined", "missed", "ended"]).default("requested").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  acceptedAt: timestamp("acceptedAt"),
  missedAt: timestamp("missedAt"),
  missedSeenAt: timestamp("missedSeenAt"),
  endedAt: timestamp("endedAt"),
}, (table) => [
  index("call_sessions_direct_idx").on(table.initiatorId, table.recipientId, table.createdAt),
  index("call_sessions_group_idx").on(table.groupId, table.status, table.createdAt),
  index("call_sessions_recipient_status_idx").on(table.recipientId, table.status, table.createdAt),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Post = typeof posts.$inferSelect;
export type PostReaction = typeof postReactions.$inferSelect;
export type UserFollow = typeof userFollows.$inferSelect;
export type ChatActivity = typeof chatActivities.$inferSelect;
export type FounderUpdate = typeof founderUpdates.$inferSelect;
export type FounderUpdateReaction = typeof founderUpdateReactions.$inferSelect;
export type FounderUpdateViewer = typeof founderUpdateViewers.$inferSelect;
export type Group = typeof groups.$inferSelect;
export type GroupMember = typeof groupMembers.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type UserPresence = typeof userPresence.$inferSelect;
export type PushToken = typeof pushTokens.$inferSelect;
export type GroupMessageReceipt = typeof groupMessageReceipts.$inferSelect;
export type CallSession = typeof callSessions.$inferSelect;
export type UserReport = typeof userReports.$inferSelect;
export type UserBlock = typeof userBlocks.$inferSelect;
export type UserBan = typeof userBans.$inferSelect;
