# Push Notification Implementation Notes

## Verified Expo SDK 54 Requirements

Source: Local Expo SDK 54 Notifications documentation, `/home/ubuntu/fikir-messenger_helper/docs/background/notifications/DOCS.md` (reviewed 20 August 2026).

- `expo-notifications` obtains an Expo Push Token, receives notifications, and reacts when the user taps a notification.
- The app must ask the user for notification permission. Android should create a high-importance notification channel before requesting permission.
- Remote push notifications are unavailable in Expo Go on Android from Expo SDK 53 onward. They require a physical Android device with a development build or release build.
- The app must use the EAS `projectId` to request an Expo Push Token. The token is device-specific and should be registered to the authenticated user on the server.
- Foreground handling requires a notification handler to display a banner and list entry. Notification response listeners should use validated route data to open the relevant chat or announcement.
- The backend should send only recipient-targeted content; it must never expose other users' tokens to clients.

## Planned Fikir Messenger Behaviour

1. Register the authenticated user’s Expo Push Token after device permission is granted.
2. Send targeted notifications for new direct messages, group messages (excluding the sender), and founder announcements.
3. Include only an internal route descriptor in notification data and validate it before routing in the app.
4. Test on two physical Android development builds with one application backgrounded or closed.
