# LiveKit রিয়েল-টাইম কল: ইন্টিগ্রেশন নোট

## অফিসিয়াল উৎস

- [Expo quickstart — LiveKit Documentation](https://docs.livekit.io/transport/sdk-platforms/expo/)
- [Access tokens & grants — LiveKit Documentation](https://docs.livekit.io/frontends/reference/tokens-grants/)
- [LiveKit JS Server SDK](https://docs.livekit.io/reference/server-sdk-js/)

## যাচাইকৃত বাস্তবায়ন শর্ত

LiveKit-এর React Native SDK ব্যবহার করে অডিও ও ভিডিও ট্র্যাকসহ WebRTC রুমে সংযোগ করা যায়। Expo-তে এটির জন্য `@livekit/react-native`, `@livekit/react-native-expo-plugin`, `@livekit/react-native-webrtc`, `@config-plugins/react-native-webrtc` এবং `livekit-client` প্রয়োজন। অফিসিয়াল Expo quickstart অনুযায়ী এটি **Expo Go-তে চলে না**; native code ব্যবহারের জন্য Expo development build বা প্রকাশিত native build প্রয়োজন।

অ্যাপ কনফিগারেশনে LiveKit Expo plugin এবং WebRTC config plugin যোগ করতে হয়; অ্যাপ চালুর আগে `registerGlobals()` কল করতে হয়। কলের সময় `AudioSession` শুরু/বন্ধ করতে হয় এবং রুমে সার্ভার URL ও একটি মেয়াদসীমাবদ্ধ টোকেন দিয়ে সংযোগ করতে হয়।

LiveKit অ্যাক্সেস টোকেন JWT-ভিত্তিক এবং API secret দিয়ে সই করা হয়। সেই secret কখনও মোবাইল ক্লায়েন্টে রাখা যাবে না; ইতিমধ্যে থাকা Express/tRPC সার্ভার থেকে প্রমাণীকৃত ব্যবহারকারী ও কল-সদস্যতার ভিত্তিতে স্বল্পমেয়াদি টোকেন তৈরি করতে হবে। LiveKit URL, API key ও API secret প্রকল্পের সার্ভার-side secret হিসেবে প্রয়োজন।

## ২০২৬-০৮-২০: অফিসিয়াল নির্দেশনা পুনরায় যাচাই

- LiveKit Expo quickstart: https://docs.livekit.io/transport/sdk-platforms/expo/
- Expo development build: https://docs.expo.dev/develop/development-builds/introduction/

LiveKit-এর Expo নির্দেশনা একই পাঁচটি প্যাকেজ, `registerGlobals()` এবং Expo config plugin ব্যবহারের কথা বলে। এটি নিশ্চিত করে যে Expo Go নেটিভ WebRTC কোড বহন করে না, তাই বাস্তব কল পরীক্ষার জন্য একটি development build বা প্রকাশিত build অপরিহার্য। Expo-এর নির্দেশনা অনুসারে native dependency বা app configuration বদলালে নতুন development build তৈরি করতে হয়।
