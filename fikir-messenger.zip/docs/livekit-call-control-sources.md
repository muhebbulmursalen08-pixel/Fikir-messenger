# LiveKit native call-control references

Reviewed 2026-08-21 for the Fikir Messenger native Android/iOS call screen.

| Need | Verified LiveKit capability | Source |
|---|---|---|
| Native session | React Native calls use `LiveKitRoom` and `AudioSession`; Expo requires a development build. | [LiveKit React Native guide](https://docs.livekit.io/transport/sdk-platforms/react-native/) |
| Audio route picker | `AudioSession.getAudioOutputs()`, `selectAudioOutput(deviceId)`, and `showAudioRoutePicker()` are available after `startAudioSession()`. Android can expose speaker, earpiece, headset, and Bluetooth; iOS exposes default/force speaker plus the system picker. | [LiveKit React Native SDK README](https://github.com/livekit/client-sdk-react-native) |
| Audio policy | Android audio routing supports `preferredOutputList`; iOS supports a speaker or earpiece default output. | [LiveKit React Native SDK README](https://github.com/livekit/client-sdk-react-native) |

The repository's installed `@livekit/react-native` package is version 2.12.0. Its local type declarations confirm the audio APIs above. Hardware microphone, camera, ring, output routing, and remote media must still be verified on two physical Android/iOS development-build devices.
