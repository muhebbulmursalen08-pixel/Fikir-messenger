export function normalizeUsername(value: string) {
  return value.trim().toLowerCase().replace(/^@+/, "");
}

export function isUsernameFormatValid(value: string) {
  return /^[a-z0-9._]{3,32}$/i.test(normalizeUsername(value));
}
