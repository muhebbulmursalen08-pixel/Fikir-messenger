export type OfflineInboxSender = {
  senderName: string | null;
  senderUsername: string | null;
};

export type OfflineInboxSummaryLike = {
  directMessages?: OfflineInboxSender[];
  groupMessages?: OfflineInboxSender[];
  missedCalls?: unknown[];
} | undefined;

/** Counts message events that arrived while the recipient could not read them. */
export function getOfflineInboxMessageCount(summary: OfflineInboxSummaryLike) {
  return (summary?.directMessages?.length ?? 0) + (summary?.groupMessages?.length ?? 0);
}

/** Returns distinct, readable sender labels without exposing a long unbounded list in the home card. */
export function getOfflineInboxSenderNames(summary: OfflineInboxSummaryLike, maximum = 3) {
  const labels = [...(summary?.directMessages ?? []), ...(summary?.groupMessages ?? [])]
    .map((message) => message.senderName?.trim() || message.senderUsername?.trim() || "ফিকির ব্যবহারকারী");
  return Array.from(new Set(labels)).slice(0, Math.max(0, maximum));
}

export function hasOfflineInboxActivity(summary: OfflineInboxSummaryLike) {
  return getOfflineInboxMessageCount(summary) > 0 || (summary?.missedCalls?.length ?? 0) > 0;
}
