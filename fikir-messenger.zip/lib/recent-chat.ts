export type RecentMessagePreviewInput = {
  body: string;
  kind: "text" | "image" | "file" | "voice";
  senderName?: string | null;
  includeSender?: boolean;
};

const attachmentLabels: Record<RecentMessagePreviewInput["kind"], string> = {
  text: "বার্তা",
  image: "ছবি পাঠিয়েছেন",
  file: "ফাইল পাঠিয়েছেন",
  voice: "ভয়েস বার্তা পাঠিয়েছেন",
};

/** Produces a concise, safe chat-list preview without exposing deleted-message content. */
export function getRecentMessagePreview({ body, kind, senderName, includeSender = false }: RecentMessagePreviewInput) {
  const cleanBody = body.replace(/\s+/g, " ").trim();
  const prefix = includeSender && senderName ? `${senderName}: ` : "";
  const content = cleanBody || attachmentLabels[kind];
  return `${prefix}${content}`.slice(0, 120);
}

export type RecentConversationSearchInput = {
  name: string | null | undefined;
  username?: string | null | undefined;
  preview: string;
};

/** Matches a home-search phrase against a conversation name, username, or last-message preview. */
export function matchesRecentConversationSearch(
  { name, username, preview }: RecentConversationSearchInput,
  query: string,
) {
  const normalizedQuery = query.replace(/\s+/g, " ").trim().toLocaleLowerCase();
  if (!normalizedQuery) return true;
  return [name, username, preview]
    .filter((value): value is string => Boolean(value))
    .some((value) => value.replace(/\s+/g, " ").toLocaleLowerCase().includes(normalizedQuery));
}
