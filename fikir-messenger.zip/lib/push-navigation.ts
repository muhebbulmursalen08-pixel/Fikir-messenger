export type PushDestination =
  | { type: "dm"; peerId: number }
  | { type: "group"; groupId: number }
  | { type: "call"; sessionId: number; action?: "open" | "accept" | "decline" }
  | { type: "announcement" }
  | { type: "founder-update"; updateId: number };

type DestinationListener = (destination: PushDestination) => void;

let pendingDestination: PushDestination | null = null;
const listeners = new Set<DestinationListener>();

/**
 * Stores a notification destination until the authenticated community screen is
 * available, and immediately informs it when it is already mounted.
 */
export function requestPushNavigation(destination: PushDestination) {
  pendingDestination = destination;
  if (listeners.size === 0) return;
  listeners.forEach((listener) => listener(destination));
  pendingDestination = null;
}

/** Retrieves and clears an interaction received before the app UI mounted. */
export function consumePendingPushNavigation() {
  const destination = pendingDestination;
  pendingDestination = null;
  return destination;
}

/** Subscribes the active messenger view to notification navigation events. */
export function subscribePushNavigation(listener: DestinationListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
