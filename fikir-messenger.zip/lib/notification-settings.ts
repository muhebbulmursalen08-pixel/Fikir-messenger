import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

const SOUND_ENABLED_KEY = "notification_sound_enabled";
const VIBRATION_ENABLED_KEY = "notification_vibration_enabled";
// Expo's Android audio enums are numeric at runtime; local values keep lightweight mocks safe.
const ANDROID_NOTIFICATION_RINGTONE_USAGE = 6 as Notifications.AndroidAudioUsage;
const ANDROID_SONIFICATION_CONTENT_TYPE = 4 as Notifications.AndroidAudioContentType;

export type NotificationSettings = {
  soundEnabled: boolean;
  vibrationEnabled: boolean;
};

export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  soundEnabled: true,
  vibrationEnabled: true,
};

const readBoolean = (value: string | null) => value !== "false";

/** Reads device-local notification choices; absent values intentionally default to enabled. */
export async function getNotificationSettings(): Promise<NotificationSettings> {
  try {
    const stored = await AsyncStorage.multiGet([SOUND_ENABLED_KEY, VIBRATION_ENABLED_KEY]);
    const values = new Map(stored);
    return {
      soundEnabled: readBoolean(values.get(SOUND_ENABLED_KEY) ?? null),
      vibrationEnabled: readBoolean(values.get(VIBRATION_ENABLED_KEY) ?? null),
    };
  } catch (error) {
    console.warn("[Notification settings] Preferences could not be read:", error);
    return DEFAULT_NOTIFICATION_SETTINGS;
  }
}

/** Persists only this device's preferences, never syncing a person's choice to other devices. */
export async function saveNotificationSettings(settings: NotificationSettings): Promise<void> {
  await AsyncStorage.multiSet([
    [SOUND_ENABLED_KEY, String(settings.soundEnabled)],
    [VIBRATION_ENABLED_KEY, String(settings.vibrationEnabled)],
  ]);
}

/**
 * Applies device-local preferences to the Android channels used by messages, updates and incoming calls.
 * Android freezes a channel's sound and vibration after creation, so a user-initiated change recreates
 * only these app-owned channels before applying the new preference.
 */
export async function configureAndroidNotificationChannels(
  settings: NotificationSettings,
  options: { resetExistingChannels?: boolean } = {},
): Promise<void> {
  if (Platform.OS !== "android") return;

  if (options.resetExistingChannels) {
    await Promise.all([
      Notifications.deleteNotificationChannelAsync("messages"),
      Notifications.deleteNotificationChannelAsync("audio-calls"),
      Notifications.deleteNotificationChannelAsync("video-calls"),
      // Remove earlier channel identifiers created by previous development builds.
      Notifications.deleteNotificationChannelAsync("updates"),
      Notifications.deleteNotificationChannelAsync("calls-audio"),
      Notifications.deleteNotificationChannelAsync("calls-video"),
    ]);
  }

  const messageVibration = settings.vibrationEnabled ? [0, 250, 250, 250] : null;
  const callVibration = settings.vibrationEnabled ? [0, 500, 250, 500, 250, 500] : null;

  await Promise.all([
    Notifications.setNotificationChannelAsync("messages", {
      name: "বার্তা ও আপডেট",
      description: "ব্যক্তিগত বার্তা, গ্রুপ বার্তা ও প্রতিষ্ঠাতা আপডেটের বিজ্ঞপ্তি",
      importance: Notifications.AndroidImportance.HIGH,
      sound: settings.soundEnabled ? "message_alert.wav" : null,
      vibrationPattern: messageVibration,
      lightColor: "#0B4F9C",
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    }),
    Notifications.setNotificationChannelAsync("audio-calls", {
      name: "ইনকামিং অডিও কল",
      description: "অডিও কলের জন্য স্বতন্ত্র রিংটোন",
      importance: Notifications.AndroidImportance.MAX,
      sound: settings.soundEnabled ? "audio_call_ring.wav" : null,
      vibrationPattern: callVibration,
      lightColor: "#0B4F9C",
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      audioAttributes: {
        usage: ANDROID_NOTIFICATION_RINGTONE_USAGE,
        contentType: ANDROID_SONIFICATION_CONTENT_TYPE,
      },
    }),
    Notifications.setNotificationChannelAsync("video-calls", {
      name: "ইনকামিং ভিডিও কল",
      description: "ভিডিও কলের জন্য স্বতন্ত্র রিংটোন",
      importance: Notifications.AndroidImportance.MAX,
      sound: settings.soundEnabled ? "video_call_ring.wav" : null,
      vibrationPattern: callVibration,
      lightColor: "#0B4F9C",
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      audioAttributes: {
        usage: ANDROID_NOTIFICATION_RINGTONE_USAGE,
        contentType: ANDROID_SONIFICATION_CONTENT_TYPE,
      },
    }),
  ]);
}
