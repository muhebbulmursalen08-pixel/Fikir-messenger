export type SavableChatAttachmentKind = "image" | "voice" | "file";

const fallbackNames: Record<SavableChatAttachmentKind, string> = {
  image: "fikir-chat-image.jpg",
  voice: "fikir-voice-message.m4a",
  file: "fikir-attachment",
};

export function getChatAttachmentFilename(url: string, kind: SavableChatAttachmentKind): string {
  const urlPath = url.split("?")[0] ?? url;
  const encodedName = urlPath.split("/").pop() ?? "";
  const decodedName = decodeURIComponent(encodedName).replace(/^\d+-/, "").trim();
  return decodedName || fallbackNames[kind];
}

export function getChatAttachmentMimeType(kind: SavableChatAttachmentKind): string {
  if (kind === "image") return "image/jpeg";
  if (kind === "voice") return "audio/m4a";
  return "application/octet-stream";
}
