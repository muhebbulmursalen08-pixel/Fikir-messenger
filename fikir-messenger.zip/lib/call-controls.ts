export function formatCallDuration(totalSeconds: number): string {
  const safeSeconds = Math.max(0, Math.floor(totalSeconds));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  const seconds = safeSeconds % 60;
  const twoDigits = (value: number) => value.toString().padStart(2, "0");

  return hours > 0
    ? `${twoDigits(hours)}:${twoDigits(minutes)}:${twoDigits(seconds)}`
    : `${twoDigits(minutes)}:${twoDigits(seconds)}`;
}

export function getAudioOutputLabel(output: string | null): string {
  switch (output) {
    case "speaker":
    case "force_speaker":
      return "স্পিকার";
    case "earpiece":
      return "ইয়ারপিস";
    case "headset":
      return "হেডসেট";
    case "bluetooth":
      return "ব্লুটুথ";
    case "default":
      return "স্বয়ংক্রিয়";
    default:
      return "অডিও আউটপুট";
  }
}

export function getNextAudioOutput(
  currentOutput: string | null,
  availableOutputs: string[],
  platform: "ios" | "android",
): string | null {
  const speakerOutput = platform === "ios" ? "force_speaker" : "speaker";
  const alternateOutputs = platform === "ios"
    ? ["default"]
    : ["earpiece", "headset", "bluetooth"];

  if (currentOutput !== speakerOutput && availableOutputs.includes(speakerOutput)) {
    return speakerOutput;
  }

  return alternateOutputs.find((output) => availableOutputs.includes(output)) ?? null;
}
