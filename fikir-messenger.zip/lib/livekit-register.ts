/**
 * TypeScript and lint fallback. Metro selects the `.native` or `.web`
 * implementation for the matching platform at runtime.
 */
export {};
