/** Expo Push Service accepts both legacy Exponent and current Expo token prefixes. */
export const EXPO_PUSH_TOKEN_PATTERN = /^(?:ExponentPushToken|ExpoPushToken)\[[A-Za-z0-9_-]+\]$/;

/** Validates the bounded, trimmed token accepted by the authenticated registration route. */
export function isExpoPushToken(value: string) {
  const token = value.trim();
  return token.length > 0 && token.length <= 255 && EXPO_PUSH_TOKEN_PATTERN.test(token);
}

/** Normalizes and de-duplicates delivery tokens before they reach Expo's service. */
export function normalizeExpoPushTokens(tokens: string[]) {
  return [...new Set(tokens.map((token) => token.trim()).filter(isExpoPushToken))];
}
