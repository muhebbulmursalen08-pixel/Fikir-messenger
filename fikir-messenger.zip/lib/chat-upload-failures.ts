export const CHAT_ATTACHMENT_MAX_BYTES = 10 * 1024 * 1024;

export type ChatUploadFailureKind = "network" | "file" | "permission" | "server" | "unknown";

export type ChatUploadFailure = {
  kind: ChatUploadFailureKind;
  label: string;
  message: string;
  retryable: boolean;
};

const tooLargeFailure = (): ChatUploadFailure => ({
  kind: "file",
  label: "ফাইলের আকার বেশি",
  message: "ফাইলটি ১০ MB-এর বেশি। ১০ MB বা তার কম ফাইল বেছে নিন।",
  retryable: false,
});

const unsupportedFileFailure = (): ChatUploadFailure => ({
  kind: "file",
  label: "ফাইলের ধরন সমর্থিত নয়",
  message: "ফাইলের ধরন সমর্থিত নয়। ছবি, অডিও বা সাধারণ ফাইল পাঠান।",
  retryable: false,
});

export const isChatAttachmentTooLarge = (size: number | null | undefined) =>
  typeof size === "number" && size > CHAT_ATTACHMENT_MAX_BYTES;

export const getChatAttachmentTooLargeFailure = () => tooLargeFailure();

export const classifyChatUploadError = (error: unknown): ChatUploadFailure => {
  const candidate = error as {
    data?: { code?: unknown };
    shape?: { data?: { code?: unknown } };
    message?: unknown;
  };
  const code = candidate?.data?.code ?? candidate?.shape?.data?.code;
  const message = typeof candidate?.message === "string" ? candidate.message : "";

  if (code === "PAYLOAD_TOO_LARGE") return tooLargeFailure();
  if (code === "BAD_REQUEST") return unsupportedFileFailure();
  if (code === "INTERNAL_SERVER_ERROR") {
    return {
      kind: "server",
      label: "সার্ভার সমস্যা",
      message: "সার্ভারে সমস্যা হয়েছে। কিছুক্ষণ পরে পুনরায় চেষ্টা করুন।",
      retryable: true,
    };
  }
  if (/(permission|denied|not granted|e_permissions_missing|not authorized)/i.test(message)) {
    return {
      kind: "permission",
      label: "অনুমতির সমস্যা",
      message: "ফাইল অ্যাক্সেসের অনুমতি নেই। সেটিংস থেকে অনুমতি দিয়ে আবার ফাইল বেছে নিন।",
      retryable: false,
    };
  }
  if (/(network|fetch|internet|offline|timeout|timed out|connection)/i.test(message)) {
    return {
      kind: "network",
      label: "নেটওয়ার্ক সমস্যা",
      message: "ইন্টারনেট সংযোগে সমস্যা হয়েছে। সংযোগ ফিরলে পুনরায় চেষ্টা করুন।",
      retryable: true,
    };
  }
  if (/(storage presign|storage upload|server)/i.test(message)) {
    return {
      kind: "server",
      label: "সার্ভার সমস্যা",
      message: "সার্ভারে সমস্যা হয়েছে। কিছুক্ষণ পরে পুনরায় চেষ্টা করুন।",
      retryable: true,
    };
  }
  if (/(no such file|file.*not.*found|could not be read|unable to read|enoent)/i.test(message)) {
    return {
      kind: "file",
      label: "ফাইল পড়া যায়নি",
      message: "ফাইলটি পড়া যায়নি। অন্য একটি ফাইল বেছে নিন।",
      retryable: false,
    };
  }
  return {
    kind: "unknown",
    label: "আপলোড সমস্যা",
    message: "সংযুক্তিটি পাঠানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।",
    retryable: true,
  };
};
