/** Native WebRTC globals are not needed in the browser preview. */
export {};
