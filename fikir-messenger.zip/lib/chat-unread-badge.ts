const bengaliDigits = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

export function formatUnreadBadgeCount(value: number) {
  const count = Math.max(0, Math.trunc(value));
  if (count === 0) return "";
  if (count > 99) return "৯৯+";
  return String(count).replace(/\d/g, (digit) => bengaliDigits[Number(digit)]);
}

export function getUnreadConversationTotal(items: Array<{ unreadCount: number }> | undefined) {
  return (items ?? []).reduce((total, item) => total + Math.max(0, item.unreadCount), 0);
}
