export type AdminDashboardUser = {
  id: number;
  name: string | null;
  username: string | null;
  email: string | null;
  isOnline?: boolean;
};

export type AdminDashboardFilter = "all" | "regular" | "blocked" | "banned";
export type AdminActivitySort = "recent" | "oldest";

/** Formats the server-recorded presence timestamp for the founder dashboard. */
export function formatAdminLastActive(value: Date | string | null | undefined) {
  if (!value) return "উপস্থিতির তথ্য নেই";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "উপস্থিতির তথ্য নেই";
  return date.toLocaleString("bn-BD", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Dhaka",
  });
}

export function getAdminUserStatus(userId: number, bannedUserIds: Set<number>, blockedUserIds: Set<number>) {
  const isBanned = bannedUserIds.has(userId);
  const isBlocked = blockedUserIds.has(userId);
  return { isBanned, isBlocked, isRegular: !isBanned && !isBlocked };
}

export function filterAdminDashboardUsers<T extends AdminDashboardUser>(
  users: T[],
  currentUserId: number,
  query: string,
  filter: AdminDashboardFilter,
  bannedUserIds: Set<number>,
  blockedUserIds: Set<number>,
) {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  return users.filter((user) => {
    if (user.id === currentUserId) return false;
    const matchesText = !normalizedQuery || [user.name, user.username, user.email]
      .some((value) => value?.toLocaleLowerCase().includes(normalizedQuery));
    const { isBanned, isBlocked, isRegular } = getAdminUserStatus(user.id, bannedUserIds, blockedUserIds);
    const matchesFilter = filter === "all" || (filter === "banned" && isBanned) || (filter === "blocked" && isBlocked) || (filter === "regular" && isRegular);
    return matchesText && matchesFilter;
  });
}

/** Returns a new list ordered by the most recently (or longest ago) active users. */
export function sortAdminDashboardUsers<T extends AdminDashboardUser & { lastActiveAt?: Date | string | null }>(
  users: T[],
  sort: AdminActivitySort,
) {
  const timestampFor = (value: Date | string | null | undefined) => {
    if (!value) return null;
    const timestamp = new Date(value).getTime();
    return Number.isNaN(timestamp) ? null : timestamp;
  };

  return [...users].sort((first, second) => {
    const firstIsOnline = first.isOnline === true;
    const secondIsOnline = second.isOnline === true;
    if (firstIsOnline !== secondIsOnline) return firstIsOnline ? -1 : 1;
    const firstTimestamp = timestampFor(first.lastActiveAt);
    const secondTimestamp = timestampFor(second.lastActiveAt);
    if (firstTimestamp === null && secondTimestamp === null) return first.id - second.id;
    if (firstTimestamp === null) return 1;
    if (secondTimestamp === null) return -1;
    const difference = sort === "recent"
      ? secondTimestamp - firstTimestamp
      : firstTimestamp - secondTimestamp;
    return difference || first.id - second.id;
  });
}
