export type GroupReceipt = {
  seenCount: number;
  recipientCount: number;
};

export type PresenceSnapshot = {
  online: boolean;
  lastSeenAt: Date | string | null;
};

export function getDirectReceiptLabel(status: string): string {
  if (status === "seen") return "দেখেছে ✓✓";
  if (status === "delivered") return "পৌঁছেছে ✓✓";
  return "পাঠানো ✓";
}

export function getGroupReceiptLabel(receipt: GroupReceipt | null | undefined): string {
  if (!receipt || receipt.recipientCount <= 0) return "পাঠানো হয়েছে";
  return `দেখেছে ${receipt.seenCount}/${receipt.recipientCount}`;
}

export function getPresenceLabel(presence: PresenceSnapshot | null | undefined): string {
  if (presence?.online) return "● অনলাইন";
  if (!presence?.lastSeenAt) return "অফলাইন";

  const lastSeen = new Date(presence.lastSeenAt);
  if (Number.isNaN(lastSeen.getTime())) return "অফলাইন";
  return `সর্বশেষ দেখা ${lastSeen.toLocaleString("bn-BD", { dateStyle: "short", timeStyle: "short" })}`;
}
