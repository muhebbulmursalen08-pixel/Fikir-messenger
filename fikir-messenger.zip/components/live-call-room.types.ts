export type LiveKitConnection = {
  token: string;
  url: string;
  roomName: string;
};
