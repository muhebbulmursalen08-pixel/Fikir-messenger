import { trpc } from "@/lib/trpc";
import type { User } from "@/lib/_core/auth";
import { filterAdminDashboardUsers, formatAdminLastActive, getAdminUserStatus, sortAdminDashboardUsers, type AdminActivitySort } from "@/lib/admin-dashboard";
import { LiveCallConnecting, LiveCallRoom, type LiveKitConnection } from "@/components/live-call-room";
import { getDirectReceiptLabel, getGroupReceiptLabel, getPresenceLabel, type GroupReceipt, type PresenceSnapshot } from "@/lib/chat-status";
import { classifyChatUploadError, getChatAttachmentTooLargeFailure, isChatAttachmentTooLarge, type ChatUploadFailure } from "@/lib/chat-upload-failures";
import { getChatAttachmentFilename, getChatAttachmentMimeType, type SavableChatAttachmentKind } from "@/lib/chat-attachment-saving";
import { getOfflineInboxMessageCount, getOfflineInboxSenderNames } from "@/lib/offline-inbox";
import { formatUnreadBadgeCount, getUnreadConversationTotal } from "@/lib/chat-unread-badge";
import { getRecentMessagePreview, matchesRecentConversationSearch } from "@/lib/recent-chat";
import { consumePendingPushNavigation, subscribePushNavigation, type PushDestination } from "@/lib/push-navigation";
import { configureAndroidNotificationChannels, DEFAULT_NOTIFICATION_SETTINGS, getNotificationSettings, saveNotificationSettings, type NotificationSettings } from "@/lib/notification-settings";
import { getApiBaseUrl } from "@/constants/oauth";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Clipboard from "expo-clipboard";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import * as MediaLibrary from "expo-media-library";
import * as Notifications from "expo-notifications";
import * as Sharing from "expo-sharing";
import { createAudioPlayer, RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  AppState,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

type CommunitySection = "home" | "profile" | "member-profile" | "settings" | "people" | "groups" | "updates" | "admin" | "calls" | "chats" | "social" | "direct" | "group";
type ProfileRow = {
  id: number;
  name: string | null;
  username: string | null;
  avatarUrl: string | null;
  bio: string | null;
  role: string | null;
};
type GroupRow = {
  id: number;
  name: string;
  handle: string;
  description: string | null;
  privacy: "public" | "private" | "approval";
  isAnnouncementsOnly: boolean;
};
type MyGroupRow = {
  group: GroupRow;
  membership: { role: "owner" | "admin" | "moderator" | "member"; state: "active" | "pending" | "invited" | "removed" };
};
type MessageRow = {
  message: { id: number; senderId: number; body: string; kind: string; attachmentUrl: string | null; status: string; editedAt?: Date | string | null; deletedAt?: Date | string | null; createdAt: Date | string };
  sender: { id: number; name: string | null; username: string | null; avatarUrl: string | null };
  receipt?: GroupReceipt | null;
};
type MemberRow = {
  membership: { userId: number; role: "owner" | "admin" | "moderator" | "member"; state: "active" | "pending" | "invited" | "removed" };
  user: { id: number; name: string | null; username: string | null; avatarUrl: string | null; role: string | null };
};
type CallSessionRow = {
  id: number;
  initiatorId: number;
  recipientId: number | null;
  groupId: number | null;
  kind: "audio" | "video";
  status: "requested" | "active" | "declined" | "ended" | "missed";
  createdAt: Date | string;
};
type OfflineMessageRow = {
  id: number;
  senderId: number;
  senderName: string | null;
  senderUsername: string | null;
  createdAt: Date | string;
};
type MissedCallRow = {
  id: number;
  kind: "audio" | "video";
  createdAt: Date | string;
  missedAt: Date | string | null;
  initiatorId: number;
  initiatorName: string | null;
  initiatorUsername: string | null;
};
type OfflineInboxSummary = {
  directMessages: OfflineMessageRow[];
  groupMessages: (OfflineMessageRow & { groupId: number; groupName: string })[];
  missedCalls: MissedCallRow[];
};
type UnreadChatBadgeSummary = {
  direct: { userId: number; name: string | null; username: string | null; avatarUrl: string | null; unreadCount: number }[];
  groups: { groupId: number; name: string; handle: string; unreadCount: number }[];
};
type UnreadChatListRow =
  | { kind: "direct"; id: number; name: string | null; username: string | null; avatarUrl: string | null; unreadCount: number }
  | { kind: "group"; id: number; name: string; handle: string; unreadCount: number };
type RecentConversationRow =
  | {
    kind: "direct";
    id: number;
    name: string | null;
    username: string | null;
    avatarUrl: string | null;
    online: boolean;
    unreadCount: number;
    lastMessage: { body: string; kind: string; attachmentUrl: string | null; senderId: number; createdAt: Date | string };
  }
  | {
    kind: "group";
    id: number;
    name: string;
    handle: string;
    unreadCount: number;
    lastMessage: { body: string; kind: string; attachmentUrl: string | null; senderId: number; createdAt: Date | string };
  };
type ActiveLiveCall = {
  session: CallSessionRow;
  title: string;
};
type OutgoingCall = { sessionId: number; kind: "audio" | "video"; peerName: string };
type FounderUpdateRow = {
  update: {
    id: number;
    authorId: number;
    body: string;
    imageUrls: string[];
    voiceUrl: string | null;
    voiceDurationSeconds: number | null;
    linkUrl: string | null;
    status: "draft" | "published";
    scheduledFor: Date | string | null;
    publishedAt: Date | string | null;
    createdAt: Date | string;
    updatedAt: Date | string;
    reactionCounts: { emoji: string; count: number }[];
    myReaction: string | null;
    viewCount: number;
  };
  author: ProfileRow;
};
type FounderUpdateReactor = { userId: number; name: string | null; username: string | null; avatarUrl: string | null; emoji: string; reactedAt: Date | string };
type FounderUpdateViewer = { userId: number; name: string | null; username: string | null; avatarUrl: string | null; viewedAt: Date | string };
type LocalUpdateImage = { uri: string; base64: string | null; contentType: "image/jpeg" | "image/png" | "image/webp" };
type SocialPostRow = { post: { id: number; authorId: number; body: string; imageUrls: string[]; voiceUrl: string | null; voiceDurationSeconds: number | null; linkUrl: string | null; createdAt: Date | string; reactionCounts: { emoji: string; count: number }[]; myReaction: string | null }; author: ProfileRow };
type ChatAttachmentKind = "image" | "file" | "voice";
type ChatUploadTarget = { type: "direct" | "group"; id: number };
type RetryableChatUpload = { loadBase64: () => Promise<string>; contentType: string; filename: string; kind: ChatAttachmentKind; target: ChatUploadTarget; body: string; size?: number };
type ChatUploadStage = { id: number; kind: ChatAttachmentKind; filename: string; phase: "preparing" | "uploading" | "sending" | "cancelling" | "failed"; errorMessage?: string; failure?: ChatUploadFailure };
type AdminUserRow = { id: number; name: string | null; username: string | null; avatarUrl: string | null; email: string | null; role: string | null; createdAt: Date | string; lastSignedIn: Date | string | null; lastActiveAt: Date | string | null; isOnline: boolean };
type BanRow = { ban: { userId: number; reason: string; bannedAt: Date | string }; user: AdminUserRow };
type ReportRow = { id: number; reporterId: number; reportedUserId: number; reason: string; status: "open" | "reviewed" | "resolved"; createdAt: Date | string };
type AdminUsageStats = { totalUsers: number; signedInLast24Hours: number; onlineNow: number; bannedCount: number; blockedByFounderCount: number; openReportCount: number };
type AdminFilter = "all" | "regular" | "blocked" | "banned";

const formatTime = (value: Date | string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleString("bn-BD", { dateStyle: "short", timeStyle: "short" });
};

const formatDate = (value: Date | string | null | undefined) => {
  if (!value) return "তথ্য নেই";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "তথ্য নেই" : date.toLocaleDateString("bn-BD", { dateStyle: "medium" });
};

const displayName = (person: { name: string | null | undefined; username?: string | null | undefined }) => person.name || person.username || "ফিকির ব্যবহারকারী";

const getMediaUrl = (value: string) => {
  if (/^(https?:|file:|data:)/i.test(value)) return value;
  const apiBase = getApiBaseUrl();
  return apiBase ? `${apiBase}${value}` : value;
};

const SUPPORTED_CHAT_FILE_MIME_TYPES = [
  "application/pdf",
  "text/plain",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/zip",
];

export function OnlineCommunity({ user, onBack }: { user: User; onBack: () => void }) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder);
  const attachmentAudioPlayer = useRef<ReturnType<typeof createAudioPlayer> | null>(null);
  const chatUploadSequence = useRef(0);
  const cancelledChatUploadId = useRef<number | null>(null);
  const failedChatUpload = useRef<RetryableChatUpload | null>(null);
  const viewedFounderUpdateIds = useRef(new Set<number>());
  const [section, setSection] = useState<CommunitySection>("home");
  const [search, setSearch] = useState("");
  const [homeSearch, setHomeSearch] = useState("");
  const [activePeer, setActivePeer] = useState<ProfileRow | null>(null);
  const [activeGroup, setActiveGroup] = useState<GroupRow | null>(null);
  const [selectedMember, setSelectedMember] = useState<ProfileRow | null>(null);
  const [messageText, setMessageText] = useState("");
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [isVoicePaused, setIsVoicePaused] = useState(false);
  const [chatUpload, setChatUpload] = useState<ChatUploadStage | null>(null);
  const [replyingTo, setReplyingTo] = useState<MessageRow | null>(null);
  const [editingMessage, setEditingMessage] = useState<MessageRow | null>(null);
  const [profileName, setProfileName] = useState(user.name ?? "");
  const [profileUsername, setProfileUsername] = useState(user.username ?? "");
  const [profileBio, setProfileBio] = useState(user.bio ?? "");
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(DEFAULT_NOTIFICATION_SETTINGS);
  const [isNotificationSettingsLoading, setIsNotificationSettingsLoading] = useState(true);
  const [savingNotificationSetting, setSavingNotificationSetting] = useState<keyof NotificationSettings | null>(null);
  const [notificationPermissionStatus, setNotificationPermissionStatus] = useState<string>("unknown");
  const [groupName, setGroupName] = useState("");
  const [groupHandle, setGroupHandle] = useState("");
  const [groupDescription, setGroupDescription] = useState("");
  const [groupPrivacy, setGroupPrivacy] = useState<"public" | "approval" | "private">("public");
  const [announcementsOnly, setAnnouncementsOnly] = useState(false);
  const [groupSettingsName, setGroupSettingsName] = useState("");
  const [groupSettingsDescription, setGroupSettingsDescription] = useState("");
  const [groupSettingsPrivacy, setGroupSettingsPrivacy] = useState<"public" | "approval" | "private">("public");
  const [groupSettingsAnnouncementsOnly, setGroupSettingsAnnouncementsOnly] = useState(false);
  const [memberSearch, setMemberSearch] = useState("");
  const [activeLiveCall, setActiveLiveCall] = useState<ActiveLiveCall | null>(null);
  const [outgoingCall, setOutgoingCall] = useState<OutgoingCall | null>(null);
  const [liveKitConnection, setLiveKitConnection] = useState<LiveKitConnection | null>(null);
  const [isPreparingLiveCall, setIsPreparingLiveCall] = useState(false);
  const [liveCallProblem, setLiveCallProblem] = useState<string | null>(null);
  const [founderUpdateBody, setFounderUpdateBody] = useState("");
  const [founderUpdateLink, setFounderUpdateLink] = useState("");
  const [scheduledForText, setScheduledForText] = useState("");
  const [localUpdateImages, setLocalUpdateImages] = useState<LocalUpdateImage[]>([]);
  const [retainedUpdateImages, setRetainedUpdateImages] = useState<string[]>([]);
  const [updateVoiceUri, setUpdateVoiceUri] = useState<string | null>(null);
  const [updateVoiceBase64, setUpdateVoiceBase64] = useState<string | null>(null);
  const [updateVoiceDurationSeconds, setUpdateVoiceDurationSeconds] = useState<number | null>(null);
  const [retainedUpdateVoiceUrl, setRetainedUpdateVoiceUrl] = useState<string | null>(null);
  const [isRecordingUpdateVoice, setIsRecordingUpdateVoice] = useState(false);
  const [isUpdateVoicePaused, setIsUpdateVoicePaused] = useState(false);
  const [editingFounderUpdate, setEditingFounderUpdate] = useState<FounderUpdateRow | null>(null);
  const [selectedReactionUpdate, setSelectedReactionUpdate] = useState<FounderUpdateRow | null>(null);
  const [selectedViewerUpdate, setSelectedViewerUpdate] = useState<FounderUpdateRow | null>(null);
  const [pendingReactionUpdateId, setPendingReactionUpdateId] = useState<number | null>(null);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);
  const [moderationTarget, setModerationTarget] = useState<ProfileRow | null>(null);
  const [reportReason, setReportReason] = useState("");
  const [selectedAdminUser, setSelectedAdminUser] = useState<AdminUserRow | null>(null);
  const [banReason, setBanReason] = useState("");
  const [adminSearch, setAdminSearch] = useState("");
  const [adminFilter, setAdminFilter] = useState<AdminFilter>("all");
  const [adminActivitySort, setAdminActivitySort] = useState<AdminActivitySort>("recent");
  const [adminBlockTarget, setAdminBlockTarget] = useState<{ user: AdminUserRow; mode: "block" | "unblock" } | null>(null);
  const [showMissedCallInbox, setShowMissedCallInbox] = useState(false);
  const [socialBody, setSocialBody] = useState("");
  const [socialLink, setSocialLink] = useState("");
  const [socialImageUrls, setSocialImageUrls] = useState<string[]>([]);
  const [editingSocialPostId, setEditingSocialPostId] = useState<number | null>(null);

  const profile = trpc.profile.me.useQuery();
  useEffect(() => {
    let active = true;
    void Promise.all([getNotificationSettings(), Notifications.getPermissionsAsync()])
      .then(([settings, permission]) => {
        if (!active) return;
        setNotificationSettings(settings);
        setNotificationPermissionStatus(permission.status);
      })
      .finally(() => {
        if (active) setIsNotificationSettingsLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const updateNotificationSetting = async (key: keyof NotificationSettings, value: boolean) => {
    const nextSettings = { ...notificationSettings, [key]: value };
    setNotificationSettings(nextSettings);
    setSavingNotificationSetting(key);
    try {
      await saveNotificationSettings(nextSettings);
      await configureAndroidNotificationChannels(nextSettings, { resetExistingChannels: true });
    } catch (error) {
      setNotificationSettings(notificationSettings);
      console.warn("[Notification settings] Preference could not be saved:", error);
      Alert.alert("সেটিংস সংরক্ষণ হয়নি", "পছন্দটি ডিভাইসে রাখা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।");
    } finally {
      setSavingNotificationSetting(null);
    }
  };

  const openSystemNotificationSettings = async () => {
    try {
      await Linking.openSettings();
    } catch (error) {
      console.warn("[Notification settings] System settings could not be opened:", error);
      Alert.alert("সেটিংস খোলা যায়নি", "ফোনের Settings > Apps > ফিকির মেসেঞ্জার > Notifications পথটি ব্যবহার করুন।");
    }
  };

  const requestNotificationAccess = async () => {
    try {
      const current = await Notifications.getPermissionsAsync();
      const next = current.status === "granted" ? current : await Notifications.requestPermissionsAsync();
      setNotificationPermissionStatus(next.status);
      if (next.status !== "granted") {
        Alert.alert("বিজ্ঞপ্তির অনুমতি প্রয়োজন", "কল ও বার্তার সতর্কতা পেতে ফোনের অ্যাপ সেটিংসে Notifications চালু করুন।", [
          { text: "এখন নয়", style: "cancel" },
          { text: "সেটিংস খুলুন", onPress: () => void openSystemNotificationSettings() },
        ]);
      } else {
        Alert.alert("অনুমতি চালু আছে", "এই ডিভাইসে ফিকির মেসেঞ্জারের বিজ্ঞপ্তি গ্রহণের অনুমতি চালু আছে।");
      }
    } catch (error) {
      console.warn("[Notification settings] Permission check failed:", error);
      Alert.alert("অনুমতি যাচাই হয়নি", "অনুগ্রহ করে ফোনের Settings থেকে বিজ্ঞপ্তি পরীক্ষা করুন।");
    }
  };

  const isFounder = profile.data?.role === "founder" || user.role === "founder";
  const myGroups = trpc.groups.mine.useQuery();
  const discoverGroups = trpc.groups.discover.useQuery();
  const founder = trpc.founder.profile.useQuery();
  const founderUpdates = trpc.founder.updates.list.useQuery(undefined, {
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });
  const founderUpdateReactors = trpc.founder.updates.reactors.useQuery(
    { updateId: selectedReactionUpdate?.update.id ?? 1 },
    { enabled: Boolean(selectedReactionUpdate), refetchOnWindowFocus: true },
  );
  const founderUpdateViewers = trpc.founder.updates.viewers.useQuery(
    { updateId: selectedViewerUpdate?.update.id ?? 1 },
    { enabled: Boolean(selectedViewerUpdate) && isFounder, refetchOnWindowFocus: true },
  );
  const founderUpdateStats = trpc.founder.updates.stats.useQuery(undefined, { enabled: isFounder });
  const socialFeed = trpc.posts.feed.useQuery(undefined, { refetchInterval: 20_000, refetchOnReconnect: true, refetchOnWindowFocus: true });
  const followingIds = trpc.posts.following.useQuery();
  const adminUsers = trpc.admin.users.useQuery(undefined, { enabled: isFounder });
  const adminUsage = trpc.admin.usageStats.useQuery(undefined, { enabled: isFounder });
  const blockedByMe = trpc.admin.blockedByMe.useQuery(undefined, { enabled: isFounder });
  const adminReports = trpc.admin.reports.useQuery(undefined, { enabled: isFounder });
  const bannedUsers = trpc.admin.banned.useQuery(undefined, { enabled: isFounder });
  const searchedPeople = trpc.profile.search.useQuery(
    { query: search.trim() || "_" },
    { enabled: search.trim().length > 0 },
  );
  const homeSearchedPeople = trpc.profile.search.useQuery(
    { query: homeSearch.trim() || "_" },
    { enabled: homeSearch.trim().length > 0 },
  );
  const searchedGroupMembers = trpc.profile.search.useQuery(
    { query: memberSearch.trim() || "_" },
    { enabled: Boolean(activeGroup) && memberSearch.trim().length > 0 },
  );
  const directMessages = trpc.messages.direct.useQuery(
    { peerId: activePeer?.id ?? 1 },
    { enabled: Boolean(activePeer), refetchInterval: 3_000, refetchOnReconnect: true, refetchOnWindowFocus: true },
  );
  const incomingActivity = trpc.activity.incoming.useQuery(
    { actorId: activePeer?.id ?? user.id, groupId: activeGroup?.id ?? null },
    { enabled: Boolean(activePeer || activeGroup), refetchInterval: 2_000, refetchOnReconnect: true },
  );
  const recentConversations = trpc.messages.recent.useQuery(undefined, {
    refetchInterval: 30_000,
    refetchOnReconnect: true,
    refetchOnWindowFocus: true,
  });
  const { refetch: refetchRecentConversations } = recentConversations;
  const groupMessages = trpc.messages.group.useQuery(
    { groupId: activeGroup?.id ?? 1 },
    { enabled: Boolean(activeGroup), refetchInterval: 3_000, refetchOnReconnect: true, refetchOnWindowFocus: true },
  );
  const groupMembers = trpc.groups.members.useQuery(
    { groupId: activeGroup?.id ?? 1 },
    { enabled: Boolean(activeGroup) },
  );
  const groupPresenceIds = useMemo(
    () => ((groupMembers.data ?? []) as unknown as MemberRow[])
      .filter((entry) => entry.membership.state === "active" && entry.user.id !== user.id)
      .map((entry) => entry.user.id),
    [groupMembers.data, user.id],
  );
  const peerPresence = trpc.presence.byUsers.useQuery(
    { userIds: [activePeer?.id ?? user.id] },
    { enabled: Boolean(activePeer), refetchInterval: 15_000 },
  );
  const groupPresence = trpc.presence.byUsers.useQuery(
    { userIds: groupPresenceIds.length > 0 ? groupPresenceIds : [user.id] },
    { enabled: Boolean(activeGroup) && groupPresenceIds.length > 0, refetchInterval: 15_000 },
  );
  const directCalls = trpc.calls.mine.useQuery(undefined, {
    refetchInterval: 3_000,
    refetchOnReconnect: true,
    refetchOnWindowFocus: true,
  });
  const { refetch: refetchDirectCalls } = directCalls;
  const offlineInbox = trpc.offline.summary.useQuery(undefined, {
    refetchInterval: 30_000,
    refetchOnReconnect: true,
    refetchOnWindowFocus: true,
  });
  const unreadChatBadges = trpc.offline.chatBadges.useQuery(undefined, {
    refetchInterval: 15_000,
    refetchOnReconnect: true,
    refetchOnWindowFocus: true,
  });
  const missedCallHistory = trpc.offline.listMissedCalls.useQuery(undefined, {
    enabled: true,
    refetchInterval: 30_000,
    refetchOnReconnect: true,
    refetchOnWindowFocus: true,
  });
  const { refetch: refetchOfflineInbox } = offlineInbox;
  const { refetch: refetchUnreadChatBadges } = unreadChatBadges;
  const groupCalls = trpc.calls.group.useQuery(
    { groupId: activeGroup?.id ?? 1 },
    { enabled: Boolean(activeGroup) },
  );
  const trpcUtils = trpc.useUtils();
  const offlineSummary = offlineInbox.data as OfflineInboxSummary | undefined;
  const unreadChatSummary = unreadChatBadges.data as UnreadChatBadgeSummary | undefined;
  const unreadChatTotal = getUnreadConversationTotal([
    ...(unreadChatSummary?.direct ?? []),
    ...(unreadChatSummary?.groups ?? []),
  ]);
  const unreadChatRows = useMemo<UnreadChatListRow[]>(() => [
    ...(unreadChatSummary?.direct ?? []).map((item) => ({ kind: "direct" as const, id: item.userId, name: item.name, username: item.username, avatarUrl: item.avatarUrl, unreadCount: item.unreadCount })),
    ...(unreadChatSummary?.groups ?? []).map((item) => ({ kind: "group" as const, id: item.groupId, name: item.name, handle: item.handle, unreadCount: item.unreadCount })),
  ], [unreadChatSummary]);
  const recentConversationRows = useMemo(
    () => (recentConversations.data ?? []) as unknown as RecentConversationRow[],
    [recentConversations.data],
  );
  const filteredRecentConversationRows = useMemo(
    () => recentConversationRows.filter((conversation) => {
      const preview = getRecentMessagePreview({
        body: conversation.lastMessage.body,
        kind: conversation.lastMessage.kind as "text" | "image" | "file" | "voice",
      });
      return matchesRecentConversationSearch({
        name: conversation.name,
        username: conversation.kind === "direct" ? conversation.username : conversation.handle,
        preview,
      }, homeSearch);
    }),
    [homeSearch, recentConversationRows],
  );
  const homeSearchPeopleRows = useMemo(
    () => ((homeSearchedPeople.data ?? []) as unknown as ProfileRow[]).filter((person) => person.id !== user.id),
    [homeSearchedPeople.data, user.id],
  );
  const offlineMessageCount = getOfflineInboxMessageCount(offlineSummary);
  const offlineSenderNames = useMemo(() => getOfflineInboxSenderNames(offlineSummary), [offlineSummary]);

  const uploadChatAttachment = trpc.chat.uploadAttachment.useMutation({
    onError: (error) => Alert.alert("সংযুক্তি আপলোড হয়নি", error.message),
  });
  const setActivity = trpc.activity.set.useMutation();
  const clearActivity = trpc.activity.clear.useMutation();
  const createSocialPost = trpc.posts.create.useMutation({
    onSuccess: () => { setSocialBody(""); setSocialLink(""); setSocialImageUrls([]); void socialFeed.refetch(); Alert.alert("পোস্ট প্রকাশিত", "সবার ফিকিরে আপনার পোস্ট দেখা যাচ্ছে।"); },
    onError: (error) => Alert.alert("পোস্ট প্রকাশ হয়নি", error.message),
  });
  const editSocialPost = trpc.posts.edit.useMutation({ onSuccess: () => { setEditingSocialPostId(null); setSocialBody(""); setSocialLink(""); void socialFeed.refetch(); Alert.alert("পোস্ট সম্পাদিত", "আপনার পরিবর্তন সংরক্ষণ হয়েছে।"); }, onError: (error) => Alert.alert("পোস্ট সম্পাদনা হয়নি", error.message) });
  const deleteSocialPost = trpc.posts.delete.useMutation({ onSuccess: () => void socialFeed.refetch(), onError: (error) => Alert.alert("পোস্ট মুছা হয়নি", error.message) });
  const reactSocialPost = trpc.posts.react.useMutation({ onSuccess: () => void socialFeed.refetch(), onError: (error) => Alert.alert("প্রতিক্রিয়া সংরক্ষণ হয়নি", error.message) });
  const followSocialUser = trpc.posts.follow.useMutation({ onSuccess: () => void followingIds.refetch(), onError: (error) => Alert.alert("ফলো পরিবর্তন হয়নি", error.message) });

  useEffect(() => {
    if (!activePeer || section !== "direct") return;
    if (!messageText.trim()) {
      clearActivity.mutate({ recipientId: activePeer.id, groupId: null });
      return;
    }
    setActivity.mutate({ recipientId: activePeer.id, groupId: null, activity: "typing" });
    const timer = setTimeout(() => clearActivity.mutate({ recipientId: activePeer.id, groupId: null }), 4_000);
    return () => clearTimeout(timer);
  }, [activePeer, clearActivity, messageText, section, setActivity]);

  const markMissedCallsSeen = trpc.offline.markMissedCallsSeen.useMutation({
    onSuccess: () => {
      void offlineInbox.refetch();
      void missedCallHistory.refetch();
    },
    onError: (error) => Alert.alert("মিসড কল হালনাগাদ হয়নি", error.message),
  });
  const deleteMissedCall = trpc.offline.deleteMissedCall.useMutation({
    onSuccess: (result) => {
      if (!result.success) {
        Alert.alert("কলটি পাওয়া যায়নি", "এই মিসড কলটি হয়তো আগে থেকেই মুছে ফেলা হয়েছে।");
      }
      void offlineInbox.refetch();
      void missedCallHistory.refetch();
    },
    onError: (error) => Alert.alert("মিসড কল মুছা যায়নি", error.message),
  });
  const clearMissedCallHistory = trpc.offline.clearMissedCallHistory.useMutation({
    onSuccess: () => {
      void offlineInbox.refetch();
      void missedCallHistory.refetch();
    },
    onError: (error) => Alert.alert("ইতিহাস পরিষ্কার করা যায়নি", error.message),
  });

  const profileUpdate = trpc.profile.update.useMutation({
    onSuccess: () => {
      Alert.alert("প্রোফাইল সংরক্ষিত", "আপনার নাম, ইউজারনেম ও পরিচিতি সংরক্ষণ করা হয়েছে।");
      void profile.refetch();
      setSection("home");
    },
    onError: (error) => Alert.alert("প্রোফাইল সংরক্ষণ হয়নি", error.message),
  });
  const createGroup = trpc.groups.create.useMutation({
    onSuccess: (created) => {
      if (created) setActiveGroup(created as GroupRow);
      void myGroups.refetch();
      void discoverGroups.refetch();
      setSection("group");
    },
    onError: (error) => Alert.alert("গ্রুপ তৈরি হয়নি", error.message),
  });
  const joinGroup = trpc.groups.join.useMutation({
    onSuccess: () => {
      void myGroups.refetch();
      void discoverGroups.refetch();
      Alert.alert("গ্রুপ অনুরোধ", "আপনার যোগদানের অনুরোধ পাঠানো হয়েছে।");
    },
    onError: (error) => Alert.alert("যোগ দেওয়া সম্ভব হয়নি", error.message),
  });
  const sendDirect = trpc.messages.sendDirect.useMutation({
    onSuccess: () => {
      setMessageText("");
      setReplyingTo(null);
      void directMessages.refetch();
      void refetchRecentConversations();
      void refetchUnreadChatBadges();
    },
    onError: (error) => Alert.alert("বার্তা পাঠানো হয়নি", error.message),
  });
  const { mutate: heartbeat } = trpc.presence.heartbeat.useMutation();
  const { mutate: markOffline } = trpc.presence.offline.useMutation();
  const sendGroup = trpc.messages.sendGroup.useMutation({
    onSuccess: () => {
      setMessageText("");
      setReplyingTo(null);
      void groupMessages.refetch();
      void refetchRecentConversations();
      void refetchUnreadChatBadges();
    },
    onError: (error) => Alert.alert("গ্রুপ বার্তা পাঠানো হয়নি", error.message),
  });
  const createFounderUpdate = trpc.founder.updates.create.useMutation({
    onSuccess: () => {
      clearFounderUpdateComposer();
      void founderUpdates.refetch();
      void founderUpdateStats.refetch();
      Alert.alert("খসড়া সংরক্ষিত", "প্রকাশ করার আগে প্রতিষ্ঠাতা ড্যাশবোর্ড বা এই ফিড থেকে আবার দেখে নিতে পারবেন।");
    },
    onError: (error) => Alert.alert("খসড়া সংরক্ষণ হয়নি", error.message),
  });
  const editFounderUpdate = trpc.founder.updates.edit.useMutation({
    onSuccess: () => {
      clearFounderUpdateComposer();
      void founderUpdates.refetch();
      void founderUpdateStats.refetch();
      Alert.alert("আপডেট সম্পাদিত", "আপনার পরিবর্তন সংরক্ষণ করা হয়েছে।");
    },
    onError: (error) => Alert.alert("আপডেট সম্পাদনা হয়নি", error.message),
  });
  const publishFounderUpdate = trpc.founder.updates.publish.useMutation({
    onSuccess: () => {
      void founderUpdates.refetch();
      void founderUpdateStats.refetch();
      Alert.alert("আপডেট প্রকাশিত", "সকল ব্যবহারকারী এখন এটি দেখতে পারবেন এবং উপযুক্ত ডিভাইসে বিজ্ঞপ্তি পাবেন।");
    },
    onError: (error) => Alert.alert("আপডেট প্রকাশ হয়নি", error.message),
  });
  const deleteFounderUpdate = trpc.founder.updates.delete.useMutation({
    onSuccess: () => {
      clearFounderUpdateComposer();
      void founderUpdates.refetch();
      void founderUpdateStats.refetch();
    },
    onError: (error) => Alert.alert("আপডেট মুছে ফেলা হয়নি", error.message),
  });
  const reactToFounderUpdate = trpc.founder.updates.react.useMutation({
    onMutate: (variables) => {
      setPendingReactionUpdateId(variables.updateId);
    },
    onSuccess: (result) => {
      setPendingReactionUpdateId(null);
      void founderUpdates.refetch();
      void founderUpdateReactors.refetch();
      Alert.alert(
        result.active ? "পছন্দ যোগ হয়েছে" : "পছন্দ তুলে নেওয়া হয়েছে",
        result.active ? "আপনার 👍 প্রতিক্রিয়াটি সংরক্ষিত হয়েছে।" : "এই আপডেট থেকে আপনার 👍 প্রতিক্রিয়াটি সরিয়ে দেওয়া হয়েছে।",
      );
    },
    onError: (error) => {
      setPendingReactionUpdateId(null);
      Alert.alert("রিঅ্যাকশন যোগ হয়নি", error.message);
    },
  });
  const { mutate: markFounderUpdateViewed } = trpc.founder.updates.markViewed.useMutation({
    onSuccess: () => {
      void founderUpdates.refetch();
    },
    onError: (_error, variables) => {
      viewedFounderUpdateIds.current.delete(variables.updateId);
    },
  });
  useEffect(() => {
    if (section !== "updates") return;
    const publishedUpdates = ((founderUpdates.data ?? []) as unknown as FounderUpdateRow[])
      .filter((entry) => entry.update.status === "published" && entry.update.authorId !== user.id);
    for (const entry of publishedUpdates) {
      if (viewedFounderUpdateIds.current.has(entry.update.id)) continue;
      viewedFounderUpdateIds.current.add(entry.update.id);
      markFounderUpdateViewed({ updateId: entry.update.id });
    }
  }, [founderUpdates.data, markFounderUpdateViewed, section, user.id]);
  const reportUser = trpc.moderation.reportUser.useMutation({
    onSuccess: () => {
      setModerationTarget(null);
      setReportReason("");
      Alert.alert("রিপোর্ট পাঠানো হয়েছে", "প্রতিষ্ঠাতা-মালিকের পর্যালোচনার জন্য রিপোর্টটি পাঠানো হয়েছে।");
    },
    onError: (error) => Alert.alert("রিপোর্ট পাঠানো হয়নি", error.message),
  });
  const blockUser = trpc.moderation.blockUser.useMutation({
    onSuccess: () => {
      setModerationTarget(null);
      setAdminBlockTarget(null);
      void blockedByMe.refetch();
      void adminUsage.refetch();
      Alert.alert("ব্যবহারকারী ব্লক করা হয়েছে", "এই ব্যবহারকারীর সঙ্গে ব্যক্তিগত বার্তা আদান-প্রদান বন্ধ থাকবে।");
    },
    onError: (error) => Alert.alert("ব্লক করা হয়নি", error.message),
  });
  const unblockUser = trpc.moderation.unblockUser.useMutation({
    onSuccess: () => {
      setAdminBlockTarget(null);
      void blockedByMe.refetch();
      void adminUsage.refetch();
      Alert.alert("ব্লক তুলে দেওয়া হয়েছে", "এই ব্যবহারকারীর সঙ্গে ব্যক্তিগত বার্তা ও কল আবার চালু থাকবে।");
    },
    onError: (error) => Alert.alert("ব্লক তোলা হয়নি", error.message),
  });
  const banUser = trpc.admin.banUser.useMutation({
    onSuccess: () => {
      setSelectedAdminUser(null);
      setBanReason("");
      void bannedUsers.refetch();
      void adminUsers.refetch();
      void adminUsage.refetch();
      Alert.alert("অ্যাকাউন্ট নিষিদ্ধ", "এই ব্যবহারকারী এখন সুরক্ষিত অনলাইন ফিচার ব্যবহার করতে পারবেন না।");
    },
    onError: (error) => Alert.alert("নিষিদ্ধ করা হয়নি", error.message),
  });
  const unbanUser = trpc.admin.unbanUser.useMutation({
    onSuccess: () => {
      void bannedUsers.refetch();
      void adminUsers.refetch();
      void adminUsage.refetch();
      Alert.alert("নিষেধাজ্ঞা উঠেছে", "ব্যবহারকারী আবার সুরক্ষিত ফিচার ব্যবহার করতে পারবেন।");
    },
    onError: (error) => Alert.alert("নিষেধাজ্ঞা তোলা হয়নি", error.message),
  });
  const resolveReport = trpc.admin.resolveReport.useMutation({
    onSuccess: () => {
      void adminReports.refetch();
      void adminUsage.refetch();
    },
    onError: (error) => Alert.alert("রিপোর্টের অবস্থা বদলানো হয়নি", error.message),
  });
  const updateGroup = trpc.groups.settings.useMutation({
    onSuccess: (updated) => {
      if (updated) setActiveGroup(updated as GroupRow);
      void myGroups.refetch();
      void discoverGroups.refetch();
      Alert.alert("গ্রুপ সেটিংস সংরক্ষিত", "গ্রুপের ঘোষণা ও গোপনীয়তার সেটিংস হালনাগাদ হয়েছে।");
    },
    onError: (error) => Alert.alert("সেটিংস সংরক্ষণ হয়নি", error.message),
  });
  const manageMember = trpc.groups.manageMember.useMutation({
    onSuccess: () => {
      void groupMembers.refetch();
    },
    onError: (error) => Alert.alert("সদস্য নিয়ন্ত্রণ হয়নি", error.message),
  });
  const inviteMember = trpc.groups.invite.useMutation({
    onSuccess: () => {
      setMemberSearch("");
      void groupMembers.refetch();
      void myGroups.refetch();
      Alert.alert("সদস্য যোগ করা হয়েছে", "নির্বাচিত ব্যবহারকারী এখন এই গ্রুপের সক্রিয় সদস্য।");
    },
    onError: (error) => Alert.alert("সদস্য যোগ করা হয়নি", error.message),
  });
  const deleteGroup = trpc.groups.delete.useMutation({
    onSuccess: () => {
      void myGroups.refetch();
      void discoverGroups.refetch();
      setActiveGroup(null);
      setSection("groups");
      Alert.alert("গ্রুপ অপসারণ করা হয়েছে", "গ্রুপ, সদস্য, পোস্ট, বার্তা ও কল-সেশন মুছে ফেলা হয়েছে।");
    },
    onError: (error) => Alert.alert("গ্রুপ অপসারণ হয়নি", error.message),
  });
  const editMessage = trpc.messages.edit.useMutation({
    onSuccess: () => {
      setMessageText("");
      setEditingMessage(null);
      void directMessages.refetch();
      void groupMessages.refetch();
    },
    onError: (error) => Alert.alert("বার্তা সম্পাদনা হয়নি", error.message),
  });
  const deleteMessage = trpc.messages.delete.useMutation({
    onSuccess: () => {
      void directMessages.refetch();
      void groupMessages.refetch();
    },
    onError: (error) => Alert.alert("বার্তা মুছে ফেলা হয়নি", error.message),
  });
  const clearDirectChat = trpc.messages.clearDirect.useMutation({
    onSuccess: async () => {
      await directMessages.refetch();
      await refetchRecentConversations();
      await refetchUnreadChatBadges();
      Alert.alert("চ্যাট খালি হয়েছে", "এই ব্যক্তিগত কথোপকথনের সব বার্তা মুছে ফেলা হয়েছে।");
    },
    onError: (error) => Alert.alert("চ্যাট খালি করা যায়নি", error.message),
  });
  const startDirectCall = trpc.calls.startDirect.useMutation({
    onSuccess: (created, variables) => {
      void directCalls.refetch();
      void refetchRecentConversations();
      const target = activePeer ?? selectedMember;
      setOutgoingCall({ sessionId: created.id, kind: variables.kind, peerName: target ? displayName(target) : "প্রাপক" });
    },
    onError: (error) => Alert.alert("কল শুরু হয়নি", error.message),
  });
  const startGroupCall = trpc.calls.startGroup.useMutation({
    onSuccess: (created, variables) => {
      void groupCalls.refetch();
      void refetchRecentConversations();
      if (activeGroup) {
        void prepareLiveCall({ id: created.id, initiatorId: user.id, recipientId: null, groupId: variables.groupId, kind: variables.kind, status: "active", createdAt: new Date() }, activeGroup.name);
      }
    },
    onError: (error) => Alert.alert("গ্রুপ কল শুরু হয়নি", error.message),
  });
  const respondDirectCall = trpc.calls.respondDirect.useMutation({
    onSuccess: () => void directCalls.refetch(),
    onError: (error) => Alert.alert("কল-সেশন হালনাগাদ হয়নি", error.message),
  });
  const endCall = trpc.calls.end.useMutation({
    onSuccess: () => {
      void directCalls.refetch();
      void groupCalls.refetch();
      void refetchRecentConversations();
    },
    onError: (error) => Alert.alert("কল-সেশন শেষ হয়নি", error.message),
  });
  const deleteCallHistoryEntry = trpc.calls.deleteHistoryEntry.useMutation({
    onSuccess: () => void directCalls.refetch(),
    onError: (error) => Alert.alert("কলের ইতিহাস মুছা যায়নি", error.message),
  });
  const clearCallHistory = trpc.calls.clearHistory.useMutation({
    onSuccess: () => {
      void directCalls.refetch();
      Alert.alert("কলের ইতিহাস পরিষ্কার হয়েছে", "সমাপ্ত, প্রত্যাখ্যাত ও মিসড ব্যক্তিগত কলের ইতিহাস মুছে ফেলা হয়েছে।");
    },
    onError: (error) => Alert.alert("কলের ইতিহাস পরিষ্কার করা যায়নি", error.message),
  });

  useEffect(() => {
    const markOnline = () => {
      heartbeat();
      void refetchOfflineInbox();
      void refetchUnreadChatBadges();
      void refetchRecentConversations();
    };
    markOnline();
    const heartbeatTimer = setInterval(markOnline, 25_000);
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active") markOnline();
      else markOffline();
    });
    return () => {
      clearInterval(heartbeatTimer);
      subscription.remove();
      markOffline();
    };
  }, [heartbeat, markOffline, refetchOfflineInbox, refetchRecentConversations, refetchUnreadChatBadges]);

  useEffect(() => {
    if (section !== "direct" && section !== "group") return;
    void refetchUnreadChatBadges();
  }, [directMessages.data, groupMessages.data, refetchUnreadChatBadges, section]);

  const myGroupRows = useMemo(() => (myGroups.data ?? []) as unknown as MyGroupRow[], [myGroups.data]);
  const discoverRows = useMemo(() => (discoverGroups.data ?? []) as unknown as GroupRow[], [discoverGroups.data]);
  const currentMembership = useMemo(
    () => myGroupRows.find((entry) => entry.group.id === activeGroup?.id)?.membership,
    [activeGroup?.id, myGroupRows],
  );
  const canManageActiveGroup = currentMembership?.role === "owner" || currentMembership?.role === "admin";

  const clearFounderUpdateComposer = () => {
    setFounderUpdateBody("");
    setFounderUpdateLink("");
    setScheduledForText("");
    setLocalUpdateImages([]);
    setRetainedUpdateImages([]);
    setUpdateVoiceUri(null);
    setUpdateVoiceBase64(null);
    setUpdateVoiceDurationSeconds(null);
    setRetainedUpdateVoiceUrl(null);
    setIsRecordingUpdateVoice(false);
    setIsUpdateVoicePaused(false);
    setEditingFounderUpdate(null);
  };

  const closeLiveCall = (shouldEndSession = true) => {
    const session = activeLiveCall?.session;
    setActiveLiveCall(null);
    setLiveKitConnection(null);
    setIsPreparingLiveCall(false);
    if (!session || !shouldEndSession) return;
    const mayEndForEveryone = !session.groupId || session.initiatorId === user.id;
    if (mayEndForEveryone) endCall.mutate({ sessionId: session.id });
  };

  const prepareLiveCall = useCallback(async (session: CallSessionRow, title: string) => {
    if (Platform.OS === "web") {
      Alert.alert("মোবাইল development build প্রয়োজন", "বাস্তব অডিও/ভিডিও কল এই ওয়েব প্রিভিউতে চলে না। Android বা iOS development build ইনস্টল করে একই কলটিতে যোগ দিন।");
      return;
    }
    setActiveLiveCall({ session, title });
    setLiveKitConnection(null);
    setLiveCallProblem(null);
    setIsPreparingLiveCall(true);
    try {
      const connection = await trpcUtils.calls.getLivekitToken.fetch({ sessionId: session.id });
      setLiveKitConnection(connection);
    } catch (error) {
      const message = error instanceof Error ? error.message : "কল সংযোগ প্রস্তুত করা যায়নি।";
      setLiveCallProblem(message);
    } finally {
      setIsPreparingLiveCall(false);
    }
  }, [trpcUtils]);

  // Once the recipient accepts, the initiator joins automatically instead of
  // having to open the call inbox and press “যোগ দিন” manually.
  useEffect(() => {
    if (activeLiveCall || isPreparingLiveCall) return;
    const acceptedCall = ((directCalls.data ?? []) as unknown as CallSessionRow[]).find(
      (session) => session.initiatorId === user.id
        && session.status === "active"
        && Date.now() - new Date(session.createdAt).getTime() < 10 * 60 * 1000,
    );
    if (acceptedCall) void prepareLiveCall(acceptedCall, "ব্যক্তিগত কল");
  }, [activeLiveCall, directCalls.data, isPreparingLiveCall, prepareLiveCall, user.id]);

  useEffect(() => {
    if (!outgoingCall) return;
    const session = ((directCalls.data ?? []) as unknown as CallSessionRow[]).find((item) => item.id === outgoingCall.sessionId);
    if (!session) return;
    if (session.status === "active") {
      setOutgoingCall(null);
      return;
    }
    if (session.status === "declined" || session.status === "ended" || session.status === "missed") {
      setOutgoingCall(null);
      Alert.alert(
        session.status === "declined" ? "কল প্রত্যাখ্যান করা হয়েছে" : session.status === "missed" ? "কলের উত্তর পাওয়া যায়নি" : "কল শেষ হয়েছে",
        `${outgoingCall.peerName}-এর কাছে ${outgoingCall.kind === "video" ? "ভিডিও" : "অডিও"} কল সংযুক্ত হয়নি।`,
      );
    }
  }, [directCalls.data, outgoingCall]);

  const cancelOutgoingCall = () => {
    if (!outgoingCall) return;
    endCall.mutate({ sessionId: outgoingCall.sessionId }, { onSettled: () => setOutgoingCall(null) });
  };

  const acceptDirectCall = (session: CallSessionRow) => {
    respondDirectCall.mutate(
      { sessionId: session.id, status: "active" },
      {
        onSuccess: () => {
          void directCalls.refetch();
          void prepareLiveCall({ ...session, status: "active" }, "ব্যক্তিগত কল");
        },
      },
    );
  };

  const openMissedCallInbox = () => {
    setShowMissedCallInbox(true);
    if ((offlineSummary?.missedCalls.length ?? 0) > 0) markMissedCallsSeen.mutate();
  };

  const confirmDeleteMissedCall = (callId: number) => {
    Alert.alert("মিসড কল মুছবেন?", "এটি শুধু আপনার মিসড-কল ইতিহাস থেকে স্থায়ীভাবে মুছে যাবে।", [
      { text: "বাতিল", style: "cancel" },
      { text: "মুছুন", style: "destructive", onPress: () => deleteMissedCall.mutate({ callId }) },
    ]);
  };

  const confirmClearMissedCallHistory = () => {
    const callCount = missedCallHistory.data?.length ?? 0;
    if (!callCount) return;
    Alert.alert("সম্পূর্ণ ইতিহাস মুছবেন?", `${callCount} টি মিসড কলের তথ্য স্থায়ীভাবে মুছে যাবে। এই কাজটি ফিরিয়ে আনা যাবে না।`, [
      { text: "বাতিল", style: "cancel" },
      { text: "সম্পূর্ণ মুছুন", style: "destructive", onPress: () => clearMissedCallHistory.mutate() },
    ]);
  };

  const confirmDeleteCallHistoryEntry = (sessionId: number) => {
    Alert.alert("এই কলের রেকর্ড মুছবেন?", "এটি শুধু আপনার ব্যক্তিগত কল-ইতিহাস থেকে মুছে যাবে। সক্রিয় বা অপেক্ষমাণ কল মুছতে আগে কল শেষ করুন।", [
      { text: "বাতিল", style: "cancel" },
      { text: "মুছুন", style: "destructive", onPress: () => deleteCallHistoryEntry.mutate({ sessionId }) },
    ]);
  };

  const confirmClearCallHistory = (count: number) => {
    if (!count) return;
    Alert.alert("সম্পূর্ণ কল ইতিহাস মুছবেন?", `${count} টি সমাপ্ত, প্রত্যাখ্যাত বা মিসড ব্যক্তিগত কলের রেকর্ড মুছে যাবে। এই কাজটি ফিরিয়ে আনা যাবে না।`, [
      { text: "বাতিল", style: "cancel" },
      { text: "সম্পূর্ণ মুছুন", style: "destructive", onPress: () => clearCallHistory.mutate() },
    ]);
  };

  const callBackMissedCall = async (missedCall: MissedCallRow) => {
    try {
      const person = await trpcUtils.profile.byId.fetch({ userId: missedCall.initiatorId });
      setShowMissedCallInbox(false);
      openDirect(person as ProfileRow);
      startDirectCall.mutate({ recipientId: missedCall.initiatorId, kind: missedCall.kind });
    } catch (error) {
      const message = error instanceof Error ? error.message : "কলকারীকে খুঁজে পাওয়া যায়নি।";
      Alert.alert("পুনরায় কল করা যায়নি", message);
    }
  };

  const openDirect = (person: ProfileRow) => {
    setActivePeer(person);
    setSelectedMember(null);
    setMessageText("");
    setReplyingTo(null);
    setEditingMessage(null);
    setSection("direct");
  };
  const openGroup = (group: GroupRow) => {
    setActiveGroup(group);
    setSelectedMember(null);
    setGroupSettingsName(group.name);
    setGroupSettingsDescription(group.description ?? "");
    setGroupSettingsPrivacy(group.privacy);
    setGroupSettingsAnnouncementsOnly(group.isAnnouncementsOnly);
    setMessageText("");
    setReplyingTo(null);
    setEditingMessage(null);
    setMemberSearch("");
    setSection("group");
  };
  const openUnreadChat = async (row: UnreadChatListRow) => {
    try {
      if (row.kind === "direct") {
        const person = await trpcUtils.profile.byId.fetch({ userId: row.id });
        openDirect(person as ProfileRow);
      } else {
        const group = await trpcUtils.groups.detail.fetch({ groupId: row.id });
        openGroup(group as GroupRow);
      }
      void refetchUnreadChatBadges();
    } catch (error) {
      const message = error instanceof Error ? error.message : "চ্যাটটি এখন খোলা যাচ্ছে না।";
      Alert.alert("চ্যাট খোলা যায়নি", message);
    }
  };
  const openRecentConversation = async (row: RecentConversationRow) => {
    try {
      if (row.kind === "direct") {
        const person = await trpcUtils.profile.byId.fetch({ userId: row.id });
        openDirect(person as ProfileRow);
      } else {
        const group = await trpcUtils.groups.detail.fetch({ groupId: row.id });
        openGroup(group as GroupRow);
      }
      void refetchRecentConversations();
      void refetchUnreadChatBadges();
    } catch (error) {
      const message = error instanceof Error ? error.message : "কথোপকথনটি এখন খোলা যাচ্ছে না।";
      Alert.alert("চ্যাট খোলা যায়নি", message);
    }
  };
  const openMemberProfile = (person: ProfileRow) => {
    setSelectedMember(person);
    setSection("member-profile");
  };
  const startMemberCall = (kind: "audio" | "video") => {
    if (!selectedMember) return;
    if (selectedMember.id === user.id) {
      Alert.alert("নিজেকে কল করা যাবে না", "অন্য একজন সদস্যের প্রোফাইল থেকে কল দিন।");
      return;
    }
    startDirectCall.mutate({ recipientId: selectedMember.id, kind });
  };
  const goHome = () => {
    setActivePeer(null);
    setActiveGroup(null);
    setSelectedMember(null);
    setMessageText("");
    setReplyingTo(null);
    setEditingMessage(null);
    setSection("home");
  };

  const openPushDestination = useCallback(async (destination: PushDestination) => {
    if (destination.type === "announcement" || destination.type === "founder-update") {
      setActivePeer(null);
      setActiveGroup(null);
      setMessageText("");
      setReplyingTo(null);
      setEditingMessage(null);
      setSection("updates");
      return;
    }
    if (destination.type === "dm") {
      const person = await trpcUtils.profile.byId.fetch({ userId: destination.peerId });
      openDirect(person as ProfileRow);
      return;
    }
    if (destination.type === "call") {
      setActivePeer(null);
      setActiveGroup(null);
      setMessageText("");
      setReplyingTo(null);
      setEditingMessage(null);
      setSection("calls");
      const session = await trpcUtils.calls.byId.fetch({ sessionId: destination.sessionId }) as CallSessionRow;
      if (destination.action === "decline" && !session.groupId && session.recipientId === user.id && session.status === "requested") {
        await respondDirectCall.mutateAsync({ sessionId: session.id, status: "declined" });
        return;
      }
      if (destination.action === "accept" && !session.groupId && session.recipientId === user.id && session.status === "requested") {
        await respondDirectCall.mutateAsync({ sessionId: session.id, status: "active" });
        await prepareLiveCall({ ...session, status: "active" }, "ব্যক্তিগত কল");
        return;
      }
      if (destination.action === "accept" && session.groupId && session.status === "active") {
        await prepareLiveCall(session, "গ্রুপ কল");
        return;
      }
      void refetchDirectCalls();
      return;
    }
    const group = await trpcUtils.groups.detail.fetch({ groupId: destination.groupId });
    openGroup(group as GroupRow);
  }, [prepareLiveCall, refetchDirectCalls, respondDirectCall, trpcUtils, user.id]);

  useEffect(() => {
    const handleDestination = (destination: PushDestination) => {
      void openPushDestination(destination).catch((error) => {
        console.warn("[Push] Unable to open the destination:", error);
      });
    };
    const pending = consumePendingPushNavigation();
    if (pending) handleDestination(pending);
    return subscribePushNavigation(handleDestination);
  }, [openPushDestination]);

  const sendMessage = () => {
    const body = messageText.trim();
    if (!body) return;
    if (editingMessage) {
      editMessage.mutate({ messageId: editingMessage.message.id, body });
      return;
    }
    const replyPrefix = replyingTo ? `↩ ${displayName(replyingTo.sender)}: ${replyingTo.message.body.slice(0, 120)}\n` : "";
    if (section === "direct" && activePeer) sendDirect.mutate({ recipientId: activePeer.id, body: `${replyPrefix}${body}` });
    if (section === "group" && activeGroup) sendGroup.mutate({ groupId: activeGroup.id, body: `${replyPrefix}${body}` });
  };

  const replyPrefix = () => replyingTo ? `↩ ${displayName(replyingTo.sender)}: ${replyingTo.message.body.slice(0, 120)}\n` : "";
  const supportedAttachmentContentType = (value: string | null | undefined, kind: ChatAttachmentKind) => {
    const allowed = new Set([
      "image/jpeg", "image/png", "image/webp", "audio/mp4", "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm",
      "application/pdf", "text/plain", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/zip", "application/octet-stream",
    ]);
    if (value && allowed.has(value)) return value as Parameters<typeof uploadChatAttachment.mutateAsync>[0]["contentType"];
    return kind === "image" ? "image/jpeg" : kind === "voice" ? "audio/mp4" : "application/octet-stream";
  };
  const showChatUploadFailure = (kind: ChatAttachmentKind, filename: string, failure: ChatUploadFailure) => {
    failedChatUpload.current = null;
    const uploadId = ++chatUploadSequence.current;
    setChatUpload({ id: uploadId, kind, filename, phase: "failed", errorMessage: failure.message, failure });
  };
  const runChatAttachmentUpload = async (request: RetryableChatUpload) => {
    const uploadId = ++chatUploadSequence.current;
    const wasCancelled = () => cancelledChatUploadId.current === uploadId;
    let uploadRequestStarted = false;
    setChatUpload({ id: uploadId, kind: request.kind, filename: request.filename, phase: "preparing" });
    try {
      if (request.target.type === "direct") setActivity.mutate({ recipientId: request.target.id, activity: request.kind === "image" ? "uploading_image" : request.kind === "voice" ? "recording_voice" : "uploading_file" });
      const base64 = await request.loadBase64();
      if (wasCancelled()) return;
      if (isChatAttachmentTooLarge(request.size) || isChatAttachmentTooLarge(Math.floor((base64.length * 3) / 4))) {
        const failure = getChatAttachmentTooLargeFailure();
        failedChatUpload.current = null;
        setChatUpload({ id: uploadId, kind: request.kind, filename: request.filename, phase: "failed", errorMessage: failure.message, failure });
        return;
      }
      setChatUpload((current) => current?.id === uploadId ? { ...current, phase: "uploading" } : current);
      uploadRequestStarted = true;
      const uploaded = await uploadChatAttachment.mutateAsync({ base64, contentType: supportedAttachmentContentType(request.contentType, request.kind), filename: request.filename });
      if (wasCancelled()) return;
      setChatUpload((current) => current?.id === uploadId ? { ...current, phase: "sending" } : current);
      if (request.target.type === "direct") {
        await sendDirect.mutateAsync({ recipientId: request.target.id, body: request.body, kind: request.kind, attachmentUrl: uploaded.url });
      } else {
        await sendGroup.mutateAsync({ groupId: request.target.id, body: request.body, kind: request.kind, attachmentUrl: uploaded.url });
      }
      failedChatUpload.current = null;
    } catch (error) {
      if (wasCancelled()) return;
      const classifiedFailure = classifyChatUploadError(error);
      const failure = !uploadRequestStarted && classifiedFailure.kind === "unknown"
        ? { kind: "file" as const, label: "ফাইল পড়া যায়নি", message: "ফাইলটি পড়া যায়নি। অন্য একটি ফাইল বেছে নিন।", retryable: false }
        : classifiedFailure;
      failedChatUpload.current = failure.retryable ? request : null;
      setChatUpload({ id: uploadId, kind: request.kind, filename: request.filename, phase: "failed", errorMessage: failure.message, failure });
    } finally {
      if (request.target.type === "direct") clearActivity.mutate({ recipientId: request.target.id, groupId: null });
      if (cancelledChatUploadId.current === uploadId) cancelledChatUploadId.current = null;
      setChatUpload((current) => current?.id === uploadId && current.phase !== "failed" ? null : current);
    }
  };

  const sendUploadedAttachment = async ({ loadBase64, contentType, filename, kind, size }: { loadBase64: () => Promise<string>; contentType: string; filename: string; kind: ChatAttachmentKind; size?: number }) => {
    if (editingMessage) {
      Alert.alert("সংযুক্তি সম্পাদনা নয়", "বিদ্যমান সংযুক্তি বদলাতে নতুন একটি বার্তা পাঠান。");
      return;
    }
    const target = section === "direct" && activePeer
      ? { type: "direct" as const, id: activePeer.id }
      : section === "group" && activeGroup
        ? { type: "group" as const, id: activeGroup.id }
        : null;
    if (!target) return;
    failedChatUpload.current = null;
    if (isChatAttachmentTooLarge(size)) {
      showChatUploadFailure(kind, filename, getChatAttachmentTooLargeFailure());
      return;
    }
    await runChatAttachmentUpload({ loadBase64, contentType, filename, kind, target, body: `${replyPrefix()}${messageText.trim()}`, size });
  };

  const cancelChatUpload = () => {
    if (!chatUpload || chatUpload.phase === "sending" || chatUpload.phase === "cancelling") return;
    cancelledChatUploadId.current = chatUpload.id;
    setChatUpload((current) => current ? { ...current, phase: "cancelling" } : current);
  };
  const retryFailedChatUpload = () => {
    const request = failedChatUpload.current;
    if (!request || chatUpload?.phase !== "failed") return;
    void runChatAttachmentUpload(request);
  };
  const dismissFailedChatUpload = () => {
    if (chatUpload?.phase !== "failed") return;
    failedChatUpload.current = null;
    setChatUpload(null);
  };
  const readBase64 = (uri: string) => FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  const pickChatImage = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) { showChatUploadFailure("image", "নির্বাচিত ছবি", classifyChatUploadError(new Error("media library permission denied"))); return; }
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, quality: 0.75, base64: true });
      if (result.canceled) return;
      const asset = result.assets[0];
      await sendUploadedAttachment({ loadBase64: () => asset.base64 ? Promise.resolve(asset.base64) : readBase64(asset.uri), contentType: supportedAttachmentContentType(asset.mimeType, "image"), filename: asset.fileName ?? `fikir-image-${Date.now()}.jpg`, kind: "image", size: asset.fileSize });
    } catch (error) {
      showChatUploadFailure("image", "নির্বাচিত ছবি", classifyChatUploadError(error));
    }
  };
  const pickChatFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, type: [...SUPPORTED_CHAT_FILE_MIME_TYPES] });
      if (result.canceled) return;
      const asset = result.assets[0];
      await sendUploadedAttachment({ loadBase64: () => readBase64(asset.uri), contentType: supportedAttachmentContentType(asset.mimeType, "file"), filename: asset.name, kind: "file", size: asset.size });
    } catch (error) {
      showChatUploadFailure("file", "নির্বাচিত ফাইল", classifyChatUploadError(error));
    }
  };
  const startVoiceRecording = async () => {
    if (Platform.OS === "web") { Alert.alert("মোবাইল development build প্রয়োজন", "ভয়েস বার্তা রেকর্ড করতে Android বা iOS development build ব্যবহার করুন。"); return; }
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) { showChatUploadFailure("voice", "ভয়েস বার্তা", classifyChatUploadError(new Error("microphone permission denied"))); return; }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setIsRecordingVoice(true);
      setIsVoicePaused(false);
      if (activePeer && section === "direct") setActivity.mutate({ recipientId: activePeer.id, activity: "recording_voice" });
    } catch (error) {
      showChatUploadFailure("voice", "ভয়েস বার্তা", classifyChatUploadError(error));
    }
  };
  const toggleVoiceRecording = async () => {
    if (isVoicePaused) { recorder.record(); setIsVoicePaused(false); } else { await recorder.pause(); setIsVoicePaused(true); }
  };
  const cancelVoiceRecording = async () => {
    if (recorderState.isRecording || isVoicePaused) await recorder.stop();
    setIsRecordingVoice(false);
    setIsVoicePaused(false);
    await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
    if (activePeer && section === "direct") clearActivity.mutate({ recipientId: activePeer.id, groupId: null });
  };
  const sendVoiceRecording = async () => {
    try {
      await recorder.stop();
      const uri = recorder.uri;
      setIsRecordingVoice(false);
      setIsVoicePaused(false);
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      if (activePeer && section === "direct") clearActivity.mutate({ recipientId: activePeer.id, groupId: null });
      if (!uri) {
        showChatUploadFailure("voice", "ভয়েস বার্তা", { kind: "file", label: "ভয়েস রেকর্ড পড়া যায়নি", message: "ভয়েস রেকর্ডটি পড়া যায়নি। আবার রেকর্ড করুন।", retryable: false });
        return;
      }
      const info = await FileSystem.getInfoAsync(uri);
      await sendUploadedAttachment({ loadBase64: () => readBase64(uri), contentType: "audio/mp4", filename: `voice-${Date.now()}.m4a`, kind: "voice", size: info.exists ? info.size : undefined });
    } catch (error) {
      setIsRecordingVoice(false);
      setIsVoicePaused(false);
      void setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      showChatUploadFailure("voice", "ভয়েস বার্তা", classifyChatUploadError(error));
    }
  };
  const playAttachmentAudio = (url: string) => {
    attachmentAudioPlayer.current?.remove();
    const player = createAudioPlayer(getMediaUrl(url));
    attachmentAudioPlayer.current = player;
    player.play();
  };

  const formatVoiceDuration = (seconds: number | null | undefined) => {
    const totalSeconds = Math.max(0, Math.floor(seconds ?? 0));
    return `${Math.floor(totalSeconds / 60)}:${String(totalSeconds % 60).padStart(2, "0")}`;
  };
  const startFounderUpdateVoiceRecording = async () => {
    if (Platform.OS === "web") {
      Alert.alert("মোবাইল development build প্রয়োজন", "প্রতিষ্ঠাতা আপডেটের ভয়েস রেকর্ড করতে Android বা iOS development build ব্যবহার করুন।");
      return;
    }
    if (isRecordingVoice) {
      Alert.alert("রেকর্ডিং চলছে", "চ্যাটের চলমান ভয়েস রেকর্ড আগে শেষ বা বাতিল করুন।");
      return;
    }
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("মাইক্রোফোন অনুমতি প্রয়োজন", "প্রতিষ্ঠাতা আপডেটে ভয়েস যোগ করতে মাইক্রোফোনের অনুমতি দিন।");
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setUpdateVoiceUri(null);
      setUpdateVoiceBase64(null);
      setUpdateVoiceDurationSeconds(null);
      setRetainedUpdateVoiceUrl(null);
      setIsRecordingUpdateVoice(true);
      setIsUpdateVoicePaused(false);
    } catch {
      Alert.alert("ভয়েস রেকর্ড শুরু হয়নি", "মাইক্রোফোন ও ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");
    }
  };
  const toggleFounderUpdateVoiceRecording = async () => {
    if (!isRecordingUpdateVoice) return;
    if (isUpdateVoicePaused) {
      recorder.record();
      setIsUpdateVoicePaused(false);
      return;
    }
    await recorder.pause();
    setIsUpdateVoicePaused(true);
  };
  const cancelFounderUpdateVoiceRecording = async () => {
    try {
      if (recorderState.isRecording || isUpdateVoicePaused) await recorder.stop();
    } finally {
      setIsRecordingUpdateVoice(false);
      setIsUpdateVoicePaused(false);
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
    }
  };
  const finishFounderUpdateVoiceRecording = async () => {
    try {
      await recorder.stop();
      const uri = recorder.uri;
      const durationSeconds = Math.max(1, Math.ceil(recorderState.durationMillis / 1000));
      setIsRecordingUpdateVoice(false);
      setIsUpdateVoicePaused(false);
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      if (!uri) {
        Alert.alert("ভয়েস রেকর্ড পড়া যায়নি", "অনুগ্রহ করে আবার রেকর্ড করুন।");
        return;
      }
      const base64 = await readBase64(uri);
      setUpdateVoiceUri(uri);
      setUpdateVoiceBase64(base64);
      setUpdateVoiceDurationSeconds(durationSeconds);
      setRetainedUpdateVoiceUrl(null);
    } catch {
      setIsRecordingUpdateVoice(false);
      setIsUpdateVoicePaused(false);
      void setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      Alert.alert("ভয়েস প্রস্তুত হয়নি", "ভয়েসটি পড়া যায়নি। আবার রেকর্ড করুন।");
    }
  };
  const removeFounderUpdateVoice = () => {
    setUpdateVoiceUri(null);
    setUpdateVoiceBase64(null);
    setUpdateVoiceDurationSeconds(null);
    setRetainedUpdateVoiceUrl(null);
  };

  const requestCall = (kind: "audio" | "video") => {
    if (section === "direct" && activePeer) startDirectCall.mutate({ recipientId: activePeer.id, kind });
    if (section === "group" && activeGroup) startGroupCall.mutate({ groupId: activeGroup.id, kind });
  };

  const confirmClearDirectChat = () => {
    if (!activePeer) return;
    Alert.alert(
      "সম্পূর্ণ চ্যাট খালি করবেন?",
      `${displayName(activePeer)}-এর সঙ্গে এই কথোপকথনের সব বার্তা স্থায়ীভাবে মুছে যাবে। এই কাজটি ফিরিয়ে আনা যাবে না।`,
      [
        { text: "বাতিল", style: "cancel" },
        { text: "সব মুছে খালি করুন", style: "destructive", onPress: () => clearDirectChat.mutate({ peerId: activePeer.id }) },
      ],
    );
  };

  const openMessageActions = (entry: MessageRow) => {
    const mine = entry.message.senderId === user.id;
    const actions = [
      { text: "উত্তর", onPress: () => { setReplyingTo(entry); setEditingMessage(null); } },
      ...(mine && !entry.message.deletedAt ? [{ text: "সম্পাদনা", onPress: () => { setEditingMessage(entry); setReplyingTo(null); setMessageText(entry.message.body); } }] : []),
      ...(mine && !entry.message.deletedAt ? [{ text: "মুছুন", style: "destructive" as const, onPress: () => Alert.alert("বার্তা মুছবেন?", "এটি অন্যদের কাছেও মুছে ফেলা হিসেবে দেখা যাবে।", [{ text: "বাতিল", style: "cancel" }, { text: "মুছুন", style: "destructive", onPress: () => deleteMessage.mutate({ messageId: entry.message.id }) }]) }] : []),
      { text: "বাতিল", style: "cancel" as const },
    ];
    Alert.alert("বার্তা নিয়ন্ত্রণ", "উত্তর দিন অথবা নিজের বার্তা সম্পাদনা/মুছে ফেলুন।", actions);
  };
  const pickFounderUpdateImages = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("গ্যালারি অনুমতি প্রয়োজন", "আপডেটে ছবি যোগ করার জন্য গ্যালারি ব্যবহারের অনুমতি দিন।");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: true,
      selectionLimit: Math.max(1, 4 - retainedUpdateImages.length - localUpdateImages.length),
      quality: 0.75,
      base64: true,
    });
    if (result.canceled) return;
    const selected = result.assets
      .filter((asset) => !!asset.base64)
      .map((asset) => ({
        uri: asset.uri,
        base64: asset.base64 ?? null,
        contentType: asset.mimeType === "image/png" ? "image/png" as const : asset.mimeType === "image/webp" ? "image/webp" as const : "image/jpeg" as const,
      }));
    if (selected.length === 0) {
      Alert.alert("ছবি প্রস্তুত হয়নি", "নির্বাচিত ছবিটি পড়া যায়নি। অনুগ্রহ করে অন্য একটি ছবি নির্বাচন করুন।");
      return;
    }
    setLocalUpdateImages((current) => [...current, ...selected].slice(0, 4 - retainedUpdateImages.length));
  };

  const getSelectedSchedule = () => {
    const value = scheduledForText.trim();
    if (!value) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      Alert.alert("সময়টি সঠিক নয়", "সময় লিখুন যেমন: 2026-08-25 20:30। এই খসড়াটি স্বয়ংক্রিয়ভাবে প্রকাশ হবে না; নির্ধারিত সময়ে আপনি প্রকাশ বোতাম চাপবেন।");
      return undefined;
    }
    return date;
  };

  const saveFounderUpdateDraft = () => {
    const body = founderUpdateBody.trim();
    const linkUrl = founderUpdateLink.trim() || null;
    if (!body && !linkUrl && localUpdateImages.length === 0 && retainedUpdateImages.length === 0 && !updateVoiceBase64 && !retainedUpdateVoiceUrl) {
      Alert.alert("কিছু যোগ করুন", "খসড়া সংরক্ষণ করার আগে লেখা, লিংক, ছবি অথবা একটি ভয়েস দিন।");
      return;
    }
    if (linkUrl && !/^https?:\/\//i.test(linkUrl)) {
      Alert.alert("বৈধ লিংক দিন", "লিংকটি http:// অথবা https:// দিয়ে শুরু করুন।");
      return;
    }
    const scheduledFor = getSelectedSchedule();
    if (scheduledFor === undefined) return;
    const newImages = localUpdateImages.filter((image) => image.base64).map((image) => ({ base64: image.base64!, contentType: image.contentType }));
    const newVoice = updateVoiceBase64
      ? { base64: updateVoiceBase64, contentType: "audio/mp4" as const, durationSeconds: updateVoiceDurationSeconds ?? 1 }
      : null;
    if (editingFounderUpdate) {
      editFounderUpdate.mutate({
        updateId: editingFounderUpdate.update.id,
        body,
        linkUrl,
        newImages,
        retainedImageUrls: retainedUpdateImages,
        voice: newVoice ?? (retainedUpdateVoiceUrl ? undefined : null),
        scheduledFor,
      });
      return;
    }
    createFounderUpdate.mutate({ body, linkUrl, images: newImages, voice: newVoice, scheduledFor });
  };

  const beginFounderUpdateEdit = (entry: FounderUpdateRow) => {
    setEditingFounderUpdate(entry);
    setFounderUpdateBody(entry.update.body);
    setFounderUpdateLink(entry.update.linkUrl ?? "");
    setScheduledForText(entry.update.scheduledFor ? new Date(entry.update.scheduledFor).toISOString().slice(0, 16).replace("T", " ") : "");
    setRetainedUpdateImages(entry.update.imageUrls);
    setLocalUpdateImages([]);
    setUpdateVoiceUri(null);
    setUpdateVoiceBase64(null);
    setUpdateVoiceDurationSeconds(null);
    setRetainedUpdateVoiceUrl(entry.update.voiceUrl);
  };

  const copyFounderLink = async (value: string) => {
    await Clipboard.setStringAsync(value);
    Alert.alert("লিংক কপি হয়েছে", "এখন যেকোনো জায়গায় পেস্ট করতে পারবেন।");
  };

  const openFounderLink = async (value: string) => {
    const supported = await Linking.canOpenURL(value);
    if (!supported) {
      Alert.alert("লিংক খোলা যাচ্ছে না", "এই ডিভাইস লিংকটি খুলতে পারছে না। আগে কপি করে ব্রাউজারে পেস্ট করুন।");
      return;
    }
    await Linking.openURL(value);
  };

  const saveFounderImage = async (uri: string) => {
    if (Platform.OS === "web") {
      await Linking.openURL(uri);
      return;
    }
    const permission = await MediaLibrary.requestPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("গ্যালারি অনুমতি প্রয়োজন", "ছবিটি গ্যালারিতে সংরক্ষণ করতে অনুমতি দিন।");
      return;
    }
    try {
      const extension = /\.png(?:\?|$)/i.test(uri) ? "png" : /\.webp(?:\?|$)/i.test(uri) ? "webp" : "jpg";
      const target = `${FileSystem.cacheDirectory ?? FileSystem.documentDirectory}fikir-update-${Date.now()}.${extension}`;
      const downloaded = await FileSystem.downloadAsync(uri, target);
      await MediaLibrary.saveToLibraryAsync(downloaded.uri);
      Alert.alert("ছবি সংরক্ষিত", "প্রতিষ্ঠাতার আপডেটের ছবিটি গ্যালারিতে রাখা হয়েছে।");
    } catch {
      Alert.alert("ছবি সংরক্ষণ হয়নি", "ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");
    }
  };

  const saveChatAttachment = async (url: string, kind: SavableChatAttachmentKind) => {
    const mediaUrl = getMediaUrl(url);
    const filename = getChatAttachmentFilename(mediaUrl, kind);
    if (Platform.OS === "web") {
      await Linking.openURL(mediaUrl);
      return;
    }
    try {
      if (kind === "image") {
        const permission = await MediaLibrary.requestPermissionsAsync();
        if (!permission.granted) {
          Alert.alert("গ্যালারি অনুমতি প্রয়োজন", "ছবিটি গ্যালারিতে সংরক্ষণ করতে অনুমতি দিন।");
          return;
        }
      }
      const target = `${FileSystem.cacheDirectory ?? FileSystem.documentDirectory}${Date.now()}-${filename}`;
      const downloaded = await FileSystem.downloadAsync(mediaUrl, target);
      if (kind === "image") {
        await MediaLibrary.saveToLibraryAsync(downloaded.uri);
        Alert.alert("ছবি সংরক্ষিত", "ছবিটি আপনার গ্যালারিতে রাখা হয়েছে।");
        return;
      }
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert("সংরক্ষণ তালিকা নেই", "এই ডিভাইসে ফাইল সংরক্ষণের তালিকা খোলা যাচ্ছে না। লিংক কপি করে ব্রাউজারে খুলুন।");
        return;
      }
      await Sharing.shareAsync(downloaded.uri, {
        mimeType: getChatAttachmentMimeType(kind),
        dialogTitle: "ফাইলটি সংরক্ষণ করুন",
      });
    } catch {
      Alert.alert("সংরক্ষণ হয়নি", "ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");
    }
  };

  const renderBack = (title: string, action = goHome) => (
    <View style={styles.header}>
      <TouchableOpacity onPress={action} style={styles.backButton} accessibilityLabel="ফিরে যান">
        <Text style={styles.backText}>‹</Text>
      </TouchableOpacity>
      <Text style={styles.headerTitle}>{title}</Text>
      <View style={styles.headerSpacer} />
    </View>
  );

  const renderProfileEditor = () => (
    <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {renderBack("আমার প্রোফাইল")}
      <Text style={styles.helper}>Gmail পরিচয়: {user.email ?? "—"}</Text>
      <Text style={styles.label}>নাম</Text>
      <TextInput value={profileName} onChangeText={setProfileName} placeholder="আপনার নাম" style={styles.input} />
      <Text style={styles.label}>স্বতন্ত্র ইউজারনেম</Text>
      <TextInput value={profileUsername} onChangeText={setProfileUsername} autoCapitalize="none" placeholder="যেমন fikir.user" style={styles.input} />
      <Text style={styles.helper}>৩–৩২ অক্ষর; ইংরেজি অক্ষর, সংখ্যা, ডট ও আন্ডারস্কোর ব্যবহার করুন। একই ইউজারনেম গ্রহণ করা হবে না।</Text>
      <Text style={styles.label}>পরিচিতি</Text>
      <TextInput value={profileBio} onChangeText={setProfileBio} placeholder="নিজের সম্পর্কে সংক্ষেপে লিখুন" multiline style={[styles.input, styles.multiline]} />
      <TouchableOpacity
        style={styles.primaryButton}
        onPress={() => profileUpdate.mutate({ name: profileName, username: profileUsername, bio: profileBio || null })}
        disabled={profileUpdate.isPending}
      >
        <Text style={styles.primaryButtonText}>{profileUpdate.isPending ? "সংরক্ষণ হচ্ছে…" : "প্রোফাইল সংরক্ষণ করুন"}</Text>
      </TouchableOpacity>
    </ScrollView>
  );

  const renderMemberProfile = () => {
    if (!selectedMember) return renderHome();
    const isSelf = selectedMember.id === user.id;
    return (
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {renderBack("সদস্যের প্রোফাইল")}
        <View style={styles.memberProfileCard}>
          <View style={styles.memberProfileAvatar}>
            {selectedMember.avatarUrl ? <Image source={{ uri: getMediaUrl(selectedMember.avatarUrl) }} style={styles.memberProfileAvatarImage} /> : <Text style={styles.memberProfileAvatarText}>{displayName(selectedMember).slice(0, 1)}</Text>}
          </View>
          <Text style={styles.memberProfileName}>{displayName(selectedMember)}</Text>
          <Text style={styles.memberProfileUsername}>@{selectedMember.username || "ইউজারনেম নির্ধারিত নয়"}</Text>
          {selectedMember.bio ? <Text style={styles.memberProfileBio}>{selectedMember.bio}</Text> : <Text style={styles.memberProfileBioMuted}>এই সদস্য এখনো কোনো পরিচিতি যোগ করেননি।</Text>}
          {selectedMember.role === "founder" ? <Text style={styles.memberFounderBadge}>স্বীকৃত প্রতিষ্ঠাতা</Text> : null}
        </View>
        {isSelf ? <View style={styles.notice}><Text style={styles.noticeText}>এটি আপনার নিজের প্রোফাইল। আপনার তথ্য পরিবর্তন করতে সম্পাদনা অপশন ব্যবহার করুন।</Text><TouchableOpacity onPress={() => setSection("profile")}><Text style={styles.openText}>প্রোফাইল সম্পাদনা</Text></TouchableOpacity></View> : (
          <View style={styles.memberProfileActions}>
            <TouchableOpacity style={styles.memberMessageButton} onPress={() => openDirect(selectedMember)} accessibilityLabel={`${displayName(selectedMember)}-কে বার্তা পাঠান`}>
              <MaterialIcons name="chat-bubble" size={19} color="#FFFFFF" /><Text style={styles.memberMessageButtonText}>বার্তা পাঠান</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.memberCallButton} onPress={() => startMemberCall("audio")} disabled={startDirectCall.isPending} accessibilityLabel={`${displayName(selectedMember)}-কে অডিও কল দিন`}>
              <MaterialIcons name="phone" size={20} color="#0A6D9A" /><Text style={styles.memberCallButtonText}>{startDirectCall.isPending ? "অনুরোধ পাঠানো হচ্ছে…" : "অডিও কল"}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.memberCallButton} onPress={() => startMemberCall("video")} disabled={startDirectCall.isPending} accessibilityLabel={`${displayName(selectedMember)}-কে ভিডিও কল দিন`}>
              <MaterialIcons name="videocam" size={21} color="#0A6D9A" /><Text style={styles.memberCallButtonText}>ভিডিও কল</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    );
  };

  const renderNotificationSettings = () => (
    <ScrollView contentContainerStyle={styles.scroll}>
      {renderBack("নোটিফিকেশন সেটিংস")}
      <View style={styles.notificationHero}>
        <View style={styles.notificationHeroIcon}><MaterialIcons name="notifications-active" size={22} color="#FFFFFF" /></View>
        <View style={styles.personText}>
          <Text style={styles.notificationHeroTitle}>বিজ্ঞপ্তির পছন্দ</Text>
          <Text style={styles.notificationHeroText}>এই ফোনে বার্তা, আপডেট ও ইনকামিং কলের শব্দ এবং কম্পন নিয়ন্ত্রণ করুন।</Text>
        </View>
      </View>
      <View style={styles.notificationCard}>
        <View style={styles.settingTextBlock}>
          <Text style={styles.settingTitle}>সিস্টেম বিজ্ঞপ্তির অনুমতি</Text>
          <Text style={styles.settingDescription}>
            {notificationPermissionStatus === "granted" ? "এই ডিভাইসে বিজ্ঞপ্তি অনুমতি চালু আছে।" : "কল, বার্তা ও আপডেট পেতে Android-এর Notifications অনুমতি চালু করুন।"}
          </Text>
        </View>
        <TouchableOpacity style={styles.notificationActionButton} onPress={() => void requestNotificationAccess()} accessibilityRole="button">
          <Text style={styles.notificationActionText}>{notificationPermissionStatus === "granted" ? "আবার যাচাই" : "অনুমতি দিন"}</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.notificationCard}>
        <View style={styles.settingTextBlock}>
          <Text style={styles.settingTitle}>নোটিফিকেশন সাউন্ড</Text>
          <Text style={styles.settingDescription}>বার্তা, প্রতিষ্ঠাতা আপডেট, অডিও কল ও ভিডিও কলের কাস্টম সাউন্ড।</Text>
        </View>
        {isNotificationSettingsLoading ? <ActivityIndicator color="#0A7EA4" /> : <Switch
          value={notificationSettings.soundEnabled}
          onValueChange={(value) => void updateNotificationSetting("soundEnabled", value)}
          disabled={savingNotificationSetting !== null}
          trackColor={{ false: "#C7D7E2", true: "#73B8D5" }}
          thumbColor={notificationSettings.soundEnabled ? "#0A7EA4" : "#FFFFFF"}
          accessibilityLabel="নোটিফিকেশন সাউন্ড চালু বা বন্ধ করুন"
        />}
      </View>
      <View style={styles.notificationCard}>
        <View style={styles.settingTextBlock}>
          <Text style={styles.settingTitle}>ভাইব্রেশন</Text>
          <Text style={styles.settingDescription}>ইনকামিং বার্তা, আপডেট ও কল এলে ফোনের কম্পন।</Text>
        </View>
        {isNotificationSettingsLoading ? <ActivityIndicator color="#0A7EA4" /> : <Switch
          value={notificationSettings.vibrationEnabled}
          onValueChange={(value) => void updateNotificationSetting("vibrationEnabled", value)}
          disabled={savingNotificationSetting !== null}
          trackColor={{ false: "#C7D7E2", true: "#73B8D5" }}
          thumbColor={notificationSettings.vibrationEnabled ? "#0A7EA4" : "#FFFFFF"}
          accessibilityLabel="নোটিফিকেশন ভাইব্রেশন চালু বা বন্ধ করুন"
        />}
      </View>
      <View style={styles.notificationHint}>
        <MaterialIcons name="info-outline" size={18} color="#17628B" />
        <Text style={styles.notificationHintText}>পরিবর্তন এই ডিভাইসেই সংরক্ষণ থাকবে এবং সঙ্গে সঙ্গে Android বিজ্ঞপ্তি চ্যানেলে প্রয়োগ হবে। ফোনের সিস্টেম সেটিংস থেকে অ্যাপের বিজ্ঞপ্তি পুরোপুরি বন্ধ থাকলে সেখানে আবার চালু করুন।</Text>
      </View>
      <View style={styles.notificationGuidance}>
        <MaterialIcons name="battery-alert" size={20} color="#8A5A00" />
        <View style={styles.settingTextBlock}>
          <Text style={styles.settingTitle}>কল নির্ভরযোগ্য রাখতে</Text>
          <Text style={styles.notificationGuidanceText}>Android Settings &gt; Apps &gt; ফিকির মেসেঞ্জার &gt; Battery-তে Unrestricted/Don’t optimize বেছে নিন। একই জায়গায় Notifications, Pop on screen এবং Lock screen চালু রাখুন। কিছু ফোনে Battery Saver বা Background restriction বন্ধ না করলে অ্যাপ বন্ধ অবস্থায় কল দেরিতে আসতে পারে।</Text>
          <TouchableOpacity style={styles.notificationActionButton} onPress={() => void openSystemNotificationSettings()} accessibilityRole="button">
            <Text style={styles.notificationActionText}>অ্যাপ সেটিংস খুলুন</Text>
          </TouchableOpacity>
        </View>
      </View>
      {savingNotificationSetting ? <Text style={styles.notificationSaving}>পরিবর্তন সংরক্ষণ হচ্ছে…</Text> : null}
    </ScrollView>
  );

  const renderPeople = () => (
    <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {renderBack("মানুষ খুঁজুন")}
      <TextInput value={search} onChangeText={setSearch} autoCapitalize="none" placeholder="নাম অথবা @ইউজারনেম লিখুন" style={styles.input} />
      {search.trim().length > 0 && searchedPeople.isFetching ? <ActivityIndicator color="#0A7EA4" /> : null}
      {(searchedPeople.data ?? []).map((person) => {
        const row = person as ProfileRow;
        return <View key={row.id} style={styles.personCard}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{displayName(row).slice(0, 1)}</Text></View>
          <View style={styles.personText}><Text style={styles.personName}>{displayName(row)}</Text><Text style={styles.meta}>@{row.username || "নির্ধারিত নয়"}</Text>{row.bio ? <Text style={styles.bodyPreview} numberOfLines={2}>{row.bio}</Text> : null}</View>
          <View style={styles.peopleActions}><TouchableOpacity onPress={() => openDirect(row)}><Text style={styles.openText}>চ্যাট</Text></TouchableOpacity>{row.id !== user.id ? <TouchableOpacity onPress={() => setModerationTarget(row)}><Text style={styles.reportLink}>রিপোর্ট/ব্লক</Text></TouchableOpacity> : null}</View>
        </View>;
      })}
      {search.trim().length > 0 && !searchedPeople.isFetching && (searchedPeople.data ?? []).length === 0 ? <Text style={styles.empty}>কোনো ব্যবহারকারী পাওয়া যায়নি।</Text> : null}
    </ScrollView>
  );

  const renderAdmin = () => {
    const adminRows = (adminUsers.data ?? []) as unknown as AdminUserRow[];
    const reportRows = (adminReports.data ?? []) as unknown as ReportRow[];
    const banRows = (bannedUsers.data ?? []) as unknown as BanRow[];
    const usage = adminUsage.data as AdminUsageStats | undefined;
    const bannedIds = new Set(banRows.map((entry) => entry.ban.userId));
    const blockedIds = new Set((blockedByMe.data ?? []).map((entry) => entry.blockedUserId));
    const nameFor = (id: number) => displayName(adminRows.find((item) => item.id === id) ?? { name: null, username: null });
    const visibleUsers = sortAdminDashboardUsers(
      filterAdminDashboardUsers(adminRows, user.id, adminSearch, adminFilter, bannedIds, blockedIds),
      adminActivitySort,
    );
    const refreshAdminData = () => {
      void Promise.all([adminUsers.refetch(), adminUsage.refetch(), blockedByMe.refetch(), bannedUsers.refetch(), adminReports.refetch()]);
    };
    return <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {renderBack("প্রতিষ্ঠাতা নিয়ন্ত্রণ")}
      <View style={styles.adminHero}>
        <View style={styles.adminHeroTop}><View style={styles.adminHeroIcon}><MaterialIcons name="admin-panel-settings" size={24} color="#FFFFFF" /></View><View style={styles.adminHeroCopy}><Text style={styles.founderBadge}>শুধু স্বীকৃত প্রতিষ্ঠাতা Gmail-এর জন্য</Text><Text style={styles.founderName}>ফিকির মেসেঞ্জার প্রশাসন</Text></View><TouchableOpacity onPress={refreshAdminData} style={styles.adminRefreshButton} accessibilityLabel="ড্যাশবোর্ড হালনাগাদ করুন"><MaterialIcons name="refresh" size={19} color="#FFFFFF" /></TouchableOpacity></View>
        <Text style={styles.adminHeroDescription}>ব্যবহারকারী নিরাপত্তা, ব্যবহার-পরিসংখ্যান, আপডেট ও প্রতিষ্ঠাতার পরিচিতি এক জায়গা থেকে নিয়ন্ত্রণ করুন।</Text>
      </View>
      <View style={styles.adminSectionHeading}><View><Text style={styles.sectionTitle}>অ্যাপ ব্যবহারের চিত্র</Text><Text style={styles.sectionSubtitle}>বাস্তব সাইন-ইন ও উপস্থিতি তথ্যের সারাংশ</Text></View>{adminUsage.isFetching ? <ActivityIndicator color="#0A7EA4" /> : null}</View>
      <View style={styles.adminMetricsGrid}>
        <View style={[styles.adminMetricCard, styles.metricBlue]}><MaterialIcons name="groups" size={19} color="#0A6D9A" /><Text style={styles.adminMetricValue}>{usage?.totalUsers ?? "—"}</Text><Text style={styles.adminMetricLabel}>মোট ব্যবহারকারী</Text></View>
        <View style={[styles.adminMetricCard, styles.metricGreen]}><MaterialIcons name="login" size={19} color="#177B4B" /><Text style={styles.adminMetricValue}>{usage?.signedInLast24Hours ?? "—"}</Text><Text style={styles.adminMetricLabel}>সাইন-ইন (২৪ ঘণ্টা)</Text></View>
        <View style={[styles.adminMetricCard, styles.metricPurple]}><MaterialIcons name="wifi-tethering" size={19} color="#6941C6" /><Text style={styles.adminMetricValue}>{usage?.onlineNow ?? "—"}</Text><Text style={styles.adminMetricLabel}>এখন অনলাইনে</Text></View>
        <View style={[styles.adminMetricCard, styles.metricRed]}><MaterialIcons name="gpp-bad" size={19} color="#B42318" /><Text style={styles.adminMetricValue}>{usage?.bannedCount ?? "—"}</Text><Text style={styles.adminMetricLabel}>নিষিদ্ধ অ্যাকাউন্ট</Text></View>
      </View>
      <View style={styles.adminSafetyStrip}><View style={styles.adminSafetyItem}><MaterialIcons name="block" size={16} color="#9A5A00" /><Text style={styles.adminSafetyText}>আপনার ব্লক: {usage?.blockedByFounderCount ?? "—"}</Text></View><View style={styles.adminSafetyDivider} /><View style={styles.adminSafetyItem}><MaterialIcons name="flag" size={16} color="#9A5A00" /><Text style={styles.adminSafetyText}>নতুন রিপোর্ট: {usage?.openReportCount ?? "—"}</Text></View></View>
      <View style={styles.adminUpdateSummary}><MaterialIcons name="campaign" size={17} color="#0A6D9A" /><Text style={styles.adminUpdateSummaryText}>প্রকাশিত আপডেট {founderUpdateStats.data?.publishedCount ?? "—"} · খসড়া {founderUpdateStats.data?.draftCount ?? "—"}</Text></View>
      <Text style={styles.lastUpdateText}>{founderUpdateStats.data?.lastPublishedAt ? `সর্বশেষ প্রকাশ: ${formatTime(founderUpdateStats.data.lastPublishedAt)}` : "এখনো কোনো প্রকাশিত আপডেট নেই"}</Text>
      <View style={styles.adminPanel}><Text style={styles.sectionTitle}>প্রতিষ্ঠাতার পরিচিতি</Text><Text style={styles.helper}>এই জীবনী আপনার প্রতিষ্ঠাতা প্রোফাইলে দেখা যাবে।</Text><TextInput value={profileBio} onChangeText={setProfileBio} multiline textAlignVertical="top" maxLength={600} placeholder="প্রতিষ্ঠাতার পরিচিতি লিখুন" style={[styles.input, styles.adminBioInput]} /><TouchableOpacity style={[styles.primaryButton, profileUpdate.isPending && styles.disabledButton]} onPress={() => profileUpdate.mutate({ name: profileName, username: profileUsername, bio: profileBio.trim() || null })} disabled={profileUpdate.isPending}><Text style={styles.primaryButtonText}>প্রতিষ্ঠাতা জীবনী সংরক্ষণ করুন</Text></TouchableOpacity></View>
      <View style={styles.adminPanel}>
        <View style={styles.adminPanelHeader}><View><Text style={styles.sectionTitle}>ব্যবহারকারী নিয়ন্ত্রণ</Text><Text style={styles.sectionSubtitle}>তালিকা, সুরক্ষা-অবস্থা ও প্রয়োজনীয় পদক্ষেপ</Text></View><Text style={styles.adminCount}>{usage?.totalUsers ?? adminRows.length} জন</Text></View>
        <Text style={styles.helper}>ব্যক্তিগত ব্লক শুধু আপনার বার্তা ও কল বন্ধ করে। অ্যাপ ব্যবহারে নিষেধাজ্ঞার জন্য “নিষিদ্ধ” ব্যবহার করুন।</Text>
        <Text style={styles.adminSearchLabel}>তাৎক্ষণিক অনুসন্ধান — নাম বা Gmail ইমেইল লিখলেই ফলাফল বদলাবে</Text>
        <View style={styles.adminSearchBox}><MaterialIcons name="search" size={19} color="#5B7890" /><TextInput value={adminSearch} onChangeText={setAdminSearch} autoCapitalize="none" autoCorrect={false} clearButtonMode="never" placeholder="নাম বা Gmail ইমেইল দিয়ে খুঁজুন..." placeholderTextColor="#7890A1" accessibilityLabel="নাম বা Gmail ইমেইল দিয়ে ব্যবহারকারী অনুসন্ধান" style={styles.adminSearchInput} />{adminSearch ? <TouchableOpacity onPress={() => setAdminSearch("")} accessibilityLabel="অনুসন্ধান মুছুন" accessibilityHint="লেখা মুছে সম্পূর্ণ ব্যবহারকারী তালিকা দেখুন" hitSlop={8} style={styles.adminSearchClear}><MaterialIcons name="close" size={18} color="#5B7890" /></TouchableOpacity> : null}</View>
        {!adminUsers.isLoading ? <Text style={styles.adminSearchResults} accessibilityLiveRegion="polite">{adminSearch.trim() ? `${visibleUsers.length} জন পাওয়া গেছে` : `বর্তমানে ${visibleUsers.length} জন দেখা যাচ্ছে`}</Text> : null}
        <View style={styles.adminFilterRow}>{([ ["all", "সব"], ["regular", "স্বাভাবিক"], ["blocked", "ব্লক"], ["banned", "নিষিদ্ধ"] ] as const).map(([value, label]) => <TouchableOpacity key={value} onPress={() => setAdminFilter(value)} style={[styles.adminFilterChip, adminFilter === value && styles.adminFilterChipActive]}><Text style={[styles.adminFilterText, adminFilter === value && styles.adminFilterTextActive]}>{label}</Text></TouchableOpacity>)}</View>
        <View style={styles.adminSortRow}><View><Text style={styles.adminSortLabel}>শেষ সক্রিয়তা অনুযায়ী সাজান</Text><Text style={styles.adminSortHint}>বর্তমানে অনলাইনে থাকা ব্যবহারকারী সবসময় আগে</Text></View><View style={styles.adminFilterRow}>{([ ["recent", "সর্বশেষ আগে"], ["oldest", "পুরোনো আগে"] ] as const).map(([value, label]) => <TouchableOpacity key={value} onPress={() => setAdminActivitySort(value)} style={[styles.adminSortChip, adminActivitySort === value && styles.adminSortChipActive]} accessibilityRole="button" accessibilityState={{ selected: adminActivitySort === value }} accessibilityLabel={`${label} সাজানো`}><Text style={[styles.adminSortText, adminActivitySort === value && styles.adminSortTextActive]}>{label}</Text></TouchableOpacity>)}</View></View>
        {adminUsers.isLoading ? <ActivityIndicator color="#0A7EA4" /> : null}
        {!adminUsers.isLoading && visibleUsers.length === 0 ? <Text style={styles.empty}>{adminSearch.trim() ? "নাম বা Gmail ইমেইল মিলিয়ে কোনো ব্যবহারকারী পাওয়া যায়নি।" : "নির্বাচিত শর্তে কোনো ব্যবহারকারী পাওয়া যায়নি।"}</Text> : null}
        {visibleUsers.map((item) => {
          const { isBanned, isBlocked } = getAdminUserStatus(item.id, bannedIds, blockedIds);
          const isFounderAccount = item.role === "founder";
          return <View key={item.id} style={[styles.adminUserCard, isBanned && styles.adminUserCardBanned, isBlocked && !isBanned && styles.adminUserCardBlocked]}>
            <View style={styles.adminUserTop}><View style={styles.adminAvatar}>{item.avatarUrl ? <Image source={{ uri: getMediaUrl(item.avatarUrl) }} style={styles.adminAvatarImage} /> : <Text style={styles.avatarText}>{displayName(item).slice(0, 1)}</Text>}</View><View style={styles.adminUserIdentity}><View style={styles.adminNameLine}><Text style={styles.personName} numberOfLines={1}>{displayName(item)}</Text>{isFounderAccount ? <Text style={styles.adminFounderPill}>প্রতিষ্ঠাতা</Text> : null}</View><Text style={styles.meta}>@{item.username || "নির্ধারিত নয়"}</Text><Text style={styles.adminEmail} numberOfLines={1}>{item.email || "Gmail পরিচয় পাওয়া যায়নি"}</Text></View></View>
            <View style={styles.adminStatusRow}>{isBanned ? <Text style={[styles.adminStatusPill, styles.adminStatusBanned]}>নিষিদ্ধ</Text> : null}{isBlocked ? <Text style={[styles.adminStatusPill, styles.adminStatusBlocked]}>আপনার ব্লকে</Text> : null}{!isBanned && !isBlocked ? <Text style={[styles.adminStatusPill, styles.adminStatusRegular]}>স্বাভাবিক</Text> : null}</View>
            <View style={styles.adminUserDetails}><Text style={styles.adminDetailText}>যোগ দিয়েছেন: {formatDate(item.createdAt)}</Text><Text style={styles.adminDetailText}>সর্বশেষ সাইন-ইন: {formatTime(item.lastSignedIn ?? item.createdAt)}</Text><View style={styles.adminLastActiveRow}><MaterialIcons name={item.isOnline ? "radio-button-checked" : "history"} size={14} color={item.isOnline ? "#16835B" : "#3D6780"} /><Text style={[styles.adminDetailText, item.isOnline && styles.adminLastActiveOnline]}>শেষ সক্রিয়: {item.isOnline ? "এখন অনলাইন · " : ""}{formatAdminLastActive(item.lastActiveAt)}</Text></View></View>
            {!isFounderAccount ? <View style={styles.adminActionRow}><TouchableOpacity disabled={blockUser.isPending || unblockUser.isPending} onPress={() => setAdminBlockTarget({ user: item, mode: isBlocked ? "unblock" : "block" })} style={[styles.adminActionButton, isBlocked ? styles.adminActionUnblock : styles.adminActionBlock]}><MaterialIcons name={isBlocked ? "lock-open" : "block"} size={15} color={isBlocked ? "#18794E" : "#A65C00"} /><Text style={[styles.adminActionText, isBlocked ? styles.adminActionUnblockText : styles.adminActionBlockText]}>{isBlocked ? "আনব্লক" : "ব্লক"}</Text></TouchableOpacity>{isBanned ? <TouchableOpacity disabled={unbanUser.isPending} onPress={() => unbanUser.mutate({ userId: item.id })} style={[styles.adminActionButton, styles.adminActionUnban]}><MaterialIcons name="restart-alt" size={15} color="#18794E" /><Text style={[styles.adminActionText, styles.adminActionUnbanText]}>অনুমতি দিন</Text></TouchableOpacity> : <TouchableOpacity disabled={banUser.isPending} onPress={() => { setSelectedAdminUser(item); setBanReason(""); }} style={[styles.adminActionButton, styles.adminActionBan]}><MaterialIcons name="gpp-bad" size={15} color="#B42318" /><Text style={[styles.adminActionText, styles.adminActionBanText]}>নিষিদ্ধ</Text></TouchableOpacity>}</View> : <Text style={styles.adminFounderNote}>প্রতিষ্ঠাতা অ্যাকাউন্ট সুরক্ষিত; এটির বিরুদ্ধে প্রশাসনিক পদক্ষেপ প্রযোজ্য নয়।</Text>}</View>;
        })}
      </View>
      <View style={styles.adminPanel}><View style={styles.adminPanelHeader}><Text style={styles.sectionTitle}>ব্যবহারকারী রিপোর্ট</Text><Text style={styles.adminCount}>{reportRows.length} টি</Text></View>{adminReports.isLoading ? <ActivityIndicator color="#0A7EA4" /> : null}{reportRows.length === 0 ? <Text style={styles.empty}>এখনো কোনো ব্যবহারকারী রিপোর্ট পাঠাননি।</Text> : null}{reportRows.map((report) => <View key={report.id} style={styles.reportCard}><Text style={styles.personName}>{nameFor(report.reportedUserId)} সম্পর্কে রিপোর্ট</Text><Text style={styles.meta}>রিপোর্ট করেছেন: {nameFor(report.reporterId)} · {formatTime(report.createdAt)}</Text><Text style={styles.postBody}>{report.reason}</Text><View style={styles.updateControls}><Text style={[styles.reportStatus, report.status === "resolved" && styles.reportStatusResolved]}>{report.status === "open" ? "নতুন" : report.status === "reviewed" ? "পর্যালোচনায়" : "সমাধান"}</Text>{report.status !== "reviewed" ? <TouchableOpacity style={styles.secondaryAction} onPress={() => resolveReport.mutate({ reportId: report.id, status: "reviewed" })}><Text style={styles.secondaryActionText}>পর্যালোচনায় নিন</Text></TouchableOpacity> : null}{report.status !== "resolved" ? <TouchableOpacity style={styles.secondaryAction} onPress={() => resolveReport.mutate({ reportId: report.id, status: "resolved" })}><Text style={styles.secondaryActionText}>সমাধান করুন</Text></TouchableOpacity> : null}</View></View>)}</View>
      <TouchableOpacity style={styles.openUpdatesButton} onPress={() => setSection("updates")}><Text style={styles.primaryButtonText}>আপডেট খসড়া ও প্রকাশ নিয়ন্ত্রণ খুলুন</Text></TouchableOpacity>
    </ScrollView>;
  };

  const renderGroupList = () => (
    <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {renderBack("গ্রুপ ও কমিউনিটি")}
      <Text style={styles.sectionTitle}>নতুন গ্রুপ খুলুন</Text>
      <TextInput value={groupName} onChangeText={setGroupName} placeholder="গ্রুপের নাম" style={styles.input} />
      <TextInput value={groupHandle} onChangeText={setGroupHandle} autoCapitalize="none" placeholder="গ্রুপ হ্যান্ডেল, যেমন fikir-study" style={styles.input} />
      <TextInput value={groupDescription} onChangeText={setGroupDescription} placeholder="গ্রুপের উদ্দেশ্য ও নিয়ম" multiline style={[styles.input, styles.multiline]} />
      <View style={styles.chipRow}>
        {(["public", "approval", "private"] as const).map((item) => (
          <TouchableOpacity key={item} style={[styles.chip, groupPrivacy === item && styles.chipActive]} onPress={() => setGroupPrivacy(item)}>
            <Text style={[styles.chipText, groupPrivacy === item && styles.chipTextActive]}>{item === "public" ? "সবার জন্য" : item === "approval" ? "অনুমোদন" : "শুধু আমন্ত্রণ"}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={styles.toggleRow}>
        <Text style={styles.toggleLabel}>শুধু অ্যাডমিনের ঘোষণা</Text>
        <Switch value={announcementsOnly} onValueChange={setAnnouncementsOnly} trackColor={{ true: "#0A7EA4" }} />
      </View>
      <TouchableOpacity
        style={styles.primaryButton}
        disabled={createGroup.isPending}
        onPress={() => createGroup.mutate({ name: groupName, handle: groupHandle, description: groupDescription || undefined, privacy: groupPrivacy, isAnnouncementsOnly: announcementsOnly })}
      >
        <Text style={styles.primaryButtonText}>{createGroup.isPending ? "তৈরি হচ্ছে…" : "গ্রুপ তৈরি করুন"}</Text>
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>আমার গ্রুপ</Text>
      {myGroupRows.map((entry) => (
        <TouchableOpacity key={entry.group.id} style={styles.groupCard} onPress={() => openGroup(entry.group)}>
          <View style={styles.groupIcon}><Text style={styles.groupIconText}>গ</Text></View>
          <View style={styles.personText}>
            <Text style={styles.personName}>{entry.group.name}</Text>
            <Text style={styles.meta}>@{entry.group.handle} · {entry.membership.role === "owner" ? "মালিক" : entry.membership.role === "admin" ? "অ্যাডমিন" : "সদস্য"}</Text>
          </View>
          <Text style={styles.openText}>খুলুন</Text>
        </TouchableOpacity>
      ))}
      {myGroupRows.length === 0 ? <Text style={styles.empty}>আপনি এখনো কোনো গ্রুপে যোগ দেননি।</Text> : null}
      <Text style={styles.sectionTitle}>আবিষ্কার করুন</Text>
      {discoverRows.map((group) => {
        const isMember = myGroupRows.some((entry) => entry.group.id === group.id);
        return (
          <View key={group.id} style={styles.groupCard}>
            <View style={styles.groupIcon}><Text style={styles.groupIconText}>গ</Text></View>
            <View style={styles.personText}>
              <Text style={styles.personName}>{group.name}</Text>
              <Text style={styles.meta}>@{group.handle} · {group.privacy === "public" ? "সবার জন্য" : "অনুমোদন প্রয়োজন"}</Text>
              {group.description ? <Text style={styles.bodyPreview} numberOfLines={2}>{group.description}</Text> : null}
            </View>
            {isMember ? <TouchableOpacity onPress={() => openGroup(group)}><Text style={styles.openText}>খুলুন</Text></TouchableOpacity> : <TouchableOpacity onPress={() => joinGroup.mutate({ groupId: group.id })}><Text style={styles.openText}>যোগ দিন</Text></TouchableOpacity>}
          </View>
        );
      })}
    </ScrollView>
  );

  const renderUnreadChats = () => (
    <FlatList
      data={unreadChatRows}
      keyExtractor={(item) => `${item.kind}-${item.id}`}
      contentContainerStyle={styles.chatListContent}
      ListHeaderComponent={
        <View style={styles.chatListHeader}>
          {renderBack("অপঠিত চ্যাট")}
          <Text style={styles.helper}>নতুন বার্তা থাকা ব্যক্তিগত ও গ্রুপ চ্যাট এখানে দেখা যাবে। চ্যাট খুললেই বার্তাগুলো পড়া হিসেবে চিহ্নিত হবে।</Text>
          {unreadChatTotal > 0 ? <View style={styles.unreadSummaryPill}><MaterialIcons name="mark-chat-unread" size={18} color="#FFFFFF" /><Text style={styles.unreadSummaryText}>{formatUnreadBadgeCount(unreadChatTotal)} অপঠিত বার্তা</Text></View> : null}
        </View>
      }
      ListEmptyComponent={
        unreadChatBadges.isLoading ? <ActivityIndicator color="#0A7EA4" style={styles.loadingList} /> : <View style={styles.emptyUnreadCard}><MaterialIcons name="mark-chat-read" size={28} color="#4E9CB5" /><Text style={styles.emptyUnreadTitle}>সব বার্তা পড়া হয়েছে</Text><Text style={styles.empty}>নতুন ব্যক্তিগত বা গ্রুপ বার্তা এলে এখানে ব্যাজসহ দেখা যাবে।</Text></View>
      }
      renderItem={({ item }) => {
        const title = item.kind === "direct" ? displayName({ name: item.name, username: item.username }) : item.name;
        const subtitle = item.kind === "direct" ? `@${item.username || "ইউজারনেম নেই"}` : `গ্রুপ · @${item.handle}`;
        return (
          <TouchableOpacity style={styles.unreadChatRow} onPress={() => void openUnreadChat(item)}>
            <View style={[styles.unreadChatAvatar, item.kind === "group" && styles.unreadGroupAvatar]}>
              <Text style={styles.unreadChatAvatarText}>{title.slice(0, 1)}</Text>
            </View>
            <View style={styles.unreadChatCopy}>
              <Text style={styles.unreadChatName} numberOfLines={1}>{title}</Text>
              <Text style={styles.unreadChatMeta} numberOfLines={1}>{subtitle}</Text>
            </View>
            <View style={styles.unreadBadge}><Text style={styles.unreadBadgeText}>{formatUnreadBadgeCount(item.unreadCount)}</Text></View>
          </TouchableOpacity>
        );
      }}
    />
  );

  const renderSocialFeed = () => {
    const rows = (socialFeed.data ?? []) as unknown as SocialPostRow[];
    const following = new Set((followingIds.data ?? []).map((entry) => entry.userId));
    const pickSocialImage = async () => {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) { Alert.alert("গ্যালারি অনুমতি প্রয়োজন", "ছবি পোস্ট করতে গ্যালারি অনুমতি দিন।"); return; }
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, quality: 0.75, base64: true });
      if (result.canceled) return;
      const asset = result.assets[0];
      try {
        const base64 = asset.base64 ?? await readBase64(asset.uri);
        const uploaded = await uploadChatAttachment.mutateAsync({ base64, contentType: supportedAttachmentContentType(asset.mimeType, "image"), filename: asset.fileName ?? `fikir-post-${Date.now()}.jpg` });
        setSocialImageUrls((current) => [...current, uploaded.url].slice(0, 4));
      } catch (error) { Alert.alert("ছবি যোগ হয়নি", error instanceof Error ? error.message : "ছবিটি আপলোড করা যায়নি।"); }
    };
    return <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
      {renderBack("সবার ফিকির")}
      <View style={styles.socialHero}><MaterialIcons name="public" size={24} color="#FFFFFF" /><View style={styles.socialHeroCopy}><Text style={styles.socialHeroTitle}>সবার ফিকির</Text><Text style={styles.socialHeroText}>সবাই নিজের চিন্তা, লেখা, ছবি ও লিংক শেয়ার করতে পারবেন।</Text></View></View>
      <View style={styles.socialComposer}><View style={styles.composerTitleRow}><Text style={styles.sectionTitle}>{editingSocialPostId ? "পোস্ট সম্পাদনা" : "আপনার ফিকির লিখুন"}</Text>{editingSocialPostId ? <TouchableOpacity onPress={() => { setEditingSocialPostId(null); setSocialBody(""); setSocialLink(""); }}><Text style={styles.cancelLink}>বাতিল</Text></TouchableOpacity> : null}</View><TextInput value={socialBody} onChangeText={setSocialBody} multiline maxLength={5000} placeholder="আপনার কথা, প্রশ্ন বা চিন্তা লিখুন…" textAlignVertical="top" style={[styles.input, styles.updateComposerInput]} /><TextInput value={socialLink} onChangeText={setSocialLink} autoCapitalize="none" keyboardType="url" placeholder="লিংক যোগ করুন (ঐচ্ছিক)" style={styles.input} />{!editingSocialPostId && socialImageUrls.length > 0 ? <Text style={styles.helper}>{socialImageUrls.length}টি ছবি যুক্ত হয়েছে</Text> : null}<View style={styles.socialComposerActions}>{!editingSocialPostId ? <TouchableOpacity style={styles.socialSecondaryButton} onPress={() => void pickSocialImage()}><MaterialIcons name="image" size={17} color="#0A6D9A" /><Text style={styles.socialSecondaryText}>ছবি</Text></TouchableOpacity> : <View /> }<TouchableOpacity style={styles.socialPublishButton} onPress={() => editingSocialPostId ? editSocialPost.mutate({ postId: editingSocialPostId, body: socialBody.trim(), linkUrl: socialLink.trim() || null }) : createSocialPost.mutate({ body: socialBody.trim(), linkUrl: socialLink.trim() || null, imageUrls: socialImageUrls, visibility: "community" })} disabled={createSocialPost.isPending || editSocialPost.isPending || (!socialBody.trim() && !socialLink.trim() && socialImageUrls.length === 0)}><Text style={styles.primaryButtonText}>{createSocialPost.isPending || editSocialPost.isPending ? "সংরক্ষণ হচ্ছে…" : editingSocialPostId ? "পরিবর্তন সংরক্ষণ" : "পোস্ট করুন"}</Text></TouchableOpacity></View></View>
      <View style={styles.socialFeedHeader}><View><Text style={styles.sectionTitle}>সবার পোস্ট</Text><Text style={styles.sectionSubtitle}>ফলো করা ব্যক্তিদের পোস্ট আগে দেখা যায়</Text></View>{socialFeed.isFetching ? <ActivityIndicator color="#0A7EA4" /> : null}</View>
      {rows.length === 0 ? <Text style={styles.empty}>এখনো কোনো পোস্ট নেই। প্রথম ফিকিরটি আপনি পোস্ট করুন।</Text> : rows.map((entry) => { const own = entry.post.authorId === user.id; const myReaction = entry.post.myReaction; return <View key={entry.post.id} style={styles.socialPostCard}><View style={styles.socialPostHeader}><View style={styles.recentAvatar}>{entry.author.avatarUrl ? <Image source={{ uri: getMediaUrl(entry.author.avatarUrl) }} style={styles.recentAvatarImage} /> : <Text style={styles.recentAvatarText}>{displayName(entry.author).slice(0, 1)}</Text>}</View><View style={styles.socialPostIdentity}><Text style={styles.personName}>{displayName(entry.author)}</Text><Text style={styles.meta}>@{entry.author.username || "ইউজারনেম নেই"} · {formatTime(entry.post.createdAt)}</Text></View>{!own ? <TouchableOpacity style={styles.followButton} onPress={() => followSocialUser.mutate({ userId: entry.author.id })}><Text style={styles.followButtonText}>{following.has(entry.author.id) ? "ফলো করা" : "ফলো"}</Text></TouchableOpacity> : <View style={styles.socialOwnerActions}><TouchableOpacity onPress={() => { setEditingSocialPostId(entry.post.id); setSocialBody(entry.post.body); setSocialLink(entry.post.linkUrl ?? ""); setSocialImageUrls([]); }}><MaterialIcons name="edit" size={18} color="#0A6D9A" /></TouchableOpacity><TouchableOpacity onPress={() => Alert.alert("পোস্ট মুছবেন?", "এই পোস্টটি স্থায়ীভাবে মুছে যাবে।", [{ text: "বাতিল", style: "cancel" }, { text: "মুছুন", style: "destructive", onPress: () => deleteSocialPost.mutate({ postId: entry.post.id }) }])}><MaterialIcons name="delete-outline" size={19} color="#A33D45" /></TouchableOpacity></View>}</View><Text style={styles.socialPostBody}>{entry.post.body}</Text>{entry.post.imageUrls.map((url) => <Image key={url} source={{ uri: getMediaUrl(url) }} style={styles.socialPostImage} />)}{entry.post.voiceUrl ? <TouchableOpacity style={styles.socialVoiceButton} onPress={() => playAttachmentAudio(entry.post.voiceUrl!)}><Text style={styles.socialVoiceText}>▶ ভয়েস পোস্ট · {formatVoiceDuration(entry.post.voiceDurationSeconds)}</Text></TouchableOpacity> : null}{entry.post.linkUrl ? <TouchableOpacity onPress={() => void openFounderLink(entry.post.linkUrl!)}><Text style={styles.socialPostLink}>{entry.post.linkUrl}</Text></TouchableOpacity> : null}<View style={styles.socialReactionRow}>{(["👍", "❤️", "👎"] as const).map((emoji) => <TouchableOpacity key={emoji} style={[styles.socialReactionButton, myReaction === emoji && styles.socialReactionActive]} onPress={() => reactSocialPost.mutate({ postId: entry.post.id, emoji })}><Text>{emoji}</Text><Text style={styles.socialReactionCount}>{entry.post.reactionCounts.find((reaction) => reaction.emoji === emoji)?.count ?? 0}</Text></TouchableOpacity>)}</View></View>; })}
    </ScrollView>;
  };

  const renderUpdates = () => {
    const rows = (founderUpdates.data ?? []) as unknown as FounderUpdateRow[];
    return (
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {renderBack("প্রতিষ্ঠাতার আপডেট")}
        <View style={styles.founderCard}>
          <Text style={styles.founderBadge}>শুধু প্রতিষ্ঠাতা প্রকাশ করেন</Text>
          <Text style={styles.founderName}>{founder.data?.name ?? "মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন"}</Text>
          <Text style={styles.founderBio}>{founder.data?.shortBio ?? "ফিকির প্ল্যাটফর্মের প্রতিষ্ঠাতা, মালিক ও প্রধান এডমিন।"}</Text>
          <Text style={styles.founderRole}>{founder.data?.role ?? "এডমিন ও খাদিম — Fikir Platform"}</Text>
        </View>

        {isFounder ? (
          <View style={styles.composerCard}>
            <View style={styles.composerTitleRow}>
              <Text style={styles.sectionTitle}>{editingFounderUpdate ? "আপডেট সম্পাদনা" : "নতুন প্রতিষ্ঠাতা আপডেট"}</Text>
              {editingFounderUpdate ? <TouchableOpacity onPress={clearFounderUpdateComposer}><Text style={styles.cancelLink}>বাতিল</Text></TouchableOpacity> : null}
            </View>
            <Text style={styles.helper}>দীর্ঘ লেখা, ইমোজি, সর্বোচ্চ ৪টি ছবি, একটি ভয়েস এবং বড় অ্যাপ/ওয়েব লিংক যোগ করা যাবে। আগে খসড়া রাখুন, পরে নিজে প্রকাশ করুন।</Text>
            <TextInput value={founderUpdateBody} onChangeText={setFounderUpdateBody} placeholder="আপডেটের বিস্তারিত লিখুন…" multiline textAlignVertical="top" maxLength={20000} style={[styles.input, styles.updateComposerInput]} />
            <Text style={styles.counterText}>{founderUpdateBody.length}/20000</Text>
            <TextInput value={founderUpdateLink} onChangeText={setFounderUpdateLink} autoCapitalize="none" keyboardType="url" placeholder="https:// আপডেট / ডাউনলোড লিংক (ঐচ্ছিক)" style={styles.input} />
            <TextInput value={scheduledForText} onChangeText={setScheduledForText} autoCapitalize="none" placeholder="পরিকল্পিত সময় (ঐচ্ছিক): 2026-08-25 20:30" style={styles.input} />
            <Text style={styles.helper}>নির্ধারিত সময়টি শুধু স্মরণ রাখার জন্য। স্বয়ংক্রিয় প্রকাশ নয়—সময় হলে “প্রকাশ করুন” চাপুন।</Text>
            <View style={styles.updateImageGrid}>
              {[...retainedUpdateImages.map((uri) => ({ uri, stored: true })), ...localUpdateImages.map((item) => ({ uri: item.uri, stored: false }))].map((image, index) => (
                <View key={`${image.uri}-${index}`} style={styles.composerImageWrap}>
                  <Image source={{ uri: getMediaUrl(image.uri) }} style={styles.composerImage} />
                  <TouchableOpacity style={styles.removeImageButton} onPress={() => image.stored ? setRetainedUpdateImages((current) => current.filter((_, itemIndex) => itemIndex !== index)) : setLocalUpdateImages((current) => current.filter((_, itemIndex) => itemIndex !== index - retainedUpdateImages.length))}>
                    <Text style={styles.removeImageText}>×</Text>
                  </TouchableOpacity>
                </View>
              ))}
              {retainedUpdateImages.length + localUpdateImages.length < 4 ? <TouchableOpacity style={styles.addImageButton} onPress={pickFounderUpdateImages}><Text style={styles.addImageText}>＋ ছবি</Text></TouchableOpacity> : null}
            </View>
            {isRecordingUpdateVoice ? <View style={styles.updateVoiceRecorder}><Text style={styles.updateVoiceRecorderText}>● {isUpdateVoicePaused ? "রেকর্ড থামানো" : "ভয়েস রেকর্ড হচ্ছে"} · {formatVoiceDuration(Math.ceil(recorderState.durationMillis / 1000))}</Text><TouchableOpacity style={styles.updateVoiceControl} onPress={() => void toggleFounderUpdateVoiceRecording()}><Text style={styles.updateVoiceControlText}>{isUpdateVoicePaused ? "চালু করুন" : "বিরতি"}</Text></TouchableOpacity><TouchableOpacity style={styles.updateVoiceControl} onPress={() => void finishFounderUpdateVoiceRecording()}><Text style={styles.updateVoiceControlText}>শেষ করুন</Text></TouchableOpacity><TouchableOpacity onPress={() => void cancelFounderUpdateVoiceRecording()}><Text style={styles.updateVoiceRemoveText}>বাতিল</Text></TouchableOpacity></View> : null}
            {!isRecordingUpdateVoice && (updateVoiceUri || retainedUpdateVoiceUrl) ? <View style={styles.updateVoicePreview}><View style={styles.updateVoicePreviewCopy}><Text style={styles.updateVoicePreviewTitle}>ভয়েস সংযুক্তি প্রস্তুত</Text><Text style={styles.updateVoicePreviewMeta}>{updateVoiceDurationSeconds ? `${formatVoiceDuration(updateVoiceDurationSeconds)} · নতুন রেকর্ড` : "আগের সংযুক্ত ভয়েস"}</Text></View><TouchableOpacity style={styles.updateVoiceControl} onPress={() => playAttachmentAudio(updateVoiceUri ?? retainedUpdateVoiceUrl!)}><Text style={styles.updateVoiceControlText}>▶ চালান</Text></TouchableOpacity><TouchableOpacity onPress={removeFounderUpdateVoice}><Text style={styles.updateVoiceRemoveText}>মুছুন</Text></TouchableOpacity></View> : null}
            {!isRecordingUpdateVoice && !updateVoiceUri && !retainedUpdateVoiceUrl ? <TouchableOpacity style={styles.addUpdateVoiceButton} onPress={() => void startFounderUpdateVoiceRecording()}><MaterialIcons name="mic" size={17} color="#0A7EA4" /><Text style={styles.addUpdateVoiceText}>ভয়েস রেকর্ড করুন</Text></TouchableOpacity> : null}
            <TouchableOpacity style={[styles.primaryButton, (createFounderUpdate.isPending || editFounderUpdate.isPending) && styles.disabledButton]} onPress={saveFounderUpdateDraft} disabled={createFounderUpdate.isPending || editFounderUpdate.isPending}>
              <Text style={styles.primaryButtonText}>{createFounderUpdate.isPending || editFounderUpdate.isPending ? "সংরক্ষণ হচ্ছে…" : editingFounderUpdate ? "পরিবর্তন সংরক্ষণ করুন" : "খসড়া সংরক্ষণ করুন"}</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        <Text style={styles.sectionTitle}>{isFounder ? "প্রকাশিত ও খসড়া" : "সর্বশেষ আপডেট"}</Text>
        {founderUpdates.isLoading ? <ActivityIndicator color="#0A7EA4" /> : null}
        {rows.map((entry) => {
          const mine = entry.update.authorId === user.id;
          return (
            <View key={entry.update.id} style={[styles.postCard, entry.update.status === "draft" && styles.draftPostCard]}>
              <View style={styles.updateCardHeader}>
                <View style={styles.personText}>
                  <Text style={styles.personName}>{displayName(entry.author)} · প্রতিষ্ঠাতা</Text>
                  <Text style={styles.meta}>@{entry.author.username || "fikir"} · {formatTime(entry.update.publishedAt ?? entry.update.updatedAt)}</Text>
                </View>
                {entry.update.status === "draft" ? <Text style={styles.draftBadge}>খসড়া</Text> : <Text style={styles.publishedBadge}>প্রকাশিত</Text>}
              </View>
              {entry.update.status === "draft" && entry.update.scheduledFor ? <Text style={styles.scheduleNote}>পরিকল্পিত প্রকাশ: {formatTime(entry.update.scheduledFor)}</Text> : null}
              {entry.update.body ? <Text selectable style={styles.postBody}>{entry.update.body}</Text> : null}
              {entry.update.imageUrls.length ? <View style={styles.feedImageGrid}>{entry.update.imageUrls.map((url, index) => <TouchableOpacity key={`${url}-${index}`} style={styles.feedImageWrap} onPress={() => setFullScreenImage(getMediaUrl(url))}><Image source={{ uri: getMediaUrl(url) }} style={styles.feedImage} /></TouchableOpacity>)}</View> : null}
              {entry.update.voiceUrl ? <View style={styles.founderUpdateVoice}><View style={styles.founderUpdateVoiceActions}><TouchableOpacity style={styles.founderUpdateVoicePlay} onPress={() => playAttachmentAudio(entry.update.voiceUrl!)}><Text style={styles.founderUpdateVoicePlayText}>▶ চালান</Text></TouchableOpacity><TouchableOpacity style={styles.founderUpdateVoiceSave} onPress={() => void saveChatAttachment(entry.update.voiceUrl!, "voice")}><Text style={styles.founderUpdateVoiceSaveText}>সংরক্ষণ</Text></TouchableOpacity></View><Text style={styles.founderUpdateVoiceDuration}>{entry.update.voiceDurationSeconds ? formatVoiceDuration(entry.update.voiceDurationSeconds) : "ভয়েস সংযুক্তি"}</Text></View> : null}
              {entry.update.linkUrl ? <View style={styles.linkPanel}><Text selectable style={styles.linkText}>{entry.update.linkUrl}</Text><View style={styles.chipRow}><TouchableOpacity style={styles.linkAction} onPress={() => copyFounderLink(entry.update.linkUrl!)}><Text style={styles.linkActionText}>কপি</Text></TouchableOpacity><TouchableOpacity style={styles.linkAction} onPress={() => openFounderLink(entry.update.linkUrl!)}><Text style={styles.linkActionText}>লিংক খুলুন</Text></TouchableOpacity></View></View> : null}
              {entry.update.status === "published" ? <View style={styles.reactionRow}>{(() => { const isReacting = reactToFounderUpdate.isPending && pendingReactionUpdateId === entry.update.id; return <><TouchableOpacity style={[styles.reactionButton, entry.update.myReaction === "👍" && styles.reactionButtonActive, isReacting && styles.reactionButtonLoading]} onPress={() => reactToFounderUpdate.mutate({ updateId: entry.update.id, emoji: "👍" })} disabled={reactToFounderUpdate.isPending}>{isReacting ? <View style={styles.reactionLoadingContent}><ActivityIndicator size="small" color="#0A7EA4" /><Text style={styles.reactionLoadingText}>পছন্দ সংরক্ষণ হচ্ছে…</Text></View> : <Text style={[styles.reactionButtonText, entry.update.myReaction === "👍" && styles.reactionButtonTextActive]}>{entry.update.myReaction === "👍" ? "👍 পছন্দ হয়েছে" : "👍 পছন্দ"}</Text>}</TouchableOpacity>{entry.update.reactionCounts.reduce((total, item) => total + item.count, 0) > 0 ? <TouchableOpacity style={styles.reactionCountButton} onPress={() => setSelectedReactionUpdate(entry)}><Text style={styles.reactionCountText}>{entry.update.reactionCounts.reduce((total, item) => total + item.count, 0)} জন পছন্দ করেছেন</Text></TouchableOpacity> : <Text style={styles.reactionEmptyText}>এখনো কোনো পছন্দ নেই</Text>}{isFounder ? <TouchableOpacity style={styles.viewCount} onPress={() => setSelectedViewerUpdate(entry)} accessibilityLabel={`${entry.update.viewCount} জন দর্শকের তালিকা দেখুন`}><MaterialIcons name="visibility" size={15} color="#0A7EA4" /><Text style={styles.viewCountText}>{entry.update.viewCount} জন দেখেছেন</Text></TouchableOpacity> : <View style={styles.viewCount}><MaterialIcons name="visibility" size={15} color="#5D7C91" /><Text style={[styles.viewCountText, styles.viewCountTextPassive]}>{entry.update.viewCount} জন দেখেছেন</Text></View>}</>; })()}</View> : null}
              {mine && isFounder ? <View style={styles.updateControls}>{entry.update.status === "draft" ? <TouchableOpacity style={styles.publishButton} onPress={() => publishFounderUpdate.mutate({ updateId: entry.update.id })}><Text style={styles.publishButtonText}>প্রকাশ করুন</Text></TouchableOpacity> : null}<TouchableOpacity style={styles.secondaryAction} onPress={() => beginFounderUpdateEdit(entry)}><Text style={styles.secondaryActionText}>সম্পাদনা</Text></TouchableOpacity><TouchableOpacity style={styles.dangerAction} onPress={() => Alert.alert("আপডেট মুছবেন?", "এটি স্থায়ীভাবে মুছে যাবে।", [{ text: "বাতিল", style: "cancel" }, { text: "মুছুন", style: "destructive", onPress: () => deleteFounderUpdate.mutate({ updateId: entry.update.id }) }])}><Text style={styles.dangerActionText}>মুছুন</Text></TouchableOpacity></View> : null}
            </View>
          );
        })}
        {!founderUpdates.isLoading && rows.length === 0 ? <Text style={styles.empty}>এখনো কোনো প্রতিষ্ঠাতা আপডেট প্রকাশিত হয়নি।</Text> : null}
        <View style={styles.futureCard}>
          <Text style={styles.sectionTitle}>পরবর্তী সংস্করণে</Text>
          <Text style={styles.helper}>স্টোরি/স্ট্যাটাস, ভিডিও স্ট্যাটাস, স্টিকার প্যাক, বার্তা প্রতিক্রিয়া, এন্ড-টু-এন্ড এনক্রিপশন সূচক, লাইভ লোকেশন ও কনট্যাক্ট শেয়ারিং—এই IMO/WhatsApp-ধাঁচের সুবিধাগুলো পরিকল্পনায় রাখা হয়েছে।</Text>
          <Text style={styles.comingSoon}>শীঘ্রই আসছে</Text>
        </View>
        <Modal visible={Boolean(selectedReactionUpdate)} transparent animationType="fade" onRequestClose={() => setSelectedReactionUpdate(null)}>
          <View style={styles.reactorModalBackdrop}>
            <View style={styles.reactorModalCard}>
              <View style={styles.reactorModalHeader}><View><Text style={styles.sectionTitle}>যারা পছন্দ করেছেন</Text><Text style={styles.helper}>এই প্রকাশিত আপডেটের 👍 রিঅ্যাকশন</Text></View><TouchableOpacity onPress={() => setSelectedReactionUpdate(null)}><Text style={styles.cancelLink}>বন্ধ করুন</Text></TouchableOpacity></View>
              {founderUpdateReactors.isLoading ? <ActivityIndicator color="#0A7EA4" /> : null}
              {((founderUpdateReactors.data ?? []) as FounderUpdateReactor[]).map((reactor) => <View key={reactor.userId} style={styles.reactorRow}>{reactor.avatarUrl ? <Image source={{ uri: getMediaUrl(reactor.avatarUrl) }} style={styles.reactorAvatar} /> : <View style={styles.reactorAvatar}><Text style={styles.reactorAvatarText}>{displayName(reactor).slice(0, 1)}</Text></View>}<View style={styles.personText}><Text style={styles.reactorName}>{displayName(reactor)}</Text><Text style={styles.reactorMeta}>@{reactor.username || "fikir"} · {formatTime(reactor.reactedAt)}</Text></View><Text style={styles.reactorEmoji}>{reactor.emoji}</Text></View>)}
              {!founderUpdateReactors.isLoading && (founderUpdateReactors.data ?? []).length === 0 ? <Text style={styles.empty}>এখনো কেউ পছন্দ করেননি।</Text> : null}
            </View>
          </View>
        </Modal>
        <Modal visible={Boolean(selectedViewerUpdate)} transparent animationType="fade" onRequestClose={() => setSelectedViewerUpdate(null)}>
          <View style={styles.reactorModalBackdrop}>
            <View style={styles.reactorModalCard}>
              <View style={styles.reactorModalHeader}><View><Text style={styles.sectionTitle}>যারা দেখেছেন</Text><Text style={styles.helper}>এই প্রকাশিত আপডেটটি যারা খুলেছেন</Text></View><TouchableOpacity onPress={() => setSelectedViewerUpdate(null)}><Text style={styles.cancelLink}>বন্ধ করুন</Text></TouchableOpacity></View>
              {founderUpdateViewers.isLoading ? <ActivityIndicator color="#0A7EA4" /> : null}
              <FlatList
                data={(founderUpdateViewers.data ?? []) as FounderUpdateViewer[]}
                keyExtractor={(viewer) => String(viewer.userId)}
                style={styles.reactorList}
                contentContainerStyle={styles.reactorListContent}
                renderItem={({ item: viewer }) => <View style={styles.reactorRow}>{viewer.avatarUrl ? <Image source={{ uri: getMediaUrl(viewer.avatarUrl) }} style={styles.reactorAvatar} /> : <View style={styles.reactorAvatar}><Text style={styles.reactorAvatarText}>{displayName(viewer).slice(0, 1)}</Text></View>}<View style={styles.personText}><Text style={styles.reactorName}>{displayName(viewer)}</Text><Text style={styles.reactorMeta}>@{viewer.username || "fikir"} · {formatTime(viewer.viewedAt)} দেখেছেন</Text></View><MaterialIcons name="visibility" size={17} color="#0A7EA4" /></View>}
                ListEmptyComponent={!founderUpdateViewers.isLoading ? <Text style={styles.empty}>এখনো কেউ এই আপডেটটি দেখেননি।</Text> : null}
              />
            </View>
          </View>
        </Modal>
      </ScrollView>
    );
  };

  const renderConversation = (groupMode: boolean) => {
    const messages = ((groupMode ? groupMessages.data : directMessages.data) ?? []) as unknown as MessageRow[];
    const title = groupMode ? activeGroup?.name ?? "গ্রুপ" : activePeer ? displayName(activePeer) : "চ্যাট";
    const visibleMessages = [...messages].reverse();
    const activeGroupSessions = groupMode ? ((groupCalls.data ?? []) as unknown as CallSessionRow[]).filter((session) => session.status === "active") : [];
    const incomingDirectCall = !groupMode
      ? ((directCalls.data ?? []) as unknown as CallSessionRow[]).find((session) => session.status === "requested" && session.recipientId === user.id && session.initiatorId === activePeer?.id)
      : null;
    const directPresence = ((peerPresence.data ?? []) as unknown as PresenceSnapshot[])[0] ?? null;
    const onlineGroupMemberCount = ((groupPresence.data ?? []) as unknown as PresenceSnapshot[]).filter((entry) => entry.online).length;
    const presenceText = groupMode ? `${onlineGroupMemberCount} সদস্য অনলাইন` : getPresenceLabel(directPresence);
    const incomingActivityLabel = incomingActivity.data?.[0]?.activity === "typing" ? "লিখছেন…" : incomingActivity.data?.[0]?.activity === "uploading_image" ? "ছবি পাঠাচ্ছেন…" : incomingActivity.data?.[0]?.activity === "uploading_file" ? "ফাইল পাঠাচ্ছেন…" : incomingActivity.data?.[0]?.activity === "recording_voice" ? "ভয়েস রেকর্ড করছেন…" : null;
    const uploadStep = chatUpload?.phase === "preparing" ? 1 : chatUpload?.phase === "uploading" || chatUpload?.phase === "cancelling" || chatUpload?.phase === "failed" ? 2 : 3;
    const uploadKindLabel = chatUpload?.kind === "image" ? "ছবি" : chatUpload?.kind === "voice" ? "ভয়েস বার্তা" : "ফাইল";
    const uploadPhaseLabel = chatUpload?.phase === "preparing" ? "প্রস্তুত করা হচ্ছে" : chatUpload?.phase === "uploading" ? "নিরাপদে আপলোড হচ্ছে" : chatUpload?.phase === "cancelling" ? "বাতিল করা হচ্ছে" : chatUpload?.phase === "failed" ? "পাঠানো যায়নি" : "বার্তা পাঠানো হচ্ছে";
    const uploadFailure = chatUpload?.failure ?? { kind: "unknown" as const, label: "আপলোড সমস্যা", message: "সংযুক্তিটি পাঠানো যায়নি।", retryable: true };
    const uploadFailureIcon = uploadFailure.kind === "network" ? "wifi-off" : uploadFailure.kind === "file" ? "insert-drive-file" : uploadFailure.kind === "permission" ? "lock-outline" : uploadFailure.kind === "server" ? "dns" : "error-outline";
    const renderAttachment = (entry: MessageRow, mine: boolean) => {
      const url = entry.message.attachmentUrl;
      if (!url) return null;
      const messageKind = entry.message.kind;
      if (messageKind === "image") {
        return <View><TouchableOpacity onPress={() => setFullScreenImage(getMediaUrl(url))}><Image source={{ uri: getMediaUrl(url) }} style={styles.messageImage} /></TouchableOpacity><View style={styles.attachmentActionRow}><TouchableOpacity onPress={() => void saveChatAttachment(url, "image")}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>গ্যালারিতে সংরক্ষণ</Text></TouchableOpacity><TouchableOpacity onPress={() => void Clipboard.setStringAsync(getMediaUrl(url))}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>লিংক কপি</Text></TouchableOpacity></View></View>;
      }
      if (messageKind === "voice") {
        return <View style={[styles.audioAttachment, mine && styles.audioAttachmentMine]}><TouchableOpacity onPress={() => playAttachmentAudio(url)}><Text style={[styles.audioAttachmentText, mine && styles.messageTextMine]}>▶ ভয়েস বার্তা চালান</Text></TouchableOpacity><View style={styles.attachmentActionRow}><TouchableOpacity onPress={() => void saveChatAttachment(url, "voice")}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>সংরক্ষণ</Text></TouchableOpacity><TouchableOpacity onPress={() => void Clipboard.setStringAsync(getMediaUrl(url))}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>লিংক কপি</Text></TouchableOpacity></View></View>;
      }
      const filename = getChatAttachmentFilename(url, "file");
      return <View style={[styles.fileAttachment, mine && styles.fileAttachmentMine]}><Text numberOfLines={1} style={[styles.fileAttachmentName, mine && styles.messageTextMine]}>ফাইল: {filename}</Text><View style={styles.attachmentActionRow}><TouchableOpacity onPress={() => void Linking.openURL(getMediaUrl(url))}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>খুলুন</Text></TouchableOpacity><TouchableOpacity onPress={() => void saveChatAttachment(url, "file")}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>সংরক্ষণ</Text></TouchableOpacity><TouchableOpacity onPress={() => void Clipboard.setStringAsync(getMediaUrl(url))}><Text style={[styles.attachmentActionText, mine && styles.messageTextMine]}>লিংক কপি</Text></TouchableOpacity></View></View>;
    };
    return (
      <KeyboardAvoidingView
        style={styles.chatPage}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 44 : 0}
      >
        {renderBack(title)}
        <View style={styles.presenceBar}><Text style={styles.presenceText}>{presenceText}</Text></View>
        {incomingActivityLabel ? <View style={styles.activityBanner}><Text style={styles.activityText}>{title} {incomingActivityLabel}</Text></View> : null}
        <View style={styles.callBar}>
          <Text style={styles.callNote}>{groupMode ? "গ্রুপের জন্য" : "ব্যক্তিগত"} কল-সেশন</Text>
          <TouchableOpacity style={styles.callAction} onPress={() => requestCall("audio")}><Text style={styles.callActionText}>অডিও</Text></TouchableOpacity>
          <TouchableOpacity style={styles.callAction} onPress={() => requestCall("video")}><Text style={styles.callActionText}>ভিডিও</Text></TouchableOpacity>
          {!groupMode ? <TouchableOpacity style={styles.clearChatAction} onPress={confirmClearDirectChat} disabled={clearDirectChat.isPending}><MaterialIcons name="delete-sweep" size={17} color="#A33D45" /><Text style={styles.clearChatActionText}>{clearDirectChat.isPending ? "খালি হচ্ছে…" : "চ্যাট খালি"}</Text></TouchableOpacity> : null}
        </View>
        {!groupMode && outgoingCall ? (
          <View style={styles.outgoingCallBanner}>
            <View style={styles.outgoingCallPulse}><MaterialIcons name={outgoingCall.kind === "video" ? "videocam" : "phone"} size={18} color="#FFFFFF" /></View>
            <View style={styles.outgoingCallCopy}><Text style={styles.outgoingCallTitle}>{outgoingCall.peerName}-এর কাছে কল যাচ্ছে…</Text><Text style={styles.outgoingCallText}>অপর প্রান্তে রিং হচ্ছে; গ্রহণ করলে কল স্বয়ংক্রিয়ভাবে শুরু হবে।</Text></View>
            <TouchableOpacity style={styles.cancelCallButton} onPress={cancelOutgoingCall} disabled={endCall.isPending}><Text style={styles.cancelCallText}>বাতিল</Text></TouchableOpacity>
          </View>
        ) : null}
        {incomingDirectCall ? (
          <View style={styles.incomingCallBanner}>
            <View style={styles.incomingCallIcon}><MaterialIcons name={incomingDirectCall.kind === "video" ? "videocam" : "phone-in-talk"} size={18} color="#FFFFFF" /></View>
            <View style={styles.incomingCallCopy}><Text style={styles.incomingCallTitle}>{title} {incomingDirectCall.kind === "video" ? "ভিডিও" : "অডিও"} কল করছেন</Text><Text style={styles.incomingCallText}>চ্যাট না ছেড়েই গ্রহণ করলে সরাসরি কল শুরু হবে।</Text></View>
            <View style={styles.incomingCallActions}><TouchableOpacity style={styles.declineCallButton} onPress={() => respondDirectCall.mutate({ sessionId: incomingDirectCall.id, status: "declined" })} disabled={respondDirectCall.isPending}><Text style={styles.declineCallText}>না</Text></TouchableOpacity><TouchableOpacity style={styles.acceptCallButton} onPress={() => respondDirectCall.mutate({ sessionId: incomingDirectCall.id, status: "active" }, { onSuccess: () => void prepareLiveCall({ ...incomingDirectCall, status: "active" }, title) })} disabled={respondDirectCall.isPending}><Text style={styles.acceptCallText}>{respondDirectCall.isPending ? "…" : "গ্রহণ"}</Text></TouchableOpacity></View>
          </View>
        ) : null}
        {groupMode && activeGroupSessions.length > 0 ? (
          <View style={styles.activeGroupCalls}>
            <Text style={styles.activeGroupCallLabel}>সক্রিয় গ্রুপ কল</Text>
            {activeGroupSessions.map((session) => (
              <TouchableOpacity key={session.id} style={styles.activeGroupCallButton} onPress={() => void prepareLiveCall(session, title)}>
                <Text style={styles.activeGroupCallText}>{session.kind === "video" ? "ভিডিও কলে যোগ দিন" : "অডিও কলে যোগ দিন"}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ) : null}
        <ScrollView contentContainerStyle={styles.chatScroll} keyboardShouldPersistTaps="handled" keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}>
          {visibleMessages.map((entry) => {
            const mine = entry.message.senderId === user.id;
            const receiptText = mine
              ? groupMode
                ? getGroupReceiptLabel(entry.receipt)
                : getDirectReceiptLabel(entry.message.status)
              : "";
            return (
              <TouchableOpacity key={entry.message.id} onLongPress={() => openMessageActions(entry)} style={[styles.messageRow, mine ? styles.messageRowMine : styles.messageRowOther]}>
                {!mine && groupMode ? <Text style={styles.senderName}>{displayName(entry.sender)}</Text> : null}
                {entry.message.body ? <Text style={[styles.messageText, mine && styles.messageTextMine]}>{entry.message.body}</Text> : null}
                {renderAttachment(entry, mine)}
                <Text style={[styles.messageMeta, mine && styles.messageTextMine]}>{formatTime(entry.message.createdAt)}{entry.message.editedAt ? " · সম্পাদিত" : ""}{receiptText ? ` · ${receiptText}` : ""}</Text>
              </TouchableOpacity>
            );
          })}
          {visibleMessages.length === 0 ? <Text style={styles.empty}>এখানে এখনো কোনো অনলাইন বার্তা নেই।</Text> : null}
          {groupMode ? renderGroupManager() : null}
        </ScrollView>
        {chatUpload ? (
          <View style={[styles.uploadProgressCard, chatUpload.phase === "failed" && styles.uploadProgressCardFailed]} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 3, now: uploadStep }}>
            <View style={styles.uploadProgressHeader}>
              <View style={[styles.uploadStatusIcon, chatUpload.phase === "failed" && styles.uploadStatusIconFailed]}>{chatUpload.phase === "failed" ? <MaterialIcons name={uploadFailureIcon} size={17} color="#FFFFFF" /> : <ActivityIndicator size="small" color="#FFFFFF" />}</View>
              <View style={styles.uploadProgressCopy}>
                <Text style={[styles.uploadProgressTitle, chatUpload.phase === "failed" && styles.uploadProgressTitleFailed]}>{uploadKindLabel} · {uploadPhaseLabel}</Text>
                <Text numberOfLines={1} style={styles.uploadProgressFilename}>{chatUpload.filename}</Text>
              </View>
              <Text style={[styles.uploadProgressStep, chatUpload.phase === "failed" && styles.uploadProgressStepFailed]}>{chatUpload.phase === "failed" ? uploadFailure.retryable ? "পুনঃচেষ্টা" : "করণীয়" : `ধাপ ${uploadStep}/৩`}</Text>
            </View>
            <View style={styles.uploadProgressTrack}>
              <View style={[styles.uploadProgressFill, chatUpload.phase === "failed" ? styles.uploadProgressFailed : uploadStep === 1 ? styles.uploadProgressPreparing : uploadStep === 2 ? styles.uploadProgressUploading : styles.uploadProgressSending]} />
            </View>
            <View style={styles.uploadProgressFooter}>
              <View style={styles.uploadProgressMessage}>
                {chatUpload.phase === "failed" ? <View style={styles.uploadFailureBadge}><MaterialIcons name={uploadFailureIcon} size={13} color="#8D1D15" /><Text style={styles.uploadFailureBadgeText}>{uploadFailure.label}</Text></View> : null}
                <Text style={[styles.uploadProgressHint, chatUpload.phase === "failed" && styles.uploadProgressHintFailed]}>{chatUpload.phase === "failed" ? chatUpload.errorMessage ?? uploadFailure.message : chatUpload.phase === "cancelling" ? "প্রেরণের আগে সংযুক্তিটি বাতিল করা হচ্ছে।" : "সংযুক্তি নিরাপদে পাঠানো শেষ না হওয়া পর্যন্ত এই চ্যাটটি খোলা রাখুন।"}</Text>
              </View>
              {chatUpload.phase === "preparing" || chatUpload.phase === "uploading" ? <TouchableOpacity onPress={cancelChatUpload} accessibilityLabel="সংযুক্তি পাঠানো বাতিল করুন"><Text style={styles.cancelUploadText}>বাতিল</Text></TouchableOpacity> : null}
              {chatUpload.phase === "failed" ? <View style={styles.uploadFailureActions}>{uploadFailure.retryable ? <TouchableOpacity style={styles.retryUploadButton} onPress={retryFailedChatUpload} accessibilityLabel="সংযুক্তি পুনরায় চেষ্টা করুন"><Text style={styles.retryUploadText}>পুনরায় চেষ্টা করুন</Text></TouchableOpacity> : null}<TouchableOpacity onPress={dismissFailedChatUpload} accessibilityLabel="ব্যর্থ সংযুক্তি বাদ দিন"><Text style={styles.dismissUploadText}>বাদ দিন</Text></TouchableOpacity></View> : null}
            </View>
          </View>
        ) : null}
        {replyingTo || editingMessage ? <View style={styles.replyBar}><View style={styles.replyCopy}><Text style={styles.replyTitle}>{editingMessage ? "বার্তা সম্পাদনা" : `উত্তর: ${displayName(replyingTo!.sender)}`}</Text><Text numberOfLines={1} style={styles.replyPreview}>{(editingMessage ?? replyingTo)!.message.body}</Text></View><TouchableOpacity onPress={() => { setReplyingTo(null); setEditingMessage(null); setMessageText(""); }}><Text style={styles.cancelReply}>×</Text></TouchableOpacity></View> : null}
        {isRecordingVoice ? (
          <View style={styles.voiceRecordingBar}>
            <Text style={styles.voiceRecordingText}>রেকর্ড হচ্ছে · {String(Math.floor(recorderState.durationMillis / 60000)).padStart(2, "0")}:{String(Math.floor((recorderState.durationMillis % 60000) / 1000)).padStart(2, "0")}</Text>
            <TouchableOpacity style={styles.voiceControl} onPress={() => void toggleVoiceRecording()}><Text style={styles.voiceControlText}>{isVoicePaused ? "চালু" : "বিরতি"}</Text></TouchableOpacity>
            <TouchableOpacity style={styles.voiceCancel} onPress={() => void cancelVoiceRecording()}><Text style={styles.voiceCancelText}>বাতিল</Text></TouchableOpacity>
            <TouchableOpacity style={styles.sendButton} onPress={() => void sendVoiceRecording()}><Text style={styles.sendText}>পাঠান</Text></TouchableOpacity>
          </View>
        ) : (
          <View style={styles.composerArea}>
            <View style={styles.attachmentGuidance} accessibilityRole="summary" accessible accessibilityLabel="সংযুক্তি পাঠানোর নিয়ম: ছবি JPG, PNG বা WEBP; ফাইল PDF, TXT, DOC, DOCX, XLS, XLSX বা ZIP; ভয়েস M4A, MP3, WAV, OGG বা WEBM। সর্বোচ্চ ফাইল আকার ১০ MB।">
              <View style={styles.attachmentGuidanceHeader}>
                <MaterialIcons name="info-outline" size={16} color="#0A7EA4" />
                <Text style={styles.attachmentGuidanceTitle}>সংযুক্তি পাঠানোর নিয়ম</Text>
                <View style={styles.attachmentSizeBadge}><Text style={styles.attachmentSizeBadgeText}>সর্বোচ্চ ১০ MB</Text></View>
              </View>
              <View style={styles.attachmentGuidanceItems}>
                <View style={styles.attachmentGuidanceItem}><MaterialIcons name="image" size={14} color="#0A7EA4" /><Text style={styles.attachmentGuidanceText}>ছবি: JPG, PNG, WEBP</Text></View>
                <View style={styles.attachmentGuidanceItem}><MaterialIcons name="insert-drive-file" size={14} color="#0A7EA4" /><Text style={styles.attachmentGuidanceText}>ফাইল: PDF, TXT, DOC/DOCX, XLS/XLSX, ZIP</Text></View>
                <View style={styles.attachmentGuidanceItem}><MaterialIcons name="mic" size={14} color="#0A7EA4" /><Text style={styles.attachmentGuidanceText}>ভয়েস: M4A, MP3, WAV, OGG, WEBM</Text></View>
              </View>
            </View>
            <View style={styles.composer}>
              <TouchableOpacity style={[styles.attachmentButton, chatUpload && styles.attachmentButtonDisabled]} onPress={() => void pickChatImage()} disabled={Boolean(chatUpload)}><Text style={styles.attachmentButtonText}>ছবি</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.attachmentButton, chatUpload && styles.attachmentButtonDisabled]} onPress={() => void pickChatFile()} disabled={Boolean(chatUpload)}><Text style={styles.attachmentButtonText}>ফাইল</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.attachmentButton, chatUpload && styles.attachmentButtonDisabled]} onPress={() => void startVoiceRecording()} disabled={Boolean(chatUpload)}><Text style={styles.attachmentButtonText}>ভয়েস</Text></TouchableOpacity>
              <TextInput value={messageText} onChangeText={setMessageText} placeholder={chatUpload ? "সংযুক্তি পাঠানো হচ্ছে…" : "বার্তা লিখুন"} multiline style={styles.composerInput} editable={!chatUpload} />
              <TouchableOpacity style={[styles.sendButton, (!messageText.trim() || chatUpload) && styles.disabledButton]} onPress={sendMessage} disabled={!messageText.trim() || Boolean(chatUpload)}><Text style={styles.sendText}>পাঠান</Text></TouchableOpacity>
            </View>
          </View>
        )}
      </KeyboardAvoidingView>
    );
  };

  const renderGroupManager = () => {
    if (!activeGroup) return null;
    const members = (groupMembers.data ?? []) as unknown as MemberRow[];
    return (
      <View style={styles.managerCard}>
        <Text style={styles.sectionTitle}>গ্রুপের সদস্য ও নিয়ন্ত্রণ</Text>
        {canManageActiveGroup ? (
          <View style={styles.groupSettingsCard}>
            <Text style={styles.label}>সদস্য খুঁজে যোগ করুন</Text>
            <TextInput value={memberSearch} onChangeText={setMemberSearch} style={styles.input} placeholder="নাম বা @ইউজারনেম লিখুন" autoCapitalize="none" />
            {memberSearch.trim().length > 0 ? (
              <View style={styles.groupSettingsCard}>
                {((searchedGroupMembers.data ?? []) as unknown as ProfileRow[])
                  .filter((person) => !members.some((member) => member.user.id === person.id))
                  .map((person) => (
                    <View key={person.id} style={styles.memberRow}>
                      <View style={styles.personText}>
                        <Text style={styles.personName}>{displayName(person)}</Text>
                        <Text style={styles.meta}>@{person.username || "—"}</Text>
                      </View>
                      <TouchableOpacity disabled={inviteMember.isPending} onPress={() => inviteMember.mutate({ groupId: activeGroup.id, userId: person.id })}>
                        <Text style={styles.openText}>{inviteMember.isPending ? "যোগ হচ্ছে…" : "যোগ করুন"}</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
                {!searchedGroupMembers.isLoading && ((searchedGroupMembers.data ?? []) as unknown as ProfileRow[]).filter((person) => !members.some((member) => member.user.id === person.id)).length === 0 ? <Text style={styles.meta}>নতুন কোনো ব্যবহারকারী পাওয়া যায়নি।</Text> : null}
              </View>
            ) : null}
            <Text style={styles.label}>গ্রুপের নাম</Text>
            <TextInput value={groupSettingsName} onChangeText={setGroupSettingsName} style={styles.input} placeholder="গ্রুপের নাম" />
            <Text style={styles.label}>বিবরণ ও নিয়ম</Text>
            <TextInput value={groupSettingsDescription} onChangeText={setGroupSettingsDescription} style={[styles.input, styles.multiline]} placeholder="গ্রুপের উদ্দেশ্য ও নিয়ম" multiline />
            <Text style={styles.label}>গোপনীয়তা</Text>
            <View style={styles.chipRow}>
              {(["public", "approval", "private"] as const).map((item) => (
                <TouchableOpacity key={item} style={[styles.chip, groupSettingsPrivacy === item && styles.chipActive]} onPress={() => setGroupSettingsPrivacy(item)}>
                  <Text style={[styles.chipText, groupSettingsPrivacy === item && styles.chipTextActive]}>{item === "public" ? "সবার জন্য" : item === "approval" ? "অনুমোদন" : "শুধু আমন্ত্রণ"}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.toggleRow}>
              <Text style={styles.toggleLabel}>শুধু অ্যাডমিনের ঘোষণা</Text>
              <Switch value={groupSettingsAnnouncementsOnly} onValueChange={setGroupSettingsAnnouncementsOnly} trackColor={{ true: "#0A7EA4" }} />
            </View>
            <TouchableOpacity style={styles.primaryButtonSmall} onPress={() => updateGroup.mutate({ groupId: activeGroup.id, name: groupSettingsName, description: groupSettingsDescription || null, privacy: groupSettingsPrivacy, isAnnouncementsOnly: groupSettingsAnnouncementsOnly })}>
              <Text style={styles.primaryButtonText}>সেটিংস সংরক্ষণ</Text>
            </TouchableOpacity>
            {currentMembership?.role === "owner" ? (
              <TouchableOpacity onPress={() => Alert.alert("গ্রুপ মুছবেন?", "এই সিদ্ধান্ত ফিরিয়ে আনা যাবে না; গ্রুপের সদস্য, পোস্ট, বার্তা এবং কল-সেশন মুছে যাবে।", [{ text: "বাতিল", style: "cancel" }, { text: "গ্রুপ মুছুন", style: "destructive", onPress: () => deleteGroup.mutate({ groupId: activeGroup.id }) }])}>
                <Text style={styles.removeText}>গ্রুপটি স্থায়ীভাবে মুছুন</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        ) : null}
        {members.map((entry) => (
          <View key={entry.user.id} style={styles.memberRow}>
            <View style={styles.personText}>
              <Text style={styles.personName}>{displayName(entry.user)}</Text>
              <Text style={styles.meta}>@{entry.user.username || "—"} · {entry.membership.role} · {entry.membership.state}</Text>
            </View>
            {canManageActiveGroup && entry.user.id !== user.id ? (
              <View style={styles.memberActions}>
                {entry.membership.state === "pending" ? <TouchableOpacity onPress={() => manageMember.mutate({ groupId: activeGroup.id, userId: entry.user.id, state: "active" })}><Text style={styles.openText}>অনুমোদন</Text></TouchableOpacity> : null}
                {entry.membership.state === "active" && entry.membership.role === "member" ? <TouchableOpacity onPress={() => manageMember.mutate({ groupId: activeGroup.id, userId: entry.user.id, role: "admin" })}><Text style={styles.openText}>অ্যাডমিন</Text></TouchableOpacity> : null}
                {entry.membership.role !== "owner" ? <TouchableOpacity onPress={() => manageMember.mutate({ groupId: activeGroup.id, userId: entry.user.id, state: "removed" })}><Text style={styles.removeText}>সরান</Text></TouchableOpacity> : null}
              </View>
            ) : null}
          </View>
        ))}
      </View>
    );
  };

  const renderCalls = () => {
    const sessions = (directCalls.data ?? []) as unknown as CallSessionRow[];
    const removableSessions = sessions.filter((session) => session.status === "declined" || session.status === "missed" || session.status === "ended");
    return (
      <ScrollView contentContainerStyle={styles.scroll}>
        {renderBack("কল-সেশন")}
        <View style={styles.notice}><Text style={styles.noticeText}>নোটিফিকেশনে ‘গ্রহণ’ চাপলেই প্রাপক সরাসরি নিরাপদ LiveKit room-এ যুক্ত হবে; প্রেরকের অ্যাপও স্বয়ংক্রিয়ভাবে সংযুক্ত হবে। Android বা iOS development build-এ Microphone/Camera অনুমতি দিন। উত্তর না এলে মিসড কল হোমের সূচক ও কল ইতিহাসে জমা থাকবে।</Text></View>
        <View style={styles.callHistoryHeader}><View><Text style={styles.sectionTitle}>ব্যক্তিগত কল-সেশন</Text><Text style={styles.sectionSubtitle}>চলমান কল নিরাপদ রাখতে শুধু শেষ হওয়া রেকর্ড মুছতে পারবেন</Text></View><TouchableOpacity disabled={!removableSessions.length || clearCallHistory.isPending} onPress={() => confirmClearCallHistory(removableSessions.length)} style={[styles.clearHistoryButton, (!removableSessions.length || clearCallHistory.isPending) && styles.mutedActionButton]} accessibilityLabel="সমস্ত ব্যক্তিগত কল ইতিহাস মুছুন"><MaterialIcons name="delete-sweep" size={16} color="#A84444" /><Text style={styles.clearHistoryButtonText}>{clearCallHistory.isPending ? "মুছছে…" : "সব মুছুন"}</Text></TouchableOpacity></View>
        {sessions.map((session) => {
          const incoming = session.recipientId === user.id && session.status === "requested";
          const initiated = session.initiatorId === user.id;
          return (
            <View key={session.id} style={styles.callCard}>
              <View style={styles.personText}>
                <Text style={styles.personName}>{session.kind === "audio" ? "অডিও কল" : "ভিডিও কল"}</Text>
                <Text style={styles.meta}>{incoming ? "আপনার কাছে কল অনুরোধ" : initiated ? "আপনার পাঠানো কল অনুরোধ" : "কল-সেশন"} · {formatTime(session.createdAt)}</Text>
                <Text style={styles.callStatus}>{session.status === "requested" ? "সিদ্ধান্তের অপেক্ষায়" : session.status === "active" ? "সক্রিয় প্রস্তুত" : session.status === "declined" ? "প্রত্যাখ্যাত" : "সমাপ্ত"}</Text>
              </View>
              <View style={styles.memberActions}>
                {incoming ? <><TouchableOpacity onPress={() => acceptDirectCall(session)}><Text style={styles.openText}>গ্রহণ</Text></TouchableOpacity><TouchableOpacity onPress={() => respondDirectCall.mutate({ sessionId: session.id, status: "declined" })}><Text style={styles.removeText}>প্রত্যাখ্যান</Text></TouchableOpacity></> : null}
                {session.status === "active" ? <TouchableOpacity onPress={() => void prepareLiveCall(session, "ব্যক্তিগত কল")}><Text style={styles.openText}>যোগ দিন</Text></TouchableOpacity> : null}
                {(initiated || session.recipientId === user.id) && (session.status === "requested" || session.status === "active") ? <TouchableOpacity onPress={() => endCall.mutate({ sessionId: session.id })}><Text style={styles.removeText}>শেষ করুন</Text></TouchableOpacity> : null}
                {(session.status === "declined" || session.status === "missed" || session.status === "ended") ? <TouchableOpacity onPress={() => confirmDeleteCallHistoryEntry(session.id)} disabled={deleteCallHistoryEntry.isPending || clearCallHistory.isPending} style={styles.deleteCallHistoryButton} accessibilityLabel="কল ইতিহাস মুছুন"><MaterialIcons name="delete-outline" size={18} color="#A84444" /></TouchableOpacity> : null}
              </View>
            </View>
          );
        })}
        {sessions.length === 0 ? <Text style={styles.empty}>এখনো কোনো ব্যক্তিগত কল-সেশন নেই। কাউকে খুঁজে চ্যাট খুলে অডিও বা ভিডিও বাটন চাপুন।</Text> : null}
      </ScrollView>
    );
  };

  const renderHome = () => (
    <ScrollView contentContainerStyle={styles.scroll}>
      <View style={styles.homeHeader}>
        <TouchableOpacity onPress={onBack} style={styles.backButton}><Text style={styles.backText}>‹</Text></TouchableOpacity>
        <View style={styles.personText}>
          <Text style={styles.headerTitle}>ফিকির কমিউনিটি</Text>
          <Text style={styles.meta}>অনলাইন পরিচয়, গ্রুপ ও আপডেট</Text>
        </View>
      </View>
      <View style={styles.identityCard}>
        <View style={styles.avatarLarge}><Text style={styles.avatarText}>{displayName(profile.data ?? user).slice(0, 1)}</Text></View>
        <View style={styles.personText}>
          <Text style={styles.personName}>{displayName(profile.data ?? user)}</Text>
          <Text style={styles.meta}>@{profile.data?.username || "ইউজারনেম সেট করুন"}</Text>
          <Text style={styles.meta}>{user.email}</Text>
        </View>
        <TouchableOpacity onPress={() => setSection("profile")}><Text style={styles.openText}>সম্পাদনা</Text></TouchableOpacity>
      </View>
      {!profile.data?.username ? <View style={styles.notice}><Text style={styles.noticeText}>চ্যাট ও গ্রুপে অন্যরা আপনাকে সহজে খুঁজতে একটি স্বতন্ত্র ইউজারনেম সেট করুন।</Text><TouchableOpacity onPress={() => setSection("profile")}><Text style={styles.openText}>এখন সেট করুন</Text></TouchableOpacity></View> : null}
      {offlineMessageCount > 0 || (offlineSummary?.missedCalls.length ?? 0) > 0 ? (
        <View style={styles.offlineNotice}>
          <View style={styles.offlineNoticeHeader}>
            <View style={styles.offlineNoticeTitleRow}>
              <MaterialIcons name="cloud-done" size={22} color="#9A6500" />
              <Text style={styles.offlineNoticeTitle}>সংযোগ ফিরে এসেছে</Text>
            </View>
            {offlineInbox.isFetching ? <ActivityIndicator size="small" color="#9A6500" /> : null}
          </View>
          {offlineMessageCount > 0 ? <Text style={styles.offlineNoticeText}>{offlineMessageCount} টি অপঠিত বার্তা{offlineSenderNames.length ? ` — ${offlineSenderNames.join("، ")}${offlineMessageCount > offlineSenderNames.length ? "সহ আরও" : ""}` : ""}</Text> : null}
          {(offlineSummary?.missedCalls.length ?? 0) > 0 ? (
            <TouchableOpacity style={styles.offlineCallAction} onPress={openMissedCallInbox}>
              <View style={styles.offlineCallActionCopy}>
                <MaterialIcons name="phone-missed" size={19} color="#B14343" />
                <Text style={styles.offlineCallActionText}>{offlineSummary?.missedCalls.length} টি মিসড কল দেখুন</Text>
              </View>
              <MaterialIcons name="chevron-right" size={23} color="#B14343" />
            </TouchableOpacity>
          ) : null}
          <Text style={styles.offlineNoticeHint}>বার্তা পড়তে ব্যক্তি বা গ্রুপের চ্যাট খুলুন। মিসড কলের সময় ও পুনরায় কল করার বাটন এখানে পাওয়া যাবে।</Text>
        </View>
      ) : null}
      <View style={styles.grid}>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("chats")}>
          <View style={styles.tileTitleRow}><Text style={styles.tileIcon}>✉</Text>{unreadChatTotal > 0 ? <View style={styles.homeUnreadBadge}><Text style={styles.homeUnreadBadgeText}>{formatUnreadBadgeCount(unreadChatTotal)}</Text></View> : null}</View>
          <Text style={styles.tileTitle}>চ্যাট</Text><Text style={styles.tileText}>{unreadChatTotal > 0 ? `${formatUnreadBadgeCount(unreadChatTotal)} নতুন বার্তা` : "সব বার্তা পড়া হয়েছে"}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("people")}><Text style={styles.tileIcon}>⌕</Text><Text style={styles.tileTitle}>মানুষ খুঁজুন</Text><Text style={styles.tileText}>নাম বা ইউজারনেমে খোঁজ</Text></TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("groups")}><Text style={styles.tileIcon}>◉</Text><Text style={styles.tileTitle}>গ্রুপ</Text><Text style={styles.tileText}>তৈরি করুন ও অংশ নিন</Text></TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("social")}><Text style={styles.tileIcon}>◎</Text><Text style={styles.tileTitle}>সবার ফিকির</Text><Text style={styles.tileText}>সবার পোস্ট, ছবি ও লিংক</Text></TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("updates")}><Text style={styles.tileIcon}>✦</Text><Text style={styles.tileTitle}>প্রতিষ্ঠাতা আপডেট</Text><Text style={styles.tileText}>প্রতিষ্ঠাতার ঘোষণাগুলো</Text></TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("calls")}><View style={styles.tileTitleRow}><Text style={styles.tileIcon}>◌</Text>{(missedCallHistory.data?.length ?? 0) > 0 ? <View style={styles.homeUnreadBadge}><Text style={styles.homeUnreadBadgeText}>{formatUnreadBadgeCount(missedCallHistory.data?.length ?? 0)}</Text></View> : null}</View><Text style={styles.tileTitle}>অডিও/ভিডিও কল</Text><Text style={styles.tileText}>{(missedCallHistory.data?.length ?? 0) > 0 ? `${missedCallHistory.data?.length} টি মিসড কল` : "কল-সেশন ও অনুরোধ"}</Text></TouchableOpacity>
        <TouchableOpacity style={styles.tile} onPress={() => setSection("settings")}><Text style={styles.tileIcon}>⚙</Text><Text style={styles.tileTitle}>সেটিংস</Text><Text style={styles.tileText}>সাউন্ড ও ভাইব্রেশন</Text></TouchableOpacity>
        {isFounder ? <TouchableOpacity style={styles.tile} onPress={() => setSection("admin")}><Text style={styles.tileIcon}>◆</Text><Text style={styles.tileTitle}>প্রতিষ্ঠাতা নিয়ন্ত্রণ</Text><Text style={styles.tileText}>আপডেট, রিপোর্ট ও নিরাপত্তা</Text></TouchableOpacity> : null}
      </View>
      <View style={styles.homeSearchBlock}>
        <View style={styles.homeSearchInputWrap}>
          <MaterialIcons name="search" size={21} color="#4D7790" />
          <TextInput
            style={styles.homeSearchInput}
            value={homeSearch}
            onChangeText={setHomeSearch}
            placeholder="নাম, ইউজারনেম বা শেষ বার্তা খুঁজুন"
            placeholderTextColor="#7A98AA"
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            accessibilityLabel="কথোপকথন বা পরিচিতি খুঁজুন"
          />
          {homeSearch.length > 0 ? <TouchableOpacity style={styles.clearHomeSearchButton} onPress={() => setHomeSearch("")} accessibilityLabel="সার্চ মুছুন"><MaterialIcons name="close" size={19} color="#477087" /></TouchableOpacity> : null}
        </View>
        <Text style={styles.homeSearchHint}>কথোপকথনের নাম, @ইউজারনেম বা শেষ বার্তার লেখা দিয়ে খুঁজুন</Text>
      </View>
      <View style={styles.recentSectionHeader}>
        <View><Text style={styles.sectionTitle}>{homeSearch.trim() ? "কথোপকথনে মিল" : "সাম্প্রতিক কথোপকথন"}</Text><Text style={styles.sectionSubtitle}>{homeSearch.trim() ? `${filteredRecentConversationRows.length} টি মিল পাওয়া গেছে` : "সর্বশেষ বার্তা অনুযায়ী সাজানো"}</Text></View>
        {recentConversations.isFetching ? <ActivityIndicator size="small" color="#0A7EA4" /> : null}
      </View>
      <FlatList
        data={filteredRecentConversationRows}
        scrollEnabled={false}
        keyExtractor={(item) => `${item.kind}-${item.id}`}
        contentContainerStyle={filteredRecentConversationRows.length === 0 ? styles.recentEmptyList : undefined}
        ListEmptyComponent={recentConversations.isLoading ? <ActivityIndicator color="#0A7EA4" /> : <Text style={styles.empty}>{homeSearch.trim() ? "কোনো সাম্প্রতিক কথোপকথনে এই লেখাটি পাওয়া যায়নি। নিচের পরিচিতি ফলাফল দেখুন।" : "এখনো কোনো কথোপকথন নেই। মানুষ খুঁজে বার্তা পাঠালে তা এখানে দেখা যাবে।"}</Text>}
        renderItem={({ item }) => {
          const isDirect = item.kind === "direct";
          const member = isDirect ? item as Extract<RecentConversationRow, { kind: "direct" }> : null;
          const preview = getRecentMessagePreview({ body: item.lastMessage.body, kind: item.lastMessage.kind as "text" | "image" | "file" | "voice" });
          return (
            <View style={styles.recentConversationRow}>
              {member ? <TouchableOpacity style={styles.recentIdentity} onPress={() => openMemberProfile({ id: member.id, name: member.name, username: member.username, avatarUrl: member.avatarUrl, bio: null, role: null })} accessibilityLabel={`${displayName(member)}-এর প্রোফাইল খুলুন`}>
                <View style={styles.recentAvatar}>{member.avatarUrl ? <Image source={{ uri: getMediaUrl(member.avatarUrl) }} style={styles.recentAvatarImage} /> : <Text style={styles.recentAvatarText}>{displayName(member).slice(0, 1)}</Text>}</View>
                <View style={styles.recentConversationText}><View style={styles.recentNameRow}><Text style={styles.recentConversationName} numberOfLines={1}>{displayName(member)}</Text><View style={[styles.presenceDot, member.online ? styles.presenceDotOnline : styles.presenceDotOffline]} /><Text style={[styles.recentPresenceLabel, member.online ? styles.recentPresenceOnline : styles.recentPresenceOffline]}>{member.online ? "অনলাইন" : "অফলাইন"}</Text></View><Text style={[styles.recentConversationPreview, member.unreadCount > 0 && styles.recentUnreadPreview]} numberOfLines={1}>{item.lastMessage.senderId === user.id ? `আপনি: ${preview}` : preview}</Text></View>
              </TouchableOpacity> : <TouchableOpacity style={styles.recentIdentity} onPress={() => void openRecentConversation(item)} accessibilityLabel={`${item.name} গ্রুপ খুলুন`}>
                <View style={[styles.recentAvatar, styles.groupRecentAvatar]}><MaterialIcons name="groups" size={23} color="#0A6D9A" /></View>
                <View style={styles.recentConversationText}><Text style={styles.recentConversationName} numberOfLines={1}>{item.name}</Text><Text style={[styles.recentConversationPreview, item.unreadCount > 0 && styles.recentUnreadPreview]} numberOfLines={1}>{item.lastMessage.senderId === user.id ? `আপনি: ${preview}` : preview}</Text></View>
              </TouchableOpacity>}
              <View style={styles.recentConversationMeta}><Text style={styles.recentConversationTime}>{formatTime(item.lastMessage.createdAt)}</Text>{item.unreadCount > 0 ? <View style={styles.recentUnreadBadge}><Text style={styles.recentUnreadBadgeText}>{formatUnreadBadgeCount(item.unreadCount)}</Text></View> : null}<TouchableOpacity style={styles.recentOpenButton} onPress={() => void openRecentConversation(item)} accessibilityLabel={`${member ? displayName(member) : item.name}-এর চ্যাট খুলুন`}><MaterialIcons name="chat" size={18} color="#0A6D9A" /></TouchableOpacity></View>
            </View>
          );
        }}
      />
      {homeSearch.trim() ? (
        <View style={styles.homePeopleResults}>
          <View style={styles.recentSectionHeader}>
            <View><Text style={styles.sectionTitle}>পরিচিতি ফলাফল</Text><Text style={styles.sectionSubtitle}>নাম বা ইউজারনেমে পাওয়া সদস্য</Text></View>
            {homeSearchedPeople.isFetching ? <ActivityIndicator size="small" color="#0A7EA4" /> : null}
          </View>
          <FlatList
            data={homeSearchPeopleRows}
            scrollEnabled={false}
            keyExtractor={(person) => `profile-${person.id}`}
            contentContainerStyle={homeSearchPeopleRows.length === 0 ? styles.recentEmptyList : undefined}
            ListEmptyComponent={homeSearchedPeople.isFetching ? null : <Text style={styles.empty}>এই নামে বা ইউজারনেমে কোনো পরিচিতি পাওয়া যায়নি।</Text>}
            renderItem={({ item: person }) => (
              <View style={styles.homeSearchPersonRow}>
                <TouchableOpacity style={styles.homeSearchPersonIdentity} onPress={() => openMemberProfile(person)} accessibilityLabel={`${displayName(person)}-এর প্রোফাইল খুলুন`}>
                  <View style={styles.recentAvatar}>{person.avatarUrl ? <Image source={{ uri: getMediaUrl(person.avatarUrl) }} style={styles.recentAvatarImage} /> : <Text style={styles.recentAvatarText}>{displayName(person).slice(0, 1)}</Text>}</View>
                  <View style={styles.recentConversationText}><Text style={styles.recentConversationName} numberOfLines={1}>{displayName(person)}</Text><Text style={styles.recentConversationPreview} numberOfLines={1}>@{person.username || "ইউজারনেম নেই"}</Text></View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.recentOpenButton} onPress={() => openDirect(person)} accessibilityLabel={`${displayName(person)}-কে বার্তা পাঠান`}><MaterialIcons name="chat" size={18} color="#0A6D9A" /></TouchableOpacity>
              </View>
            )}
          />
        </View>
      ) : null}
      <View style={styles.founderCard}>
        <Text style={styles.founderBadge}>প্রতিষ্ঠাতা পরিচিতি</Text>
        <Text style={styles.founderName}>মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন</Text>
        <Text style={styles.founderBio}>জামিয়া ইসলামিয়া আব্বাসিয়া কৌড়িয়া ইসলামাবাদ, বিশ্বনাথ, সিলেট থেকে ২০২৫ সালে দাওরায়ে হাদীস (মাস্টার্স) সম্পন্ন করেছেন। ফিকির প্ল্যাটফর্মের প্রতিষ্ঠাতা, মালিক ও প্রধান এডমিন।</Text>
        <TouchableOpacity onPress={() => setSection("updates")}><Text style={styles.openText}>বিস্তারিত ও আপডেট দেখুন</Text></TouchableOpacity>
      </View>
    </ScrollView>
  );

  const activeScreen = section === "profile" ? renderProfileEditor()
    : section === "settings" ? renderNotificationSettings()
      : section === "member-profile" ? renderMemberProfile()
      : section === "people" ? renderPeople()
      : section === "groups" ? renderGroupList()
        : section === "chats" ? renderUnreadChats()
              : section === "updates" ? renderUpdates()
                : section === "social" ? renderSocialFeed()
          : section === "admin" && isFounder ? renderAdmin()
            : section === "calls" ? renderCalls()
              : section === "direct" ? renderConversation(false)
                : section === "group" ? renderConversation(true)
                  : renderHome();

  return (
    <>
      {activeScreen}
      <Modal visible={Boolean(fullScreenImage)} transparent animationType="fade" onRequestClose={() => setFullScreenImage(null)}>
        <View style={styles.imageModalBackdrop}>
          <TouchableOpacity style={styles.imageModalCloseArea} activeOpacity={1} onPress={() => setFullScreenImage(null)} />
          {fullScreenImage ? <Image source={{ uri: fullScreenImage }} resizeMode="contain" style={styles.fullScreenImage} /> : null}
          <View style={styles.imageModalControls}><TouchableOpacity style={styles.modalSaveButton} onPress={() => fullScreenImage && saveFounderImage(fullScreenImage)}><Text style={styles.primaryButtonText}>গ্যালারিতে সংরক্ষণ</Text></TouchableOpacity><TouchableOpacity style={styles.modalCloseButton} onPress={() => setFullScreenImage(null)}><Text style={styles.modalCloseText}>বন্ধ করুন</Text></TouchableOpacity></View>
        </View>
      </Modal>
      <Modal visible={Boolean(moderationTarget)} transparent animationType="slide" onRequestClose={() => setModerationTarget(null)}>
        <View style={styles.sheetBackdrop}><View style={styles.sheet}><Text style={styles.sheetTitle}>{moderationTarget ? displayName(moderationTarget) : ""} পরিচালনা</Text><Text style={styles.helper}>ব্লক করলে শুধু আপনার সঙ্গে ব্যক্তিগত যোগাযোগ বন্ধ হবে। রিপোর্টটি প্রতিষ্ঠাতাদের পর্যালোচনায় যাবে।</Text><TextInput value={reportReason} onChangeText={setReportReason} multiline textAlignVertical="top" placeholder="রিপোর্টের কারণ লিখুন (কমপক্ষে ৩ অক্ষর)" style={[styles.input, styles.reportReasonInput]} /><TouchableOpacity style={styles.primaryButton} disabled={!moderationTarget || reportReason.trim().length < 3 || reportUser.isPending} onPress={() => moderationTarget && reportUser.mutate({ reportedUserId: moderationTarget.id, reason: reportReason.trim() })}><Text style={styles.primaryButtonText}>রিপোর্ট পাঠান</Text></TouchableOpacity><TouchableOpacity style={styles.blockButton} disabled={!moderationTarget || blockUser.isPending} onPress={() => moderationTarget && blockUser.mutate({ userId: moderationTarget.id })}><Text style={styles.blockButtonText}>ব্যক্তিগতভাবে ব্লক করুন</Text></TouchableOpacity><TouchableOpacity onPress={() => setModerationTarget(null)}><Text style={styles.cancelSheetText}>বাতিল</Text></TouchableOpacity></View></View>
      </Modal>
      <Modal visible={Boolean(selectedAdminUser)} transparent animationType="slide" onRequestClose={() => setSelectedAdminUser(null)}>
        <View style={styles.sheetBackdrop}><View style={styles.sheet}><Text style={styles.sheetTitle}>{selectedAdminUser ? displayName(selectedAdminUser) : ""} নিষিদ্ধ করুন</Text><Text style={styles.helper}>কারণ সংরক্ষিত থাকবে। নিষিদ্ধ হলে এই ব্যবহারকারী অনলাইন বার্তা, কল, পোস্ট এবং নিরাপদ API ব্যবহার করতে পারবেন না।</Text><TextInput value={banReason} onChangeText={setBanReason} multiline textAlignVertical="top" placeholder="নিষেধাজ্ঞার কারণ লিখুন (কমপক্ষে ৩ অক্ষর)" style={[styles.input, styles.reportReasonInput]} /><TouchableOpacity style={styles.banConfirmButton} disabled={!selectedAdminUser || banReason.trim().length < 3 || banUser.isPending} onPress={() => selectedAdminUser && banUser.mutate({ userId: selectedAdminUser.id, reason: banReason.trim() })}><Text style={styles.primaryButtonText}>{banUser.isPending ? "প্রক্রিয়াধীন…" : "নিষেধাজ্ঞা নিশ্চিত করুন"}</Text></TouchableOpacity><TouchableOpacity onPress={() => setSelectedAdminUser(null)}><Text style={styles.cancelSheetText}>বাতিল</Text></TouchableOpacity></View></View>
      </Modal>
      <Modal visible={Boolean(adminBlockTarget)} transparent animationType="slide" onRequestClose={() => setAdminBlockTarget(null)}>
        <View style={styles.sheetBackdrop}><View style={styles.sheet}><Text style={styles.sheetTitle}>{adminBlockTarget ? `${displayName(adminBlockTarget.user)}-কে ${adminBlockTarget.mode === "block" ? "ব্লক" : "আনব্লক"} করুন` : ""}</Text><Text style={styles.helper}>{adminBlockTarget?.mode === "block" ? "নিশ্চিত করলে এই প্রতিষ্ঠাতা Gmail অ্যাকাউন্ট থেকে ওই ব্যবহারকারীর ব্যক্তিগত বার্তা ও কল বন্ধ হবে। এটি অ্যাপ ব্যবহারে নিষেধাজ্ঞা নয়।" : "নিশ্চিত করলে এই ব্যবহারকারীর সঙ্গে ব্যক্তিগত বার্তা ও কল আবার চালু হবে।"}</Text><TouchableOpacity style={[styles.primaryButton, adminBlockTarget?.mode === "block" && styles.adminBlockConfirmButton]} disabled={!adminBlockTarget || blockUser.isPending || unblockUser.isPending} onPress={() => adminBlockTarget && (adminBlockTarget.mode === "block" ? blockUser.mutate({ userId: adminBlockTarget.user.id }) : unblockUser.mutate({ userId: adminBlockTarget.user.id }))}><Text style={styles.primaryButtonText}>{blockUser.isPending || unblockUser.isPending ? "প্রক্রিয়াধীন…" : adminBlockTarget?.mode === "block" ? "ব্লক নিশ্চিত করুন" : "আনব্লক নিশ্চিত করুন"}</Text></TouchableOpacity><TouchableOpacity onPress={() => setAdminBlockTarget(null)}><Text style={styles.cancelSheetText}>বাতিল</Text></TouchableOpacity></View></View>
      </Modal>
      <Modal visible={showMissedCallInbox} transparent animationType="slide" onRequestClose={() => setShowMissedCallInbox(false)}>
        <View style={styles.sheetBackdrop}>
          <View style={styles.sheet}>
            <View style={styles.missedCallSheetHeader}>
              <Text style={styles.sheetTitle}>মিসড কল</Text>
              <TouchableOpacity disabled={!missedCallHistory.data?.length || clearMissedCallHistory.isPending} onPress={confirmClearMissedCallHistory} style={[styles.clearHistoryButton, (!missedCallHistory.data?.length || clearMissedCallHistory.isPending) && styles.mutedActionButton]}>
                <MaterialIcons name="delete-sweep" size={18} color="#B14343" />
                <Text style={styles.clearHistoryButtonText}>{clearMissedCallHistory.isPending ? "মুছছে…" : "সব মুছুন"}</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.helper}>ডাটা সংযোগ না থাকায় যে ব্যক্তিগত কলগুলো গ্রহণ করা যায়নি, সেগুলো এখানে দেখানো হচ্ছে।</Text>
            <FlatList
              data={missedCallHistory.data ?? []}
              keyExtractor={(item) => String(item.id)}
              style={styles.missedCallList}
              contentContainerStyle={styles.missedCallListContent}
              ListEmptyComponent={<Text style={styles.empty}>{missedCallHistory.isLoading ? "মিসড কল লোড হচ্ছে…" : "এখন কোনো মিসড কলের ইতিহাস নেই।"}</Text>}
              renderItem={({ item }) => {
                const callerName = item.initiatorName || item.initiatorUsername || "ফিকির ব্যবহারকারী";
                const missedTime = item.missedAt ?? item.createdAt;
                return (
                  <View style={styles.missedCallRow}>
                    <View style={styles.missedCallAvatar}><Text style={styles.missedCallAvatarText}>{callerName.slice(0, 1)}</Text></View>
                    <View style={styles.missedCallDetails}>
                      <Text style={styles.missedCallName} numberOfLines={1}>{callerName}</Text>
                      <View style={styles.missedCallMetaRow}>
                        <MaterialIcons name={item.kind === "video" ? "videocam-off" : "phone-missed"} size={15} color="#B14343" />
                        <Text style={styles.missedCallMeta}>{item.kind === "video" ? "মিসড ভিডিও কল" : "মিসড অডিও কল"} · {formatTime(missedTime)}</Text>
                      </View>
                    </View>
                    <View style={styles.missedCallActions}>
                      <TouchableOpacity accessibilityLabel={`${callerName} এর মিসড কল মুছুন`} style={styles.deleteMissedCallButton} disabled={deleteMissedCall.isPending || clearMissedCallHistory.isPending} onPress={() => confirmDeleteMissedCall(item.id)}>
                        <MaterialIcons name="delete-outline" size={19} color="#B14343" />
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.callBackButton} disabled={startDirectCall.isPending || deleteMissedCall.isPending || clearMissedCallHistory.isPending} onPress={() => void callBackMissedCall(item)}>
                        <MaterialIcons name={item.kind === "video" ? "videocam" : "phone"} size={18} color="#FFFFFF" />
                        <Text style={styles.callBackButtonText}>{startDirectCall.isPending ? "…" : "কল"}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              }}
            />
            <TouchableOpacity onPress={() => setShowMissedCallInbox(false)}><Text style={styles.cancelSheetText}>বন্ধ করুন</Text></TouchableOpacity>
          </View>
        </View>
      </Modal>
      <Modal visible={Boolean(activeLiveCall)} animationType="slide" presentationStyle="fullScreen" onRequestClose={() => closeLiveCall(true)}>
        {isPreparingLiveCall ? <LiveCallConnecting /> : null}
        {!isPreparingLiveCall && activeLiveCall && liveKitConnection ? (
          <LiveCallRoom
            connection={liveKitConnection}
            kind={activeLiveCall.session.kind}
            title={activeLiveCall.title}
            onLeave={() => closeLiveCall(true)}
            onFailure={setLiveCallProblem}
          />
        ) : null}
        {!isPreparingLiveCall && activeLiveCall && !liveKitConnection && liveCallProblem ? (
          <View style={styles.callErrorPage}>
            <Text style={styles.callErrorTitle}>কল সংযোগ করা যায়নি</Text>
            <Text style={styles.callErrorCopy}>{liveCallProblem}</Text>
            <TouchableOpacity style={styles.primaryButton} onPress={() => closeLiveCall(false)}><Text style={styles.primaryButtonText}>কল ইনবক্সে ফিরুন</Text></TouchableOpacity>
          </View>
        ) : null}
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 18, paddingBottom: 36, gap: 12 },
  chatListContent: { padding: 18, paddingBottom: 36, gap: 10 },
  chatListHeader: { gap: 12, marginBottom: 4 },
  loadingList: { marginTop: 42 },
  unreadSummaryPill: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999, backgroundColor: "#0A7EA4" },
  unreadSummaryText: { color: "#FFFFFF", fontSize: 13, fontWeight: "800" },
  emptyUnreadCard: { alignItems: "center", gap: 7, paddingHorizontal: 22, paddingVertical: 30, borderWidth: 1, borderColor: "#C9E4EE", borderRadius: 18, backgroundColor: "#F4FBFE" },
  emptyUnreadTitle: { color: "#103B5B", fontSize: 16, fontWeight: "800" },
  unreadChatRow: { flexDirection: "row", alignItems: "center", gap: 11, padding: 12, borderWidth: 1, borderColor: "#D5E8F0", borderRadius: 15, backgroundColor: "#FFFFFF" },
  unreadChatAvatar: { width: 43, height: 43, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: "#D6F0F8" },
  unreadGroupAvatar: { borderRadius: 14, backgroundColor: "#E4E3FB" },
  unreadChatAvatarText: { color: "#0A6A8A", fontSize: 18, fontWeight: "800" },
  unreadChatCopy: { flex: 1, gap: 3 },
  unreadChatName: { color: "#103B5B", fontSize: 15, fontWeight: "800" },
  unreadChatMeta: { color: "#648092", fontSize: 12 },
  unreadBadge: { minWidth: 26, height: 26, paddingHorizontal: 7, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#D93535" },
  unreadBadgeText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },
  tileTitleRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  homeUnreadBadge: { minWidth: 22, height: 22, paddingHorizontal: 5, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#D93535" },
  homeUnreadBadgeText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" },
  offlineNotice: { gap: 9, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: "#F0D28C", backgroundColor: "#FFF8E8" },
  offlineNoticeHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  offlineNoticeTitleRow: { flex: 1, flexDirection: "row", alignItems: "center", gap: 8 },
  offlineNoticeTitle: { color: "#6E4800", fontSize: 15, fontWeight: "800" },
  offlineNoticeText: { color: "#6E4800", fontSize: 13, lineHeight: 19, fontWeight: "700" },
  offlineNoticeHint: { color: "#866A2D", fontSize: 12, lineHeight: 18 },
  offlineCallAction: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, paddingHorizontal: 11, paddingVertical: 10, borderRadius: 12, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#F4DFA8" },
  offlineCallActionCopy: { flex: 1, flexDirection: "row", alignItems: "center", gap: 7 },
  offlineCallActionText: { color: "#9B3737", fontSize: 13, fontWeight: "800" },
  missedCallSheetHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  callHistoryHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  clearHistoryButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, minHeight: 34, paddingHorizontal: 9, borderRadius: 9, backgroundColor: "#FFF0F0", borderWidth: 1, borderColor: "#F3CCCC" },
  clearHistoryButtonText: { color: "#B14343", fontSize: 12, fontWeight: "800" },
  mutedActionButton: { opacity: 0.45 },
  missedCallList: { maxHeight: 360, marginTop: 8 },
  missedCallListContent: { gap: 9, paddingBottom: 8 },
  missedCallRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 11, borderWidth: 1, borderColor: "#F0D9D9", borderRadius: 14, backgroundColor: "#FFF9F9" },
  missedCallAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: "#F9E1E1" },
  missedCallAvatarText: { color: "#A84444", fontSize: 17, fontWeight: "800" },
  missedCallDetails: { flex: 1, gap: 3 },
  missedCallName: { color: "#103B5B", fontSize: 14, fontWeight: "800" },
  missedCallMetaRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  missedCallMeta: { flex: 1, color: "#8E5151", fontSize: 11, lineHeight: 16 },
  missedCallActions: { flexDirection: "row", alignItems: "center", gap: 6 },
  deleteMissedCallButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 10, borderWidth: 1, borderColor: "#F0CFCF", backgroundColor: "#FFFFFF" },
  deleteCallHistoryButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 9, borderWidth: 1, borderColor: "#F0CFCF", backgroundColor: "#FFFFFF" },
  callBackButton: { minWidth: 58, minHeight: 36, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 3, paddingHorizontal: 8, borderRadius: 10, backgroundColor: "#0A7EA4" },
  callBackButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  chatPage: { flex: 1, backgroundColor: "#F5FAFE" },
  chatScroll: { padding: 14, gap: 8, paddingBottom: 18 },
  header: { height: 54, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#E1ECF5", backgroundColor: "#FFFFFF", paddingHorizontal: 12 },
  presenceBar: { paddingHorizontal: 14, paddingVertical: 5, backgroundColor: "#FFFFFF", borderBottomWidth: 1, borderBottomColor: "#E8F0F5" },
  presenceText: { color: "#2C7A56", fontSize: 11, fontWeight: "700" },
  activityBanner: { paddingHorizontal: 14, paddingVertical: 6, backgroundColor: "#F0FAFD", borderBottomWidth: 1, borderBottomColor: "#D4EDF5" },
  activityText: { color: "#0A6D9A", fontSize: 11, fontStyle: "italic", fontWeight: "800" },
  socialHero: { flexDirection: "row", alignItems: "center", gap: 10, padding: 15, borderRadius: 16, backgroundColor: "#0A6D9A" },
  socialHeroCopy: { flex: 1, gap: 3 },
  socialHeroTitle: { color: "#FFFFFF", fontSize: 18, fontWeight: "900" },
  socialHeroText: { color: "#DDF4FC", fontSize: 12, lineHeight: 18 },
  socialComposer: { gap: 9, padding: 13, borderRadius: 15, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#CBE4EF" },
  socialComposerActions: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 8 },
  socialSecondaryButton: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10, backgroundColor: "#EAF7FD" },
  socialSecondaryText: { color: "#0A6D9A", fontWeight: "900", fontSize: 12 },
  socialPublishButton: { minHeight: 38, justifyContent: "center", paddingHorizontal: 15, borderRadius: 11, backgroundColor: "#0A7EA4" },
  socialFeedHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 5 },
  socialPostCard: { gap: 9, padding: 13, borderRadius: 15, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#DDEBF2" },
  socialPostHeader: { flexDirection: "row", alignItems: "center", gap: 9 },
  socialPostIdentity: { flex: 1, gap: 2 },
  socialOwnerActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  followButton: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 9, backgroundColor: "#EAF7FD" },
  followButtonText: { color: "#0A6D9A", fontSize: 11, fontWeight: "900" },
  socialPostBody: { color: "#183E58", fontSize: 14, lineHeight: 21 },
  socialPostImage: { width: "100%", height: 190, borderRadius: 12, backgroundColor: "#EAF4F8" },
  socialPostLink: { color: "#0A6D9A", fontSize: 12, textDecorationLine: "underline" },
  socialVoiceButton: { padding: 10, borderRadius: 10, backgroundColor: "#EAF7FD" },
  socialVoiceText: { color: "#0A6D9A", fontSize: 12, fontWeight: "900" },
  socialReactionRow: { flexDirection: "row", gap: 7, borderTopWidth: 1, borderTopColor: "#E4EEF3", paddingTop: 8 },
  socialReactionButton: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 9, backgroundColor: "#F3F8FB" },
  socialReactionActive: { backgroundColor: "#DDF2FC", borderWidth: 1, borderColor: "#9BCDE3" },
  socialReactionCount: { color: "#547287", fontSize: 11, fontWeight: "800" },
  homeHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 2 },
  headerTitle: { flex: 1, fontSize: 20, fontWeight: "800", color: "#103B5B" },
  headerSpacer: { width: 34 },
  backButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 17, backgroundColor: "#EAF6FD" },
  backText: { color: "#0A7EA4", fontSize: 30, lineHeight: 32, marginTop: -4 },
  helper: { color: "#587186", fontSize: 13, lineHeight: 19 },
  label: { color: "#103B5B", fontWeight: "700", marginTop: 5 },
  input: { minHeight: 46, paddingHorizontal: 13, paddingVertical: 10, borderWidth: 1, borderColor: "#C9DFEC", borderRadius: 13, backgroundColor: "#FFFFFF", color: "#103B5B", fontSize: 15 },
  multiline: { minHeight: 92, textAlignVertical: "top" },
  postInput: { minHeight: 120 },
  primaryButton: { minHeight: 48, alignItems: "center", justifyContent: "center", borderRadius: 14, backgroundColor: "#0A7EA4", paddingHorizontal: 16, marginTop: 3 },
  primaryButtonSmall: { flex: 1, minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: "#0A7EA4", paddingHorizontal: 10 },
  founderButtonSmall: { flex: 1.45, minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: "#1467A0", paddingHorizontal: 10 },
  primaryButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13, textAlign: "center" },
  sectionTitle: { marginTop: 10, color: "#103B5B", fontWeight: "800", fontSize: 17 },
  chipRow: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  chip: { borderRadius: 999, paddingVertical: 8, paddingHorizontal: 11, borderWidth: 1, borderColor: "#BBD6E5", backgroundColor: "#FFFFFF" },
  chipActive: { backgroundColor: "#E3F4FC", borderColor: "#0A7EA4" },
  chipText: { color: "#587186", fontWeight: "700", fontSize: 12 },
  chipTextActive: { color: "#0A7EA4" },
  toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 5 },
  toggleLabel: { color: "#103B5B", fontWeight: "600", flex: 1, paddingRight: 12 },
  personCard: { flexDirection: "row", alignItems: "center", gap: 11, padding: 12, backgroundColor: "#FFFFFF", borderRadius: 15, borderWidth: 1, borderColor: "#E1ECF5" },
  groupCard: { flexDirection: "row", alignItems: "center", gap: 11, padding: 12, backgroundColor: "#FFFFFF", borderRadius: 15, borderWidth: 1, borderColor: "#E1ECF5" },
  personText: { flex: 1, gap: 2 },
  personName: { color: "#103B5B", fontWeight: "800", fontSize: 15 },
  meta: { color: "#688298", fontSize: 12, lineHeight: 18 },
  bodyPreview: { color: "#466277", fontSize: 12, lineHeight: 18, marginTop: 2 },
  openText: { color: "#0A7EA4", fontWeight: "800", fontSize: 12 },
  removeText: { color: "#B42318", fontWeight: "800", fontSize: 12 },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center", backgroundColor: "#D9F0FB" },
  avatarLarge: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center", backgroundColor: "#D9F0FB" },
  avatarText: { color: "#0A7EA4", fontWeight: "900", fontSize: 20 },
  groupIcon: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#E4F1FB" },
  groupIconText: { color: "#1467A0", fontWeight: "900", fontSize: 18 },
  empty: { color: "#688298", textAlign: "center", paddingVertical: 18, lineHeight: 21 },
  founderCard: { gap: 6, backgroundColor: "#EAF6FD", borderWidth: 1, borderColor: "#B7DDEC", padding: 15, borderRadius: 16 },
  founderBadge: { color: "#0A7EA4", fontWeight: "900", fontSize: 12 },
  founderName: { color: "#103B5B", fontWeight: "900", fontSize: 17 },
  founderBio: { color: "#3E6078", fontSize: 13, lineHeight: 20 },
  founderRole: { color: "#1467A0", fontWeight: "700", fontSize: 12 },
  notificationHero: { flexDirection: "row", alignItems: "center", gap: 11, padding: 15, borderRadius: 16, backgroundColor: "#EAF6FD", borderWidth: 1, borderColor: "#B7DDEC" },
  notificationHeroIcon: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 21, backgroundColor: "#0A7EA4" },
  notificationHeroTitle: { color: "#103B5B", fontSize: 16, fontWeight: "900" },
  notificationHeroText: { color: "#466277", fontSize: 12, lineHeight: 18, marginTop: 2 },
  notificationCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 15, borderRadius: 16, borderWidth: 1, borderColor: "#E1ECF5", backgroundColor: "#FFFFFF" },
  notificationActionButton: { minHeight: 36, justifyContent: "center", borderRadius: 10, backgroundColor: "#EAF6FD", paddingHorizontal: 10 },
  notificationActionText: { color: "#0A6D9A", fontSize: 12, fontWeight: "800" },
  settingTextBlock: { flex: 1, gap: 3 },
  settingTitle: { color: "#103B5B", fontSize: 15, fontWeight: "800" },
  settingDescription: { color: "#587186", fontSize: 12, lineHeight: 18 },
  notificationHint: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 14, backgroundColor: "#F0F8FD", borderWidth: 1, borderColor: "#C7E2F0" },
  notificationHintText: { flex: 1, color: "#416A84", fontSize: 11, lineHeight: 17 },
  notificationGuidance: { flexDirection: "row", alignItems: "flex-start", gap: 9, padding: 13, borderRadius: 14, backgroundColor: "#FFF8E8", borderWidth: 1, borderColor: "#F0D99B" },
  notificationGuidanceText: { color: "#70531C", fontSize: 11, lineHeight: 17 },
  notificationSaving: { color: "#0A7EA4", fontSize: 12, textAlign: "center", fontWeight: "800" },
  postCard: { gap: 4, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E1ECF5", borderRadius: 15, padding: 13 },
  postBody: { color: "#193F5A", fontSize: 14, lineHeight: 21, marginTop: 3 },
  linkText: { color: "#0A7EA4", fontSize: 13, lineHeight: 19, marginTop: 2 },
  messageRow: { maxWidth: "84%", paddingHorizontal: 11, paddingVertical: 8, borderRadius: 14, gap: 3 },
  messageRowMine: { alignSelf: "flex-end", backgroundColor: "#0A7EA4", borderBottomRightRadius: 3 },
  messageRowOther: { alignSelf: "flex-start", backgroundColor: "#FFFFFF", borderBottomLeftRadius: 3, borderWidth: 1, borderColor: "#E1ECF5" },
  senderName: { color: "#0A7EA4", fontWeight: "800", fontSize: 11 },
  messageText: { color: "#173D57", fontSize: 14, lineHeight: 20 },
  messageTextMine: { color: "#FFFFFF" },
  messageMeta: { color: "#6B8599", fontSize: 10, alignSelf: "flex-end" },
  messageImage: { width: 220, height: 170, borderRadius: 10, marginTop: 2, backgroundColor: "#DCECF4" },
  audioAttachment: { marginTop: 3, borderRadius: 10, backgroundColor: "#E8F5FB", paddingHorizontal: 10, paddingVertical: 9 },
  audioAttachmentMine: { backgroundColor: "#187EAA" },
  audioAttachmentText: { color: "#0A7EA4", fontSize: 12, fontWeight: "800" },
  fileAttachment: { marginTop: 3, gap: 6, padding: 9, borderRadius: 10, backgroundColor: "#E8F5FB" },
  fileAttachmentMine: { backgroundColor: "#187EAA" },
  fileAttachmentName: { color: "#103B5B", fontSize: 12, fontWeight: "800" },
  attachmentActionRow: { flexDirection: "row", gap: 12, flexWrap: "wrap" },
  attachmentActionText: { color: "#0A7EA4", fontSize: 11, fontWeight: "800" },
  callBar: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: "#EAF6FD", borderBottomWidth: 1, borderBottomColor: "#D8E9F2" },
  callNote: { flex: 1, color: "#35617D", fontSize: 12, fontWeight: "700" },
  callAction: { minHeight: 31, justifyContent: "center", paddingHorizontal: 11, borderRadius: 10, backgroundColor: "#0A7EA4" },
  callActionText: { color: "#FFFFFF", fontWeight: "800", fontSize: 11 },
  clearChatAction: { minHeight: 31, flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 7, borderRadius: 10, backgroundColor: "#FFF2F3", borderWidth: 1, borderColor: "#F0C9CD" },
  clearChatActionText: { color: "#A33D45", fontWeight: "800", fontSize: 10 },
  outgoingCallBanner: { flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 13, paddingVertical: 10, backgroundColor: "#E9F8EF", borderBottomWidth: 1, borderBottomColor: "#C5E7D2" },
  outgoingCallPulse: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "#2E9B5B" },
  outgoingCallCopy: { flex: 1, gap: 2 },
  outgoingCallTitle: { color: "#1D6D3D", fontSize: 12, fontWeight: "900" },
  outgoingCallText: { color: "#4A7F5B", fontSize: 10, lineHeight: 15 },
  cancelCallButton: { minHeight: 34, justifyContent: "center", paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#C93636" },
  cancelCallText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" },
  incomingCallBanner: { flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 13, paddingVertical: 10, backgroundColor: "#EAF4FF", borderBottomWidth: 1, borderBottomColor: "#C4DFF5" },
  incomingCallIcon: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "#1769AA" },
  incomingCallCopy: { flex: 1, gap: 2 },
  incomingCallTitle: { color: "#155789", fontSize: 12, fontWeight: "900" },
  incomingCallText: { color: "#52748F", fontSize: 10, lineHeight: 15 },
  incomingCallActions: { flexDirection: "row", gap: 5 },
  declineCallButton: { minHeight: 34, justifyContent: "center", paddingHorizontal: 9, borderRadius: 10, backgroundColor: "#FFF0F1", borderWidth: 1, borderColor: "#EDC2C7" },
  declineCallText: { color: "#A33D45", fontSize: 11, fontWeight: "900" },
  acceptCallButton: { minHeight: 34, justifyContent: "center", paddingHorizontal: 9, borderRadius: 10, backgroundColor: "#2E9B5B" },
  acceptCallText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" },
  callCard: { flexDirection: "row", alignItems: "center", gap: 10, padding: 13, borderRadius: 15, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E1ECF5" },
  callStatus: { color: "#1467A0", fontWeight: "700", fontSize: 12, marginTop: 2 },
  replyBar: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 8, borderTopWidth: 1, borderTopColor: "#D8E9F2", backgroundColor: "#EAF6FD" },
  replyCopy: { flex: 1, gap: 1 },
  replyTitle: { color: "#0A7EA4", fontWeight: "800", fontSize: 12 },
  replyPreview: { color: "#587186", fontSize: 12, lineHeight: 17 },
  cancelReply: { color: "#0A7EA4", fontSize: 25, lineHeight: 27, fontWeight: "400" },
  uploadProgressCard: { marginHorizontal: 10, marginTop: 8, gap: 7, padding: 11, borderRadius: 14, backgroundColor: "#EAF6FD", borderWidth: 1, borderColor: "#B7DDEC" },
  uploadProgressCardFailed: { backgroundColor: "#FFF4F2", borderColor: "#F3B7B0" },
  uploadProgressHeader: { flexDirection: "row", alignItems: "center", gap: 9 },
  uploadStatusIcon: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#0A7EA4" },
  uploadStatusIconFailed: { backgroundColor: "#B42318" },
  uploadFailedIcon: { color: "#FFFFFF", fontSize: 17, fontWeight: "900", lineHeight: 20 },
  uploadProgressCopy: { flex: 1, gap: 1 },
  uploadProgressTitle: { color: "#0A5474", fontSize: 12, fontWeight: "900" },
  uploadProgressTitleFailed: { color: "#8D1D15" },
  uploadProgressFilename: { color: "#587186", fontSize: 11 },
  uploadProgressStep: { color: "#0A7EA4", fontSize: 11, fontWeight: "900" },
  uploadProgressStepFailed: { color: "#B42318" },
  uploadProgressTrack: { height: 6, overflow: "hidden", borderRadius: 99, backgroundColor: "#C7E6F3" },
  uploadProgressFill: { height: "100%", borderRadius: 99, backgroundColor: "#0A7EA4" },
  uploadProgressPreparing: { width: "33%" },
  uploadProgressUploading: { width: "67%" },
  uploadProgressSending: { width: "100%" },
  uploadProgressFailed: { width: "100%", backgroundColor: "#D92D20" },
  uploadProgressFooter: { flexDirection: "row", alignItems: "center", gap: 10 },
  uploadProgressMessage: { flex: 1, gap: 4 },
  uploadProgressHint: { flex: 1, color: "#587186", fontSize: 10, lineHeight: 14 },
  uploadProgressHintFailed: { color: "#8D1D15" },
  uploadFailureBadge: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 7, paddingHorizontal: 6, paddingVertical: 3, backgroundColor: "#FDE2E0" },
  uploadFailureBadgeText: { color: "#8D1D15", fontSize: 10, fontWeight: "900" },
  cancelUploadText: { color: "#B42318", fontSize: 11, fontWeight: "900" },
  uploadFailureActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  retryUploadButton: { minHeight: 29, justifyContent: "center", paddingHorizontal: 9, borderRadius: 9, backgroundColor: "#B42318" },
  retryUploadText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  dismissUploadText: { color: "#8D1D15", fontSize: 10, fontWeight: "900" },
  composerArea: { borderTopWidth: 1, borderTopColor: "#D8E9F2", backgroundColor: "#FFFFFF" },
  attachmentGuidance: { marginHorizontal: 10, marginTop: 8, gap: 7, padding: 10, borderRadius: 12, backgroundColor: "#F0F8FD", borderWidth: 1, borderColor: "#B7DDEC" },
  attachmentGuidanceHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  attachmentGuidanceTitle: { flex: 1, color: "#0A5474", fontSize: 11, fontWeight: "900" },
  attachmentSizeBadge: { borderRadius: 99, paddingHorizontal: 8, paddingVertical: 3, backgroundColor: "#D7EDF8" },
  attachmentSizeBadgeText: { color: "#0A5474", fontSize: 10, fontWeight: "900" },
  attachmentGuidanceItems: { gap: 4 },
  attachmentGuidanceItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  attachmentGuidanceText: { flex: 1, color: "#416A84", fontSize: 10, lineHeight: 14 },
  composer: { flexDirection: "row", alignItems: "flex-end", gap: 8, padding: 10, backgroundColor: "#FFFFFF" },
  attachmentButton: { minHeight: 42, justifyContent: "center", paddingHorizontal: 8, borderRadius: 11, backgroundColor: "#E5F4FB" },
  attachmentButtonDisabled: { opacity: 0.48 },
  attachmentButtonText: { color: "#0A7EA4", fontSize: 10, fontWeight: "900" },
  composerInput: { flex: 1, minHeight: 42, maxHeight: 100, borderRadius: 13, borderWidth: 1, borderColor: "#C9DFEC", paddingHorizontal: 12, paddingVertical: 8, textAlignVertical: "top", color: "#103B5B" },
  sendButton: { minHeight: 42, justifyContent: "center", borderRadius: 12, backgroundColor: "#0A7EA4", paddingHorizontal: 13 },
  sendText: { color: "#FFFFFF", fontWeight: "900", fontSize: 12 },
  voiceRecordingBar: { flexDirection: "row", alignItems: "center", gap: 7, padding: 10, borderTopWidth: 1, borderTopColor: "#D8E9F2", backgroundColor: "#FFF7E5" },
  voiceRecordingText: { flex: 1, color: "#805A12", fontSize: 11, fontWeight: "800" },
  voiceControl: { paddingHorizontal: 9, paddingVertical: 9, borderRadius: 10, backgroundColor: "#EBD59C" },
  voiceControlText: { color: "#6B4B08", fontSize: 11, fontWeight: "900" },
  voiceCancel: { paddingHorizontal: 8, paddingVertical: 9 },
  voiceCancelText: { color: "#B42318", fontSize: 11, fontWeight: "900" },
  managerCard: { marginTop: 16, backgroundColor: "#F0F8FD", borderRadius: 15, borderWidth: 1, borderColor: "#C7E2F0", padding: 12, gap: 8 },
  groupSettingsCard: { gap: 8, padding: 11, borderRadius: 13, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D8EAF3" },
  memberRow: { flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: "#DCECF4", paddingTop: 9 },
  memberActions: { gap: 6, alignItems: "flex-end" },
  identityCard: { flexDirection: "row", alignItems: "center", gap: 11, padding: 14, backgroundColor: "#FFFFFF", borderRadius: 16, borderWidth: 1, borderColor: "#D8EAF3" },
  notice: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#FFF7E5", padding: 12, borderRadius: 13, borderWidth: 1, borderColor: "#F2D792" },
  noticeText: { flex: 1, color: "#805A12", fontSize: 12, lineHeight: 18 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  tile: { width: "48.6%", minHeight: 126, padding: 13, borderRadius: 16, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E1ECF5", gap: 5 },
  tileIcon: { color: "#0A7EA4", fontSize: 25, fontWeight: "900" },
  tileTitle: { color: "#103B5B", fontWeight: "900", fontSize: 14 },
  tileText: { color: "#688298", fontSize: 11, lineHeight: 16 },
  callErrorPage: { flex: 1, justifyContent: "center", alignItems: "center", padding: 26, gap: 12, backgroundColor: "#071729" },
  callErrorTitle: { color: "#FFFFFF", fontSize: 20, fontWeight: "900", textAlign: "center" },
  callErrorCopy: { color: "#B8D5E7", fontSize: 14, lineHeight: 21, textAlign: "center" },
  activeGroupCalls: { marginHorizontal: 14, marginTop: 8, padding: 10, gap: 8, borderRadius: 14, backgroundColor: "#E2F4FE", borderWidth: 1, borderColor: "#B9E4F7" },
  activeGroupCallLabel: { color: "#17628B", fontSize: 12, fontWeight: "800" },
  activeGroupCallButton: { alignSelf: "flex-start", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, backgroundColor: "#0A7EA4" },
  activeGroupCallText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  composerCard: { gap: 9, padding: 14, borderRadius: 16, backgroundColor: "#F0F8FD", borderWidth: 1, borderColor: "#B7DDEC" },
  composerTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cancelLink: { color: "#0A7EA4", fontWeight: "800", fontSize: 13 },
  updateComposerInput: { minHeight: 142, maxHeight: 300 },
  counterText: { alignSelf: "flex-end", color: "#688298", fontSize: 11, marginTop: -6 },
  updateImageGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, alignItems: "center" },
  composerImageWrap: { width: 86, height: 86, borderRadius: 11, overflow: "visible" },
  composerImage: { width: 86, height: 86, borderRadius: 11, backgroundColor: "#DCECF4" },
  removeImageButton: { position: "absolute", top: -7, right: -7, width: 23, height: 23, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#B42318", borderWidth: 2, borderColor: "#FFFFFF" },
  removeImageText: { color: "#FFFFFF", fontSize: 18, lineHeight: 19, fontWeight: "700", marginTop: -2 },
  addImageButton: { width: 94, height: 86, borderRadius: 11, alignItems: "center", justifyContent: "center", borderWidth: 1, borderStyle: "dashed", borderColor: "#78B7D4", backgroundColor: "#FFFFFF" },
  addImageText: { color: "#0A7EA4", fontSize: 12, fontWeight: "800" },
  addUpdateVoiceButton: { minHeight: 42, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderRadius: 11, borderWidth: 1, borderStyle: "dashed", borderColor: "#78B7D4", backgroundColor: "#FFFFFF" },
  addUpdateVoiceText: { color: "#0A7EA4", fontSize: 12, fontWeight: "900" },
  updateVoiceRecorder: { flexDirection: "row", alignItems: "center", gap: 7, padding: 10, borderRadius: 11, backgroundColor: "#FFF7E5", borderWidth: 1, borderColor: "#F0D68D" },
  updateVoiceRecorderText: { flex: 1, color: "#805A12", fontSize: 11, fontWeight: "800" },
  updateVoicePreview: { flexDirection: "row", alignItems: "center", gap: 8, padding: 10, borderRadius: 11, backgroundColor: "#EAF7FD", borderWidth: 1, borderColor: "#C8E8F6" },
  updateVoicePreviewCopy: { flex: 1, gap: 2 },
  updateVoicePreviewTitle: { color: "#17628B", fontSize: 12, fontWeight: "900" },
  updateVoicePreviewMeta: { color: "#688298", fontSize: 11 },
  updateVoiceControl: { minHeight: 32, justifyContent: "center", paddingHorizontal: 9, borderRadius: 9, backgroundColor: "#D8EFFA" },
  updateVoiceControlText: { color: "#0A7EA4", fontSize: 11, fontWeight: "900" },
  updateVoiceRemoveText: { color: "#B42318", fontSize: 11, fontWeight: "900" },
  disabledButton: { opacity: 0.58 },
  updateCardHeader: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  draftPostCard: { backgroundColor: "#FFFDF7", borderColor: "#EFD69C" },
  draftBadge: { color: "#8A640E", backgroundColor: "#FFF0BF", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999, fontSize: 11, fontWeight: "800" },
  publishedBadge: { color: "#17628B", backgroundColor: "#E3F4FC", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999, fontSize: 11, fontWeight: "800" },
  scheduleNote: { color: "#8A640E", fontSize: 12, lineHeight: 18, marginTop: 4 },
  feedImageGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 7 },
  feedImageWrap: { width: "48.5%", aspectRatio: 1, borderRadius: 12, overflow: "hidden", backgroundColor: "#DCECF4" },
  feedImage: { width: "100%", height: "100%" },
  linkPanel: { marginTop: 8, padding: 9, backgroundColor: "#F1F8FC", borderRadius: 11, borderWidth: 1, borderColor: "#D4E8F2", gap: 7 },
  linkAction: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 9, backgroundColor: "#E2F3FB" },
  linkActionText: { color: "#0A7EA4", fontWeight: "800", fontSize: 12 },
  founderUpdateVoice: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8, padding: 9, borderRadius: 11, backgroundColor: "#EAF7FD", borderWidth: 1, borderColor: "#C8E8F6" },
  founderUpdateVoiceActions: { flex: 1, flexDirection: "row", gap: 6 },
  founderUpdateVoicePlay: { flex: 1, minHeight: 34, justifyContent: "center", paddingHorizontal: 10, borderRadius: 9, backgroundColor: "#D8EFFA" },
  founderUpdateVoicePlayText: { color: "#0A7EA4", fontSize: 12, fontWeight: "900" },
  founderUpdateVoiceSave: { minHeight: 34, justifyContent: "center", paddingHorizontal: 10, borderRadius: 9, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#BFDDEB" },
  founderUpdateVoiceSaveText: { color: "#0A7EA4", fontSize: 11, fontWeight: "900" },
  founderUpdateVoiceDuration: { color: "#587186", fontSize: 11, fontWeight: "800" },
  reactionRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 8, marginTop: 10 },
  reactionButton: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 17, backgroundColor: "#F0F6F9", borderWidth: 1, borderColor: "#D5E5ED" },
  reactionButtonActive: { backgroundColor: "#DDF3FD", borderColor: "#66B9DE" },
  reactionButtonLoading: { minWidth: 154 },
  reactionButtonText: { color: "#43677E", fontSize: 12, fontWeight: "800" },
  reactionButtonTextActive: { color: "#0A7EA4" },
  reactionLoadingContent: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  reactionLoadingText: { color: "#0A7EA4", fontSize: 12, fontWeight: "800" },
  reactionCountButton: { paddingVertical: 5, paddingHorizontal: 2 },
  reactionCountText: { color: "#0A7EA4", fontSize: 12, fontWeight: "800", textDecorationLine: "underline" },
  reactionEmptyText: { color: "#8096A6", fontSize: 11 },
  viewCount: { minHeight: 34, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 4 },
  viewCountText: { color: "#0A7EA4", fontSize: 12, fontWeight: "800", textDecorationLine: "underline" },
  viewCountTextPassive: { color: "#5D7C91", textDecorationLine: "none" },
  updateControls: { flexDirection: "row", gap: 7, flexWrap: "wrap", marginTop: 9 },
  publishButton: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 9, backgroundColor: "#0A7EA4" },
  publishButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 12 },
  secondaryAction: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 9, backgroundColor: "#E2F3FB" },
  secondaryActionText: { color: "#0A7EA4", fontWeight: "800", fontSize: 12 },
  dangerAction: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 9, backgroundColor: "#FDECEC" },
  dangerActionText: { color: "#B42318", fontWeight: "800", fontSize: 12 },
  reactorModalBackdrop: { flex: 1, justifyContent: "center", padding: 20, backgroundColor: "rgba(7, 30, 47, 0.52)" },
  reactorModalCard: { maxHeight: "72%", gap: 10, padding: 16, borderRadius: 18, backgroundColor: "#FFFFFF" },
  reactorModalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 10, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: "#E2EDF3" },
  reactorList: { flexGrow: 0 },
  reactorListContent: { paddingBottom: 4 },
  reactorRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "#EDF3F6" },
  reactorAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: "#D8EFFA" },
  reactorAvatarText: { color: "#0A7EA4", fontSize: 15, fontWeight: "900" },
  reactorName: { color: "#103B5B", fontSize: 13, fontWeight: "900" },
  reactorMeta: { color: "#688298", fontSize: 10, marginTop: 2 },
  reactorEmoji: { fontSize: 18 },
  futureCard: { gap: 7, padding: 14, borderRadius: 16, backgroundColor: "#F3F6F8", borderWidth: 1, borderColor: "#D9E1E7", marginTop: 4 },
  peopleActions: { alignItems: "flex-end", gap: 8 },
  reportLink: { color: "#9B3B18", fontSize: 11, fontWeight: "800" },
  adminHero: { gap: 10, padding: 16, borderRadius: 18, backgroundColor: "#075B87", borderWidth: 1, borderColor: "#06496C" },
  adminHeroTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  adminHeroIcon: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.16)" },
  adminHeroCopy: { flex: 1, gap: 2 },
  adminHeroDescription: { color: "#D9F3FF", fontSize: 12, lineHeight: 18 },
  adminRefreshButton: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.14)" },
  adminSectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 4 },
  sectionSubtitle: { color: "#688298", fontSize: 11, lineHeight: 16, marginTop: 2 },
  adminMetricsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  adminMetricCard: { width: "48.5%", minHeight: 112, gap: 5, padding: 13, borderRadius: 16, borderWidth: 1 },
  metricBlue: { backgroundColor: "#EEF9FE", borderColor: "#C8E8F6" },
  metricGreen: { backgroundColor: "#F0FAF4", borderColor: "#CBEAD6" },
  metricPurple: { backgroundColor: "#F6F3FF", borderColor: "#DED4FA" },
  metricRed: { backgroundColor: "#FFF4F2", borderColor: "#F5CEC9" },
  adminMetricValue: { color: "#103B5B", fontSize: 24, fontWeight: "900", marginTop: 2 },
  adminMetricLabel: { color: "#587186", fontSize: 11, lineHeight: 16, fontWeight: "700" },
  adminSafetyStrip: { flexDirection: "row", alignItems: "center", borderRadius: 13, paddingVertical: 10, paddingHorizontal: 12, backgroundColor: "#FFF8E7", borderWidth: 1, borderColor: "#F0DEA6" },
  adminSafetyItem: { flex: 1, flexDirection: "row", alignItems: "center", gap: 6 },
  adminSafetyText: { flex: 1, color: "#805A12", fontSize: 11, fontWeight: "800" },
  adminSafetyDivider: { width: 1, height: 22, backgroundColor: "#EACD79", marginHorizontal: 8 },
  adminUpdateSummary: { flexDirection: "row", alignItems: "center", gap: 7, padding: 10, borderRadius: 12, backgroundColor: "#F0F8FD", borderWidth: 1, borderColor: "#D0E7F3" },
  adminUpdateSummaryText: { flex: 1, color: "#35617D", fontSize: 12, fontWeight: "700" },
  statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  statCard: { width: "48.5%", gap: 3, padding: 13, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D7E9F3" },
  statValue: { color: "#0A7EA4", fontSize: 23, fontWeight: "900" },
  statLabel: { color: "#587186", fontSize: 11, fontWeight: "700" },
  lastUpdateText: { color: "#587186", fontSize: 12, lineHeight: 18, marginTop: -4 },
  adminPanel: { gap: 9, padding: 14, borderRadius: 16, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D7E9F3" },
  adminPanelHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  adminCount: { color: "#0A7EA4", backgroundColor: "#E2F3FB", borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4, fontSize: 11, fontWeight: "800" },
  adminBioInput: { minHeight: 116, maxHeight: 220 },
  adminSearchLabel: { color: "#24536E", fontSize: 12, fontWeight: "700", lineHeight: 18 },
  adminSearchBox: { flexDirection: "row", alignItems: "center", gap: 8, minHeight: 46, borderWidth: 1, borderColor: "#C9DFEC", borderRadius: 13, paddingHorizontal: 12, backgroundColor: "#F9FCFE" },
  adminSearchInput: { flex: 1, minHeight: 44, color: "#103B5B", fontSize: 14 },
  adminSearchClear: { minWidth: 32, minHeight: 32, alignItems: "center", justifyContent: "center", borderRadius: 16 },
  adminSearchResults: { color: "#527287", fontSize: 12, fontWeight: "700" },
  adminFilterRow: { flexDirection: "row", gap: 7, flexWrap: "wrap" },
  adminFilterChip: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 999, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#C9DFEC" },
  adminFilterChipActive: { backgroundColor: "#0A7EA4", borderColor: "#0A7EA4" },
  adminFilterText: { color: "#587186", fontSize: 11, fontWeight: "800" },
  adminFilterTextActive: { color: "#FFFFFF" },
  adminSortRow: { gap: 6, paddingVertical: 3 },
  adminSortLabel: { color: "#466277", fontSize: 11, fontWeight: "800" },
  adminSortHint: { color: "#177B4B", fontSize: 10, fontWeight: "700", marginTop: 2 },
  adminSortChip: { minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 999, backgroundColor: "#F7FBFD", borderWidth: 1, borderColor: "#C9DFEC" },
  adminSortChipActive: { backgroundColor: "#17628B", borderColor: "#17628B" },
  adminSortText: { color: "#466277", fontSize: 11, fontWeight: "800" },
  adminSortTextActive: { color: "#FFFFFF" },
  adminUserCard: { gap: 9, padding: 12, borderRadius: 15, backgroundColor: "#FBFDFF", borderWidth: 1, borderColor: "#DCECF4" },
  adminUserCardBanned: { backgroundColor: "#FFF7F6", borderColor: "#F3B9B3" },
  adminUserCardBlocked: { backgroundColor: "#FFFDF7", borderColor: "#EFD69C" },
  adminUserTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  adminAvatar: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center", overflow: "hidden", backgroundColor: "#D9F0FB" },
  adminAvatarImage: { width: "100%", height: "100%" },
  adminUserIdentity: { flex: 1, gap: 1 },
  adminNameLine: { flexDirection: "row", alignItems: "center", gap: 6 },
  adminEmail: { color: "#466277", fontSize: 11, lineHeight: 16 },
  adminFounderPill: { color: "#17628B", backgroundColor: "#DFF1FA", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 999, fontSize: 9, fontWeight: "900" },
  adminStatusRow: { flexDirection: "row", gap: 6, flexWrap: "wrap" },
  adminStatusPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999, fontSize: 10, fontWeight: "900" },
  adminStatusRegular: { color: "#18794E", backgroundColor: "#E5F6ED" },
  adminStatusBlocked: { color: "#9A5A00", backgroundColor: "#FFF0C7" },
  adminStatusBanned: { color: "#B42318", backgroundColor: "#FDE5E2" },
  adminUserDetails: { gap: 2, paddingTop: 8, borderTopWidth: 1, borderTopColor: "#E6EFF4" },
  adminDetailText: { color: "#688298", fontSize: 11, lineHeight: 16 },
  adminLastActiveRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  adminLastActiveOnline: { color: "#18794E", fontWeight: "700" },
  adminActionRow: { flexDirection: "row", gap: 8 },
  adminActionButton: { flex: 1, minHeight: 38, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderRadius: 10, borderWidth: 1, paddingHorizontal: 8 },
  adminActionText: { fontSize: 11, fontWeight: "900" },
  adminActionBlock: { backgroundColor: "#FFF8E7", borderColor: "#F0DEA6" },
  adminActionBlockText: { color: "#9A5A00" },
  adminActionUnblock: { backgroundColor: "#F0FAF4", borderColor: "#CBEAD6" },
  adminActionUnblockText: { color: "#18794E" },
  adminActionBan: { backgroundColor: "#FFF1F0", borderColor: "#F4C5C0" },
  adminActionBanText: { color: "#B42318" },
  adminActionUnban: { backgroundColor: "#E5F6ED", borderColor: "#B9E0C7" },
  adminActionUnbanText: { color: "#18794E" },
  adminFounderNote: { color: "#17628B", fontSize: 10, lineHeight: 15, fontWeight: "700", backgroundColor: "#EAF6FD", borderRadius: 9, paddingHorizontal: 9, paddingVertical: 7 },
  adminBlockConfirmButton: { backgroundColor: "#A65C00" },
  memberProfileCard: { alignItems: "center", gap: 7, paddingVertical: 24, paddingHorizontal: 18, borderRadius: 20, backgroundColor: "#F4FBFF", borderWidth: 1, borderColor: "#C9E7F4" },
  memberProfileAvatar: { width: 96, height: 96, borderRadius: 48, alignItems: "center", justifyContent: "center", overflow: "hidden", backgroundColor: "#D5EFFB", borderWidth: 3, borderColor: "#FFFFFF" },
  memberProfileAvatarImage: { width: "100%", height: "100%" },
  memberProfileAvatarText: { color: "#0A6D9A", fontSize: 37, fontWeight: "900" },
  memberProfileName: { color: "#103B5B", fontSize: 22, lineHeight: 29, fontWeight: "900", textAlign: "center", marginTop: 5 },
  memberProfileUsername: { color: "#527287", fontSize: 13, fontWeight: "700" },
  memberProfileBio: { color: "#466277", fontSize: 13, lineHeight: 20, textAlign: "center", marginTop: 7 },
  memberProfileBioMuted: { color: "#7B95A7", fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 7 },
  memberFounderBadge: { color: "#17628B", backgroundColor: "#DDF2FC", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5, fontSize: 11, fontWeight: "900", marginTop: 5 },
  memberProfileActions: { gap: 9 },
  memberMessageButton: { minHeight: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 16, borderRadius: 14, backgroundColor: "#0A7EA4" },
  memberMessageButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
  memberCallButton: { minHeight: 47, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 16, borderRadius: 14, backgroundColor: "#EAF7FD", borderWidth: 1, borderColor: "#B9DEEF" },
  memberCallButtonText: { color: "#0A6D9A", fontSize: 14, fontWeight: "900" },
  recentSectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 4 },
  recentEmptyList: { paddingVertical: 14 },
  recentConversationRow: { minHeight: 70, flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 8, paddingHorizontal: 4, borderBottomWidth: 1, borderBottomColor: "#E2EEF4" },
  recentIdentity: { flex: 1, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 12, paddingVertical: 3 },
  recentAvatar: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center", overflow: "hidden", backgroundColor: "#D8EFFA" },
  groupRecentAvatar: { backgroundColor: "#E8F5FB", borderWidth: 1, borderColor: "#CBE6F1" },
  recentAvatarImage: { width: "100%", height: "100%" },
  recentAvatarText: { color: "#0A6D9A", fontSize: 17, fontWeight: "900" },
  recentConversationText: { flex: 1, minWidth: 0, gap: 3 },
  recentConversationName: { color: "#153E5D", fontSize: 14, fontWeight: "900" },
  recentConversationPreview: { color: "#688298", fontSize: 12, lineHeight: 17 },
  recentUnreadPreview: { color: "#153E5D", fontWeight: "900" },
  recentNameRow: { flexDirection: "row", alignItems: "center", gap: 4, minWidth: 0 },
  presenceDot: { width: 7, height: 7, borderRadius: 4 },
  presenceDotOnline: { backgroundColor: "#2E9B5B" },
  presenceDotOffline: { backgroundColor: "#A8B8C2" },
  recentPresenceLabel: { fontSize: 9, fontWeight: "800" },
  recentPresenceOnline: { color: "#2E9B5B" },
  recentPresenceOffline: { color: "#8194A0" },
  recentConversationMeta: { width: 59, alignItems: "flex-end", gap: 7 },
  recentConversationTime: { color: "#7992A3", fontSize: 9, textAlign: "right" },
  recentUnreadBadge: { minWidth: 20, height: 20, paddingHorizontal: 5, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#0A7EA4" },
  recentUnreadBadgeText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  recentOpenButton: { width: 29, height: 29, alignItems: "center", justifyContent: "center", borderRadius: 15, backgroundColor: "#EAF7FD" },
  homeSearchBlock: { gap: 6, padding: 10, borderRadius: 15, borderWidth: 1, borderColor: "#CBE7F3", backgroundColor: "#F6FBFE" },
  homeSearchInputWrap: { minHeight: 45, flexDirection: "row", alignItems: "center", gap: 9, paddingLeft: 12, paddingRight: 5, borderRadius: 12, borderWidth: 1, borderColor: "#B8DDEC", backgroundColor: "#FFFFFF" },
  homeSearchInput: { flex: 1, minWidth: 0, paddingVertical: 9, color: "#153E5D", fontSize: 14 },
  clearHomeSearchButton: { width: 32, height: 32, alignItems: "center", justifyContent: "center", borderRadius: 16, backgroundColor: "#EEF7FB" },
  homeSearchHint: { paddingHorizontal: 2, color: "#678196", fontSize: 11, lineHeight: 16 },
  homePeopleResults: { gap: 4, paddingTop: 4 },
  homeSearchPersonRow: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8, paddingHorizontal: 4, borderBottomWidth: 1, borderBottomColor: "#E2EEF4" },
  homeSearchPersonIdentity: { flex: 1, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 12, paddingVertical: 3 },
  banButton: { alignSelf: "center", paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9, backgroundColor: "#FDECEC" },
  banButtonText: { color: "#B42318", fontSize: 11, fontWeight: "900" },
  unbanButton: { alignSelf: "center", paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9, backgroundColor: "#E5F6ED" },
  unbanButtonText: { color: "#18794E", fontSize: 11, fontWeight: "900" },
  reportCard: { gap: 6, paddingTop: 11, borderTopWidth: 1, borderTopColor: "#E1ECF3" },
  reportStatus: { alignSelf: "center", color: "#8A640E", backgroundColor: "#FFF0BF", borderRadius: 999, paddingHorizontal: 9, paddingVertical: 5, fontSize: 11, fontWeight: "800" },
  reportStatusResolved: { color: "#18794E", backgroundColor: "#E5F6ED" },
  openUpdatesButton: { minHeight: 46, justifyContent: "center", alignItems: "center", paddingHorizontal: 14, borderRadius: 13, backgroundColor: "#0A7EA4" },
  imageModalBackdrop: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(4, 22, 35, 0.94)", padding: 16 },
  imageModalCloseArea: { ...StyleSheet.absoluteFillObject },
  fullScreenImage: { width: "100%", height: "76%" },
  imageModalControls: { width: "100%", maxWidth: 410, flexDirection: "row", justifyContent: "center", gap: 9, marginTop: 14 },
  modalSaveButton: { justifyContent: "center", paddingHorizontal: 14, paddingVertical: 11, borderRadius: 11, backgroundColor: "#0A7EA4" },
  modalCloseButton: { justifyContent: "center", paddingHorizontal: 14, paddingVertical: 11, borderRadius: 11, backgroundColor: "#FFFFFF" },
  modalCloseText: { color: "#103B5B", fontWeight: "800" },
  sheetBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(4, 22, 35, 0.45)" },
  sheet: { gap: 12, padding: 20, borderTopLeftRadius: 24, borderTopRightRadius: 24, backgroundColor: "#FFFFFF" },
  sheetTitle: { color: "#103B5B", fontSize: 19, fontWeight: "900" },
  reportReasonInput: { minHeight: 96, maxHeight: 180 },
  blockButton: { minHeight: 44, justifyContent: "center", alignItems: "center", borderRadius: 12, backgroundColor: "#FDECEC" },
  blockButtonText: { color: "#B42318", fontWeight: "900" },
  banConfirmButton: { minHeight: 44, justifyContent: "center", alignItems: "center", borderRadius: 12, backgroundColor: "#B42318" },
  cancelSheetText: { alignSelf: "center", color: "#587186", fontWeight: "800", paddingVertical: 7 },
  comingSoon: { alignSelf: "flex-start", color: "#526C7D", backgroundColor: "#E1E9EE", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999, fontWeight: "800", fontSize: 11 },
});
