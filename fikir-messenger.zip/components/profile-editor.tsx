import * as ImagePicker from "expo-image-picker";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Image, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

import { getApiBaseUrl } from "@/constants/oauth";
import type { User } from "@/lib/_core/auth";
import { isUsernameFormatValid, normalizeUsername } from "@/lib/profile-utils";
import { trpc } from "@/lib/trpc";

type ProfileChanges = Pick<User, "name" | "username" | "avatarUrl" | "bio">;

type ProfileEditorProps = {
  user: User;
  onBack: () => void;
  onSaved: (changes: ProfileChanges) => Promise<void> | void;
};

function getAvatarUrl(value?: string | null) {
  if (!value) return null;
  if (/^https?:\/\//i.test(value) || value.startsWith("file:") || value.startsWith("data:")) return value;
  const apiBase = getApiBaseUrl();
  return apiBase ? `${apiBase}${value}` : value;
}

function initials(value?: string | null) {
  return value?.trim().slice(0, 2) || "ফি";
}

export function ProfileEditor({ user, onBack, onSaved }: ProfileEditorProps) {
  const [name, setName] = useState(user.name ?? "");
  const [username, setUsername] = useState(user.username ?? "");
  const [bio, setBio] = useState(user.bio ?? "");
  const [localImage, setLocalImage] = useState<{ uri: string; base64?: string | null; mimeType?: string | null } | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const normalizedUsername = normalizeUsername(username);
  const usernameFormatValid = isUsernameFormatValid(username);
  const needsUsernameCheck = usernameFormatValid && normalizedUsername !== (user.username ?? "").toLowerCase();
  const usernameCheck = trpc.profile.usernameAvailable.useQuery(
    { username: normalizedUsername || "placeholder" },
    { enabled: needsUsernameCheck, staleTime: 800 },
  );
  const uploadAvatar = trpc.profile.uploadAvatar.useMutation();
  const updateProfile = trpc.profile.update.useMutation();

  useEffect(() => {
    setMessage(null);
  }, [name, username, bio, localImage]);

  const shownAvatar = useMemo(() => localImage?.uri ?? getAvatarUrl(user.avatarUrl), [localImage?.uri, user.avatarUrl]);
  const saving = uploadAvatar.isPending || updateProfile.isPending;
  const usernameError = username.length === 0
    ? "সবার সঙ্গে সংযোগের জন্য একটি স্বতন্ত্র ইউজারনেম দিন।"
    : !usernameFormatValid
      ? "ইউজারনেম ৩–৩২ অক্ষরের হতে হবে এবং শুধু ইংরেজি অক্ষর, সংখ্যা, ডট বা আন্ডারস্কোর ব্যবহার করা যাবে।"
      : usernameCheck.data && !usernameCheck.data.available
        ? "এই ইউজারনেমটি ইতিমধ্যে ব্যবহার করা হচ্ছে। অন্য একটি নাম দিন।"
        : null;

  const chooseAvatar = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setMessage("প্রোফাইল ছবি বাছাই করতে গ্যালারির অনুমতি প্রয়োজন।");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true,
    });
    if (!result.canceled && result.assets[0]) {
      setLocalImage({ uri: result.assets[0].uri, base64: result.assets[0].base64, mimeType: result.assets[0].mimeType });
    }
  };

  const save = async () => {
    if (!name.trim()) {
      setMessage("প্রোফাইল নাম খালি রাখা যাবে না।");
      return;
    }
    if (usernameError) {
      setMessage(usernameError);
      return;
    }
    try {
      let avatarUrl = user.avatarUrl ?? null;
      if (localImage?.base64) {
        const uploaded = await uploadAvatar.mutateAsync({
          base64: localImage.base64,
          contentType: localImage.mimeType === "image/png" ? "image/png" : localImage.mimeType === "image/webp" ? "image/webp" : "image/jpeg",
        });
        avatarUrl = uploaded.avatarUrl;
      }
      await updateProfile.mutateAsync({
        name: name.trim(),
        username: normalizedUsername,
        bio: bio.trim() || null,
        avatarUrl,
      });
      await onSaved({ name: name.trim(), username: normalizedUsername, bio: bio.trim() || null, avatarUrl });
      setMessage("আপনার প্রোফাইল সফলভাবে সংরক্ষণ হয়েছে।");
    } catch (error) {
      const text = error instanceof Error ? error.message : "প্রোফাইল সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।";
      setMessage(text);
    }
  };

  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} accessibilityLabel="প্রোফাইলে ফিরে যান" style={styles.backButton}>
          <Text style={styles.backArrow}>‹</Text>
        </TouchableOpacity>
        <View>
          <Text style={styles.title}>প্রোফাইল সম্পাদনা</Text>
          <Text style={styles.subtitle}>আপনার পরিচিতি অন্য ব্যবহারকারীরা দেখতে পাবেন</Text>
        </View>
      </View>

      <View style={styles.avatarSection}>
        <TouchableOpacity onPress={chooseAvatar} style={styles.avatarButton} accessibilityLabel="প্রোফাইল ছবি পরিবর্তন করুন">
          {shownAvatar ? <Image source={{ uri: shownAvatar }} style={styles.avatarImage} /> : <Text style={styles.avatarInitials}>{initials(name)}</Text>}
          <View style={styles.cameraBadge}><Text style={styles.cameraGlyph}>⌁</Text></View>
        </TouchableOpacity>
        <TouchableOpacity onPress={chooseAvatar}><Text style={styles.changePhoto}>ছবি পরিবর্তন করুন</Text></TouchableOpacity>
        <Text style={styles.helper}>বর্গাকার ও পরিষ্কার ছবি নির্বাচন করুন</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>প্রোফাইল নাম</Text>
        <TextInput value={name} onChangeText={setName} placeholder="আপনার নাম" placeholderTextColor="#7890A8" style={styles.input} maxLength={100} returnKeyType="next" />

        <Text style={styles.label}>ইউজারনেম</Text>
        <View style={[styles.usernameField, usernameError && styles.inputError]}>
          <Text style={styles.atSign}>@</Text>
          <TextInput value={username} onChangeText={setUsername} placeholder="unique.username" placeholderTextColor="#7890A8" autoCapitalize="none" autoCorrect={false} style={styles.usernameInput} maxLength={32} />
          {usernameCheck.isFetching ? <ActivityIndicator size="small" color="#0B4F9C" /> : needsUsernameCheck && usernameCheck.data?.available ? <Text style={styles.available}>✓</Text> : null}
        </View>
        {usernameError ? <Text style={styles.errorText}>{usernameError}</Text> : normalizedUsername && !needsUsernameCheck ? <Text style={styles.okText}>এই ইউজারনেমটি আপনার প্রোফাইলে সংরক্ষিত আছে।</Text> : needsUsernameCheck && usernameCheck.data?.available ? <Text style={styles.okText}>ইউজারনেমটি ব্যবহার করা যাবে।</Text> : null}

        <Text style={styles.label}>সংক্ষিপ্ত পরিচিতি</Text>
        <TextInput value={bio} onChangeText={setBio} placeholder="আপনার সম্পর্কে সংক্ষিপ্ত কিছু লিখুন" placeholderTextColor="#7890A8" style={[styles.input, styles.bioInput]} maxLength={600} multiline textAlignVertical="top" />
        <Text style={styles.counter}>{bio.length}/600</Text>
      </View>

      {message ? <Text style={message.includes("সফল") ? styles.successMessage : styles.errorMessage}>{message}</Text> : null}
      <TouchableOpacity style={[styles.saveButton, saving && styles.saveButtonDisabled]} onPress={save} disabled={saving}>
        {saving ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.saveText}>পরিবর্তন সংরক্ষণ করুন</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: "#F4F8FC" },
  content: { padding: 18, paddingBottom: 40 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 22 },
  backButton: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: "#E1EFFB" },
  backArrow: { color: "#0B4F9C", fontSize: 34, lineHeight: 34, marginTop: -5 },
  title: { color: "#17324D", fontSize: 22, fontWeight: "800" },
  subtitle: { color: "#617992", fontSize: 13, marginTop: 2 },
  avatarSection: { alignItems: "center", marginBottom: 22 },
  avatarButton: { width: 108, height: 108, borderRadius: 54, backgroundColor: "#0B4F9C", alignItems: "center", justifyContent: "center", overflow: "visible" },
  avatarImage: { width: 108, height: 108, borderRadius: 54, borderWidth: 4, borderColor: "#FFFFFF" },
  avatarInitials: { color: "#FFFFFF", fontSize: 34, fontWeight: "800" },
  cameraBadge: { position: "absolute", right: -2, bottom: 0, height: 31, width: 31, borderRadius: 16, backgroundColor: "#FFFFFF", borderWidth: 2, borderColor: "#D4E9FA", alignItems: "center", justifyContent: "center" },
  cameraGlyph: { color: "#0B4F9C", fontSize: 22, fontWeight: "900", transform: [{ rotate: "-35deg" }] },
  changePhoto: { color: "#0B4F9C", fontWeight: "800", marginTop: 11, fontSize: 15 },
  helper: { color: "#7890A8", fontSize: 12, marginTop: 4 },
  card: { backgroundColor: "#FFFFFF", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: "#D9E6F2" },
  label: { color: "#2A4663", fontWeight: "800", fontSize: 14, marginTop: 10, marginBottom: 7 },
  input: { minHeight: 48, borderRadius: 12, borderWidth: 1, borderColor: "#C9D9E8", backgroundColor: "#FAFCFF", paddingHorizontal: 13, color: "#17324D", fontSize: 16 },
  usernameField: { height: 48, borderRadius: 12, borderWidth: 1, borderColor: "#C9D9E8", backgroundColor: "#FAFCFF", flexDirection: "row", alignItems: "center", paddingHorizontal: 13 },
  inputError: { borderColor: "#C93636", backgroundColor: "#FFF7F7" },
  atSign: { color: "#0B4F9C", fontSize: 17, fontWeight: "800", marginRight: 3 },
  usernameInput: { flex: 1, color: "#17324D", fontSize: 16, height: "100%" },
  available: { color: "#16805D", fontSize: 20, fontWeight: "800" },
  errorText: { color: "#B22626", fontSize: 12, lineHeight: 17, marginTop: 6 },
  okText: { color: "#167052", fontSize: 12, lineHeight: 17, marginTop: 6 },
  bioInput: { height: 118, paddingTop: 12 },
  counter: { color: "#7890A8", fontSize: 11, textAlign: "right", marginTop: 4 },
  saveButton: { minHeight: 52, borderRadius: 14, backgroundColor: "#0B4F9C", marginTop: 18, alignItems: "center", justifyContent: "center" },
  saveButtonDisabled: { opacity: 0.65 },
  saveText: { color: "#FFFFFF", fontWeight: "800", fontSize: 16 },
  successMessage: { color: "#167052", backgroundColor: "#E6F7F0", padding: 11, borderRadius: 10, marginTop: 15, textAlign: "center" },
  errorMessage: { color: "#B22626", backgroundColor: "#FFF1F1", padding: 11, borderRadius: 10, marginTop: 15, textAlign: "center" },
});
