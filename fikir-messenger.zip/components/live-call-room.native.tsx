import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import * as LiveKitNative from "@livekit/react-native";
import { formatCallDuration, getAudioOutputLabel, getNextAudioOutput } from "@/lib/call-controls";
import type { LiveKitConnection } from "./live-call-room.types";

type LiveCallRoomProps = {
  connection: LiveKitConnection;
  kind: "audio" | "video";
  title: string;
  onLeave: () => void;
  onFailure: (message: string) => void;
};

// Keep the native WebRTC package out of the web preview runtime. The actual call
// screen is available in an Android/iOS development build, where these modules exist.
const NativeLiveKit: any = Platform.OS === "web" ? null : LiveKitNative;

function NativeCallControls({ kind, title, onLeave, onFailure }: Omit<LiveCallRoomProps, "connection">) {
  const room = NativeLiveKit.useRoomContext();
  const { localParticipant, isMicrophoneEnabled, isCameraEnabled } = NativeLiveKit.useLocalParticipant();
  const connectionState = NativeLiveKit.useConnectionState();
  const [callDurationSeconds, setCallDurationSeconds] = useState(0);
  const [usesFrontCamera, setUsesFrontCamera] = useState(true);
  const [availableAudioOutputs, setAvailableAudioOutputs] = useState<string[]>([]);
  const [selectedAudioOutput, setSelectedAudioOutput] = useState<string | null>(null);
  const cameraTracks = NativeLiveKit.useTracks(["camera"]);
  const visibleTracks = useMemo(
    () => cameraTracks.filter((track: unknown) => NativeLiveKit.isTrackReference(track)),
    [cameraTracks],
  );

  useEffect(() => {
    let mounted = true;
    void (async () => {
      try {
        const outputs = await NativeLiveKit.AudioSession.getAudioOutputs();
        if (mounted) setAvailableAudioOutputs(outputs);
      } catch {
        if (mounted) onFailure("ডিভাইসের অডিও সেশন চালু করা যায়নি। মাইক্রোফোন অনুমতি পরীক্ষা করুন।");
      }
    })();
    return () => {
      mounted = false;
    };
  }, [onFailure]);

  useEffect(() => {
    if (connectionState !== "connected") return;
    let cancelled = false;
    void (async () => {
      try {
        // LiveKitRoom's audio/video props can be skipped by the native bridge
        // when the Android audio session is still starting. Explicitly publish
        // after connection so both participants receive real media tracks.
        await localParticipant.setMicrophoneEnabled(true);
        if (kind === "video") await localParticipant.setCameraEnabled(true);
      } catch {
        if (!cancelled) onFailure(kind === "video"
          ? "মাইক্রোফোন বা ক্যামেরা চালু করা যায়নি। Android Settings-এ দুইটির অনুমতি দিন।"
          : "মাইক্রোফোন চালু করা যায়নি। Android Settings-এ Microphone অনুমতি দিন।");
      }
    })();
    return () => { cancelled = true; };
  }, [connectionState, kind, localParticipant, onFailure]);

  useEffect(() => {
    if (connectionState !== "connected") {
      setCallDurationSeconds(0);
      return;
    }

    const startedAt = Date.now();
    const updateDuration = () => setCallDurationSeconds(Math.floor((Date.now() - startedAt) / 1000));
    updateDuration();
    const timer = setInterval(updateDuration, 1000);
    return () => clearInterval(timer);
  }, [connectionState]);

  const toggleMicrophone = () => {
    void localParticipant.setMicrophoneEnabled(!isMicrophoneEnabled).catch(() => {
      onFailure("মাইক্রোফোন পরিবর্তন করা যায়নি। ডিভাইসের অনুমতি পরীক্ষা করুন।");
    });
  };
  const toggleCamera = () => {
    void localParticipant.setCameraEnabled(!isCameraEnabled).catch(() => {
      onFailure("ক্যামেরা পরিবর্তন করা যায়নি। ডিভাইসের অনুমতি পরীক্ষা করুন।");
    });
  };
  const switchCamera = () => {
    const localCamera = visibleTracks.find((track: any) => track.participant?.isLocal)?.publication?.track;
    if (!isCameraEnabled || !localCamera?.restartTrack) {
      onFailure("ক্যামেরা বদলাতে আগে ভিডিও চালু করুন।");
      return;
    }
    const nextFacingMode = usesFrontCamera ? "environment" : "user";
    void localCamera.restartTrack({ facingMode: nextFacingMode }).then(() => {
      setUsesFrontCamera((current) => !current);
    }).catch(() => {
      onFailure("ক্যামেরা বদলানো যায়নি। ডিভাইসটি অন্য কোনো অ্যাপে ক্যামেরা ব্যবহার করছে কি না পরীক্ষা করুন।");
    });
  };
  const toggleAudioOutput = () => {
    const nextOutput = getNextAudioOutput(
      selectedAudioOutput,
      availableAudioOutputs,
      Platform.OS === "ios" ? "ios" : "android",
    );
    if (!nextOutput) {
      onFailure("এই মুহূর্তে অন্য কোনো অডিও আউটপুট পাওয়া যায়নি। হেডসেট বা ব্লুটুথ সংযোগ পরীক্ষা করুন।");
      return;
    }
    void NativeLiveKit.AudioSession.selectAudioOutput(nextOutput).then(() => {
      setSelectedAudioOutput(nextOutput);
    }).catch(() => {
      onFailure("অডিও আউটপুট পরিবর্তন করা যায়নি। আবার চেষ্টা করুন।");
    });
  };
  const leave = () => {
    room.disconnect();
  };

  return (
    <View style={styles.stage}>
      <View style={styles.topBar}>
        <View style={styles.titleBlock}>
          <Text style={styles.roomTitle} numberOfLines={1}>{title}</Text>
          <Text style={styles.connectionStatus}>{connectionState === "connected" ? `নিরাপদে সংযুক্ত • ${formatCallDuration(callDurationSeconds)}` : "সংযোগ হচ্ছে…"}</Text>
        </View>
        <View style={styles.kindBadge}><Text style={styles.kindBadgeText}>{kind === "video" ? "ভিডিও" : "অডিও"}</Text></View>
      </View>

      {kind === "video" ? (
        <View style={styles.videoArea}>
          {visibleTracks.length > 0 ? visibleTracks.map((track: any, index: number) => (
            <NativeLiveKit.VideoTrack
              key={`${track.participant.identity}-${track.source}-${index}`}
              trackRef={track}
              style={visibleTracks.length === 1 ? styles.videoLarge : styles.videoTile}
              objectFit="cover"
              mirror={track.participant.isLocal}
              zOrder={track.participant.isLocal ? 1 : 0}
            />
          )) : (
            <View style={styles.videoEmpty}>
              <View style={styles.avatar}><Text style={styles.avatarText}>{title.slice(0, 1)}</Text></View>
              <Text style={styles.emptyTitle}>{connectionState === "connected" ? "ভিডিওর অপেক্ষায়" : "ভিডিও কল সংযোগ হচ্ছে"}</Text>
              <Text style={styles.emptyCopy}>অন্য অংশগ্রহণকারী যুক্ত হলে ভিডিও এখানে দেখা যাবে।</Text>
            </View>
          )}
        </View>
      ) : (
        <View style={styles.audioArea}>
          <View style={styles.audioPulse}><View style={styles.avatar}><Text style={styles.avatarText}>{title.slice(0, 1)}</Text></View></View>
          <Text style={styles.audioTitle}>{title}</Text>
          <Text style={styles.emptyCopy}>{connectionState === "connected" ? "অডিও কল চলছে" : "নিরাপদ অডিও সংযোগ হচ্ছে"}</Text>
        </View>
      )}

      <View style={styles.controls}>
        <TouchableOpacity onPress={toggleMicrophone} style={[styles.controlButton, !isMicrophoneEnabled && styles.controlButtonMuted]} accessibilityLabel="মাইক্রোফোন চালু বা বন্ধ করুন">
          <Text style={styles.controlIcon}>{isMicrophoneEnabled ? "মাইক" : "মাইক বন্ধ"}</Text>
        </TouchableOpacity>
        {kind === "video" ? <TouchableOpacity onPress={toggleCamera} style={[styles.controlButton, !isCameraEnabled && styles.controlButtonMuted]} accessibilityLabel="ক্যামেরা চালু বা বন্ধ করুন">
          <Text style={styles.controlIcon}>{isCameraEnabled ? "ক্যামেরা" : "ক্যামেরা বন্ধ"}</Text>
        </TouchableOpacity> : null}
        {kind === "video" ? <TouchableOpacity onPress={switchCamera} style={[styles.controlButton, !isCameraEnabled && styles.controlButtonDisabled]} disabled={!isCameraEnabled} accessibilityLabel="সামনের বা পেছনের ক্যামেরা বেছে নিন">
          <Text style={styles.controlIcon}>ক্যামেরা বদল</Text>
        </TouchableOpacity> : null}
        <TouchableOpacity onPress={toggleAudioOutput} style={styles.controlButton} accessibilityLabel={`অডিও আউটপুট পরিবর্তন করুন। বর্তমান নির্বাচন: ${getAudioOutputLabel(selectedAudioOutput)}`}>
          <Text style={styles.controlIcon}>{getAudioOutputLabel(selectedAudioOutput)}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={leave} style={styles.endButton} accessibilityLabel="কল শেষ করুন"><Text style={styles.endButtonText}>কল শেষ</Text></TouchableOpacity>
      </View>
      <Text style={styles.volumeHint}>শব্দ কমানো বা বাড়াতে ফোনের ভলিউম বোতাম ব্যবহার করুন।</Text>
    </View>
  );
}

export function LiveCallRoom({ connection, kind, title, onLeave, onFailure }: LiveCallRoomProps) {
  const [audioSessionReady, setAudioSessionReady] = useState(false);
  const [audioSessionError, setAudioSessionError] = useState<string | null>(null);

  useEffect(() => {
    if (Platform.OS === "web" || !NativeLiveKit) return;
    let mounted = true;
    void NativeLiveKit.AudioSession.startAudioSession()
      .then(() => { if (mounted) setAudioSessionReady(true); })
      .catch(() => {
        if (mounted) {
          setAudioSessionError("ডিভাইসের অডিও সেশন চালু করা যায়নি। Microphone permission এবং Bluetooth/ফোনের অডিও সেটিংস পরীক্ষা করুন।");
          onFailure("ডিভাইসের অডিও সেশন চালু করা যায়নি। Microphone permission পরীক্ষা করুন।");
        }
      });
    return () => {
      mounted = false;
      void NativeLiveKit.AudioSession.stopAudioSession();
    };
  }, [onFailure]);

  if (Platform.OS === "web" || !NativeLiveKit) {
    return <View style={styles.unsupported}><Text style={styles.unsupportedTitle}>বাস্তব কল কেবল মোবাইল development build-এ চালু হবে</Text><Text style={styles.emptyCopy}>Android বা iOS development build ইনস্টল করে আবার কলটিতে যোগ দিন।</Text></View>;
  }
  const LiveKitRoom = NativeLiveKit.LiveKitRoom;
  if (audioSessionError) {
    return <View style={styles.unsupported}><Text style={styles.unsupportedTitle}>{audioSessionError}</Text></View>;
  }
  return (
    <LiveKitRoom
      serverUrl={connection.url}
      token={connection.token}
      connect={audioSessionReady}
      audio
      video={kind === "video"}
      options={{ adaptiveStream: { pixelDensity: "screen" } }}
      onError={() => onFailure("LiveKit কলে সংযোগ করা যায়নি। ইন্টারনেট ও কল অনুমতি পরীক্ষা করে আবার চেষ্টা করুন।")}
      onMediaDeviceFailure={() => onFailure("মাইক্রোফোন বা ক্যামেরা ব্যবহারের অনুমতি পাওয়া যায়নি।")}
      onDisconnected={onLeave}
    >
      <NativeCallControls kind={kind} title={title} onLeave={onLeave} onFailure={onFailure} />
    </LiveKitRoom>
  );
}

export function LiveCallConnecting() {
  return <View style={styles.connecting}><ActivityIndicator color="#FFFFFF" size="large" /><Text style={styles.connectingText}>নিরাপদ কল-সংযোগ প্রস্তুত হচ্ছে…</Text></View>;
}

const styles = StyleSheet.create({
  stage: { flex: 1, backgroundColor: "#061727", paddingTop: 18 },
  topBar: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 20, paddingBottom: 16 },
  titleBlock: { flex: 1, gap: 3 },
  roomTitle: { color: "#FFFFFF", fontSize: 19, fontWeight: "800" },
  connectionStatus: { color: "#A9D8F5", fontSize: 12, fontWeight: "700" },
  kindBadge: { paddingVertical: 7, paddingHorizontal: 10, borderRadius: 999, backgroundColor: "#133A58" },
  kindBadgeText: { color: "#D7F2FF", fontSize: 11, fontWeight: "800" },
  videoArea: { flex: 1, marginHorizontal: 12, borderRadius: 22, overflow: "hidden", backgroundColor: "#0C2840", justifyContent: "center" },
  videoLarge: { width: "100%", height: "100%" },
  videoTile: { flex: 1, minWidth: "50%", minHeight: 180 },
  videoEmpty: { alignItems: "center", justifyContent: "center", padding: 30, gap: 10 },
  audioArea: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30, gap: 12 },
  audioPulse: { width: 170, height: 170, borderRadius: 85, backgroundColor: "#123B5C", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#2B6A91" },
  avatar: { width: 104, height: 104, borderRadius: 52, alignItems: "center", justifyContent: "center", backgroundColor: "#A9DCF8" },
  avatarText: { color: "#0A4D75", fontSize: 42, fontWeight: "900" },
  audioTitle: { color: "#FFFFFF", fontSize: 22, fontWeight: "800", textAlign: "center" },
  emptyTitle: { color: "#FFFFFF", fontWeight: "800", fontSize: 18 },
  emptyCopy: { color: "#B3D0E3", fontSize: 13, lineHeight: 19, textAlign: "center" },
  controls: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingTop: 24, paddingBottom: 10 },
  controlButton: { minWidth: 88, minHeight: 48, justifyContent: "center", alignItems: "center", paddingHorizontal: 12, borderRadius: 15, backgroundColor: "#214F70" },
  controlButtonMuted: { backgroundColor: "#6A3940" },
  controlButtonDisabled: { opacity: 0.45 },
  controlIcon: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  endButton: { minWidth: 96, minHeight: 48, justifyContent: "center", alignItems: "center", paddingHorizontal: 14, borderRadius: 15, backgroundColor: "#C93636" },
  endButtonText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  volumeHint: { color: "#8BB9D5", fontSize: 11, fontWeight: "600", textAlign: "center", paddingHorizontal: 24, paddingBottom: 18 },
  connecting: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14, backgroundColor: "#061727" },
  connectingText: { color: "#FFFFFF", fontSize: 15, fontWeight: "700" },
  unsupported: { flex: 1, padding: 30, gap: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#061727" },
  unsupportedTitle: { color: "#FFFFFF", fontSize: 18, fontWeight: "800", textAlign: "center", lineHeight: 26 },
});
