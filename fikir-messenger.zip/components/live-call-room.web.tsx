import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import type { LiveKitConnection } from "./live-call-room.types";

type LiveCallRoomProps = {
  connection: LiveKitConnection;
  kind: "audio" | "video";
  title: string;
  onLeave: () => void;
  onFailure: (message: string) => void;
};

/** Web preview fallback. Native media calling is intentionally available only in a development build. */
export function LiveCallRoom({ kind, title, onLeave }: LiveCallRoomProps) {
  return (
    <View style={styles.page}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.badge}>{kind === "video" ? "ভিডিও কল" : "অডিও কল"}</Text>
      <Text style={styles.message}>
        বাস্তব অডিও ও ভিডিও কল Android বা iOS development build-এ চালু হবে। ওয়েব প্রিভিউতে শুধু মেসেঞ্জারের অন্যান্য ফিচার দেখা যাবে।
      </Text>
      <TouchableOpacity style={styles.button} onPress={onLeave} accessibilityRole="button">
        <Text style={styles.buttonText}>কল পর্দা বন্ধ করুন</Text>
      </TouchableOpacity>
    </View>
  );
}

export function LiveCallConnecting() {
  return (
    <View style={styles.page}>
      <ActivityIndicator color="#FFFFFF" size="large" />
      <Text style={styles.message}>নিরাপদ কল-সংযোগ প্রস্তুত হচ্ছে…</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, alignItems: "center", justifyContent: "center", padding: 28, backgroundColor: "#071D49" },
  title: { color: "#FFFFFF", fontSize: 24, fontWeight: "800", textAlign: "center" },
  badge: { color: "#C7E4FF", fontSize: 15, fontWeight: "700", marginTop: 10 },
  message: { color: "#E8F3FF", fontSize: 16, lineHeight: 24, marginTop: 26, textAlign: "center" },
  button: { backgroundColor: "#FFFFFF", borderRadius: 18, marginTop: 30, paddingHorizontal: 22, paddingVertical: 13 },
  buttonText: { color: "#0B5CAF", fontSize: 15, fontWeight: "800" },
});
