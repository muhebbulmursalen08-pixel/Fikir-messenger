// This file is used only by TypeScript resolution. Expo selects the `.native` or
// `.web` implementation at runtime.
export { LiveCallRoom, LiveCallConnecting } from "./live-call-room.web";
export type { LiveKitConnection } from "./live-call-room.types";
