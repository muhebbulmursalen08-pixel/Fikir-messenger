# ফিকির মেসেঞ্জার: বর্তমান সুবিধা, ব্যবহারযোগ্যতা ও কাজের পদ্ধতি

## সংক্ষিপ্ত পরিচয়

ফিকির মেসেঞ্জার হলো Gmail-ভিত্তিক একটি বাংলা-ডিফল্ট অনলাইন মেসেজিং অ্যাপ। এতে মোবাইল নম্বর ছাড়াই ব্যবহারকারীরা Gmail পরিচয়ের মাধ্যমে প্রবেশ করে ব্যক্তিগত বার্তা, গ্রুপ বার্তা, প্রতিষ্ঠাতা আপডেট এবং অডিও-ভিডিও কল ব্যবহার করতে পারেন। অ্যাপটির নকশায় নিরাপত্তা, সহজ ব্যবহার এবং বাস্তব মোবাইল ব্যবহারের বিষয়গুলোকে অগ্রাধিকার দেওয়া হয়েছে।

> **গুরুত্বপূর্ণ বাস্তবতা:** ওয়েব প্রিভিউতে মেসেঞ্জারের সাধারণ পর্দা দেখা যায়, কিন্তু বাস্তব মাইক্রোফোন, ক্যামেরা এবং LiveKit অডিও-ভিডিও কলের জন্য Android বা iOS development build প্রয়োজন। নতুন native build ইনস্টল করে দুইটি বাস্তব ফোনে পরীক্ষা করতে হবে।

## ১. Gmail দিয়ে প্রবেশ ও পরিচয়

ব্যবহারকারী Google/Gmail পরিচয় দিয়ে অ্যাপে প্রবেশ করেন। এখানে মোবাইল নম্বর ব্যবহার করার প্রয়োজন নেই। প্রবেশের পরে ব্যবহারকারীর নাম, Gmail-ভিত্তিক অ্যাকাউন্ট এবং একটি স্বতন্ত্র username ব্যবহার করে অন্যরা তাকে খুঁজে পেতে পারে।

ব্যবহারকারী নিজের নাম, username, profile picture এবং bio সম্পাদনা করতে পারেন। username নির্ধারণ করলে মানুষ search করে তাকে সহজে খুঁজে পায়।

## ২. হোম পেজে সাম্প্রতিক কথোপকথনের তালিকা

কোনো ব্যক্তির সঙ্গে প্রথমবার বার্তা আদান-প্রদান হলে সেই কথোপকথন হোম পেজের **সাম্প্রতিক কথোপকথন** তালিকায় যুক্ত হয়। অ্যাপ বন্ধ করে আবার খুললেও তালিকাটি server থেকে পুনরায় আসে।

প্রতিটি direct chat row-তে সাধারণত নিচের তথ্য দেখা যায়:

- ব্যক্তির নাম এবং profile picture;
- শেষ বার্তার সংক্ষিপ্ত preview;
- শেষ বার্তা পাঠানোর সময়;
- unread message badge;
- ব্যক্তি বর্তমানে online নাকি offline;
- chat খোলার জন্য সরাসরি chat button।

কোনো নাম বা profile picture-এ চাপলে profile খুলে যায়। chat icon-এ চাপলে সরাসরি সেই ব্যক্তির সঙ্গে কথোপকথন শুরু করা যায়।

## ৩. হোম পেজের search ব্যবস্থা

হোম পেজের search bar দিয়ে কথোপকথন এবং নতুন পরিচিতি খোঁজা যায়। Search করার সময় নাম, username, Gmail email অথবা শেষ বার্তার লেখা ব্যবহার করা যায়।

Search result দুইভাবে দেখা যায়। আগে সাম্প্রতিক কথোপকথনের মিল দেখানো হয়। এরপর নতুন পরিচিতি বা যাদের সঙ্গে আগে chat হয়নি, তাদের profile result দেখানো হয়। Result-এর profile খুলে সরাসরি message, audio call অথবা video call করা যায়।

## ৪. ব্যক্তিগত chat ও message আদান-প্রদান

ব্যবহারকারী একজনের সঙ্গে ব্যক্তিগত chat খুলে text message, emoji, ছবি, voice message এবং file পাঠাতে পারেন। Message পাঠানোর পরে sender নিজের message edit বা delete করতে পারেন। Message-এর delivery এবং seen status দেখা যায়।

অন্য ব্যবহারকারী message পড়লে read receipt বা seen status হালনাগাদ হয়। Chat list-এ unread message-এর সংখ্যা badge আকারে দেখা যায়। অ্যাপ offline থাকার সময় message এলে data connection ফিরে আসার পরে offline summary-তে sender এবং unread message-এর তথ্য দেখা যায়।

সংযুক্তি পাঠানোর সময় file type এবং ১০ MB সীমা সম্পর্কে নির্দেশনা দেখানো হয়। Upload চলাকালে progress card থাকে। Network, permission, file size অথবা server সমস্যার মতো কারণ আলাদা করে জানানো হয় এবং retry button দেওয়া থাকে।

## ৫. সম্পূর্ণ direct chat খালি করার সুবিধা

ব্যক্তিগত chat-এর header-এ **চ্যাট খালি** action আছে। এটি চাপলে confirmation dialog আসে। নিশ্চিত করলে ওই দুই ব্যক্তির কথোপকথনের সব direct message স্থায়ীভাবে মুছে যায়। এরপর chat screen, recent chat list এবং unread badge refresh হয়।

এই কাজ ফিরিয়ে আনা যায় না। তাই ব্যবহারকারীকে confirmation না দেওয়া পর্যন্ত message মুছে ফেলা হয় না।

## ৬. Member profile থেকে message ও call

Home list, search result অথবা people list থেকে কোনো সদস্যের profile খুললে সেখানে তিনটি প্রধান action থাকে:

1. বার্তা পাঠান;
2. অডিও কল;
3. ভিডিও কল।

এ কারণে user-কে আলাদা menu খুঁজতে হয় না। Profile থেকেই যোগাযোগের প্রয়োজনীয় কাজ শুরু করা যায়। নিজের profile-এ call বা message action না দেখিয়ে profile edit করার option দেখানো হয়।

## ৭. ব্যক্তিগত অডিও কলের কাজের পদ্ধতি

অডিও কল শুরু করলে server একটি ব্যক্তিগত call session তৈরি করে। প্রাপকের registered device token-এ high-priority incoming call notification পাঠানো হয়। Notification-এ কলকারীর পরিচয়, কলের ধরন এবং গ্রহণ বা প্রত্যাখ্যানের action থাকে।

প্রাপক notification-এর **গ্রহণ** button চাপলে:

1. call session active হয়;
2. প্রাপক স্বয়ংক্রিয়ভাবে LiveKit room-এ যোগ দেন;
3. প্রেরকের অ্যাপ active session শনাক্ত করে;
4. প্রেরকও স্বয়ংক্রিয়ভাবে একই room-এ যোগ দেন;
5. দুই ফোনের microphone track publish ও subscribe হয়ে real-time voice conversation শুরু হওয়ার কথা।

কলের সময় microphone mute/unmute, audio output পরিবর্তন এবং call end করার control থাকে।

## ৮. ব্যক্তিগত ভিডিও কলের কাজের পদ্ধতি

ভিডিও কলের flow অডিও কলের মতোই। পার্থক্য হলো, গ্রহণের পরে microphone-এর পাশাপাশি camera track চালু হয়। LiveKit একই নিরাপদ room-এ দুই পক্ষের video track পাঠায় এবং গ্রহণ করে।

ভিডিও call screen-এ local এবং remote video দেখা যায়। Camera on/off, microphone on/off, front/back camera switch, audio output এবং call end control থাকে। অন্য ব্যক্তি camera বন্ধ রাখলে video area-তে তার avatar বা অপেক্ষার status দেখা যায়।

## ৯. কল যাচ্ছে, incoming ring এবং missed call

Outgoing call শুরু হলে chat screen-এ **কল যাচ্ছে** status banner দেখা যায়। সেখানে বোঝা যায় যে অপর প্রান্তে call request পাঠানো হয়েছে এবং প্রাপক গ্রহণ করলে call automatically শুরু হবে। Sender চাইলে ringing অবস্থায় call cancel করতে পারেন।

প্রাপক কল গ্রহণ না করলে নির্দিষ্ট সময় পরে request missed call হিসেবে সংরক্ষিত হয়। Home page-এ missed call badge দেখা যায়। Offline বা data connection ফিরে এলে missed call summary-তে কলকারীর নাম, audio/video type এবং সময় দেখা যায়।

Missed call history থেকে:

- callback করা যায়;
- নির্দিষ্ট record delete করা যায়;
- সম্পূর্ণ missed-call history clear করা যায়।

## ১০. Group chat ও group call

ব্যবহারকারী group তৈরি করতে পারেন এবং সদস্য আমন্ত্রণ করতে পারেন। Group-এ text, image, file এবং voice message পাঠানো যায়। Group message-এ sender name এবং seen summary দেখা যায়।

Group owner বা admin সদস্য approve, promote বা remove করতে পারেন। Group privacy এবং announcement-only setting নিয়ন্ত্রণ করা যায়। Active group member-রা group audio বা video call শুরু করতে পারেন এবং অন্য সদস্যরা notification বা group screen থেকে join করতে পারেন।

## ১১. Online status ও last active

অ্যাপ heartbeat-এর মাধ্যমে user presence সংরক্ষণ করে। নির্দিষ্ট সময়ের মধ্যে heartbeat পাওয়া গেলে user online হিসেবে গণ্য হয়। নির্দিষ্ট সময় heartbeat না এলে user offline হিসেবে দেখানো হয়।

Home recent chat list-এ direct contact-এর পাশে online বা offline label দেখা যায়। Profile এবং chat screen-এ last active বা current presence label দেখা যায়। Founder dashboard-এও stale presence বাদ দিয়ে online count দেখানো হয়।

## ১২. Push notification ও offline support

অ্যাপ background বা বন্ধ অবস্থায় থাকলেও registered device token-এর মাধ্যমে message, group message, founder update এবং incoming call notification পাঠানোর ব্যবস্থা আছে। Android-এ message, audio call এবং video call-এর জন্য আলাদা high-importance notification channel ব্যবহার করা হয়েছে।

Notification পাওয়ার জন্য Android Settings-এ Notifications, Lock screen এবং Pop on screen চালু রাখা দরকার। Reliable incoming call-এর জন্য Battery setting-এ app-কে Unrestricted বা Don’t optimize করা প্রয়োজন। কিছু ফোনে Background restriction এবং Battery Saver বন্ধ রাখতে হয়।

## ১৩. প্রতিষ্ঠাতা আপডেট

নির্ধারিত founder Gmail account-গুলো প্রতিষ্ঠাতা update প্রকাশ করতে পারে। Update-এ text, emoji, valid link, একাধিক image এবং voice attachment রাখা যায়। Founder update edit, publish এবং delete করতে পারেন।

সাধারণ ব্যবহারকারীরা update দেখতে পারেন, image gallery-তে সংরক্ষণ করতে পারেন এবং link কপি বা খুলতে পারেন। তারা কেবল একটি অনুমোদিত emoji reaction দিতে পারেন। কোনো সাধারণ user update-এ text comment বা নিজের post করতে পারেন না। Founder দেখতে পারেন কারা update দেখেছেন এবং কারা reaction দিয়েছেন।

## ১৪. প্রতিষ্ঠাতা নিয়ন্ত্রণ বা Admin Dashboard

Founder control option কেবল অনুমোদিত founder Gmail account-এর জন্য server-side নিরাপদভাবে খোলা থাকে। সাধারণ user UI-তে option না পেলেও কেউ API পরিবর্তন করে admin access নিতে পারে না, কারণ server প্রতিটি admin route-এ founder role যাচাই করে।

Dashboard-এ নিচের সুবিধাগুলো রয়েছে:

- সব সাধারণ user-এর তালিকা;
- user name বা Gmail দিয়ে real-time search;
- online user-কে আগে দেখানোর sorting;
- last active date ও time;
- all, regular, blocked এবং banned filter;
- total users count;
- গত ২৪ ঘণ্টায় sign-in করা user count;
- বর্তমানে online user count;
- banned account count;
- founder-এর ব্যক্তিগত block count;
- open report count;
- user-কে ব্যক্তিগতভাবে block বা unblock;
- কারণ লিখে user-কে platform-level ban বা unban;
- founder account-কে ban না করার সুরক্ষা;
- user report দেখা;
- report review বা resolve করা;
- founder biography সম্পাদনা ও সংরক্ষণ;
- founder update draft, publish, edit এবং delete control।

Founder block এবং platform ban এক জিনিস নয়। Block করলে নির্দিষ্ট founder-এর সঙ্গে ব্যক্তিগত message ও call বন্ধ হয়। Ban করলে user-এর app-level messaging, call এবং protected action বন্ধ হয়।

## ১৫. Notification settings

Settings page থেকে user notification sound এবং vibration আলাদাভাবে চালু বা বন্ধ করতে পারেন। পছন্দ AsyncStorage-এ device-level সংরক্ষিত থাকে। Android notification channel-ও preference অনুযায়ী পুনর্গঠন করা হয়।

Settings page-এ notification permission এবং battery optimization-এর জন্য বাংলায় নির্দেশনা দেওয়া আছে।

## ১৬. নিরাপত্তা ও permission ব্যবস্থা

Gmail-only identity, protected tRPC route, founder-only authorization এবং membership checks ব্যবহার করা হয়েছে। Call token server-side LiveKit credential দিয়ে স্বল্পমেয়াদি তৈরি হয়। শুধু call-এর initiator, recipient অথবা active group member token পেতে পারে।

Android manifest-এ camera, microphone, audio settings, notification, full-screen intent এবং call-related foreground service permission যোগ করা হয়েছে। iOS-এর জন্য microphone এবং camera usage description যোগ করা হয়েছে।

## ১৭. বর্তমান ব্যবহারযোগ্যতার সৎ মূল্যায়ন

কোড, server route, token generation, permission configuration, native prebuild, TypeScript, lint এবং ৫৩টি automated test সফল হয়েছে। তাই feature flow এবং implementation structure প্রস্তুত।

তবে real-time voice এবং video-এর চূড়ান্ত নিশ্চয়তা automated test দিয়ে একা দেওয়া যায় না। নতুন Android development build দুইটি physical phone-এ ইনস্টল করে একই সময়ে নিচের test করতে হবে:

1. দুই ফোনে আলাদা Gmail দিয়ে sign-in;
2. উভয় ফোনে notification, microphone এবং camera permission অনুমোদন;
3. Battery optimization বন্ধ বা Unrestricted;
4. প্রথম ফোন থেকে audio call;
5. দ্বিতীয় ফোনের lock screen ও app-বন্ধ অবস্থায় ring পরীক্ষা;
6. notification-এর গ্রহণ button চাপা;
7. দুই পাশে voice শোনা;
8. video call-এ দুই পাশের camera image দেখা;
9. microphone mute, camera switch এবং call end পরীক্ষা;
10. কল না ধরলে missed-call badge ও callback পরীক্ষা।

এই physical test সম্পন্ন না হওয়া পর্যন্ত বলা যাবে যে implementation প্রস্তুত, কিন্তু production-level real-device verification সম্পূর্ণ হয়নি।

## মানুষকে পড়ে শোনানোর সংক্ষিপ্ত বক্তব্য

“ফিকির মেসেঞ্জার Gmail দিয়ে ব্যবহার করা যায়, মোবাইল নম্বর লাগে না। এখানে ব্যক্তিগত ও group chat, text, emoji, ছবি, voice message এবং file পাঠানো যায়। যাদের সঙ্গে কথা বলা হয়েছে তারা Home page-এর recent chat list-এ সংরক্ষিত থাকে। Home page থেকেই নাম, username বা message লিখে মানুষ খুঁজে message, audio call এবং video call করা যায়।

“অডিও ও ভিডিও call-এর জন্য LiveKit ব্যবহার করা হয়েছে। একজন call করলে অপর প্রান্তে notification ও গ্রহণের option যায়। গ্রহণ করলে দুই ফোন একই নিরাপদ call room-এ যুক্ত হয়। Audio call-এ voice এবং video call-এ camera image আদান-প্রদান হয়। কল না ধরলে missed-call history ও badge দেখা যায়।

“প্রতিষ্ঠাতা account-এর জন্য আলাদা Admin Dashboard আছে। সেখানে user list, online count, total user count, last active time, report, block, unblock, ban এবং unban ব্যবস্থা আছে। Founder update-এ text, image, voice, link ও emoji reaction দেওয়া যায়। Settings থেকে notification sound, vibration এবং Android battery guidance পাওয়া যায়।”

## শেষ কথা

ফিকির মেসেঞ্জারের বর্তমান codebase-এ মেসেজিং, search, recent chat, presence, notification, missed call, founder update, admin control এবং LiveKit calling-এর প্রয়োজনীয় প্রধান কাঠামো যুক্ত আছে। বাস্তব মানুষের ব্যবহারের জন্য পরবর্তী অপরিহার্য ধাপ হলো নতুন development build দিয়ে দুই-ফোনের end-to-end পরীক্ষা এবং সেই পরীক্ষার ফল অনুযায়ী device-specific adjustment করা।

## References

[1]: https://docs.livekit.io/home/client/connect/ "LiveKit client connection documentation"
[2]: https://docs.expo.dev/versions/latest/sdk/notifications/ "Expo Notifications documentation"
[3]: https://docs.expo.dev/build/introduction/ "Expo development build documentation"

---

**প্রস্তুতকারক:** Manus AI  
**ডকুমেন্ট:** Fikir Messenger current capability and usability guide  
**ভাষা:** বাংলা

© Fikir Messenger project documentation.

