/** @type {const} */
const themeColors = {
  primary: { light: "#0B4F9C", dark: "#54A0FF" },
  background: { light: "#F6F9FE", dark: "#071729" },
  surface: { light: "#FFFFFF", dark: "#102A43" },
  foreground: { light: "#102A43", dark: "#F6F9FE" },
  muted: { light: "#61758A", dark: "#AEC3D9" },
  border: { light: "#D8E4F2", dark: "#234566" },
  success: { light: "#138A55", dark: "#5CD79E" },
  warning: { light: "#C98500", dark: "#FFC75C" },
  error: { light: "#C93636", dark: "#FF7B7B" },
};

module.exports = { themeColors };
