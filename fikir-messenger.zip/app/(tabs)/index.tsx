import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import * as MediaLibrary from "expo-media-library";
import { createAudioPlayer, RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { StatusBar } from "expo-status-bar";
import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Image, Modal, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from "react-native";

import { OnlineCommunity } from "@/components/online-community";
import { ProfileEditor } from "@/components/profile-editor";
import { ScreenContainer } from "@/components/screen-container";
import { startOAuthLogin } from "@/constants/oauth";
import { useAuth } from "@/hooks/use-auth";

type Tab = "chats" | "contacts" | "calls" | "profile";
type Screen = Tab | "conversation" | "settings" | "community" | "profile-edit";
type Language = "bn" | "ar" | "ur" | "fa" | "en";
type MessageKind = "text" | "image" | "file" | "voice";
type IconName = React.ComponentProps<typeof MaterialIcons>["name"];

type Conversation = { id: string; name: string; initials: string; tone: string; online: boolean; preview: string; updatedAt: string };
type Attachment = { uri: string; name: string; size?: number; mimeType?: string | null };
type Message = { id: string; chatId: string; text: string; mine: boolean; kind: MessageKind; createdAt: string; editedAt?: string; attachment?: Attachment; durationMs?: number; status?: "sent" | "seen" };
type LocalState = { conversations: Conversation[]; messages: Message[]; language: Language; notifications: boolean; readReceipts: boolean };

const STORE_KEY = "fikir-messenger.local.v2";
const undoWindowMs = 12_000;
const founderBio = `بسم الله الرحمن الرحيم
السلام عليكم ورحمة الله وبركاته

“যারা আমার পথে সর্বাত্মক চেষ্টা ও সাধনা করে, আমি অবশ্যই তাদেরকে আমার (সফলতার) পথ দেখাব।” — সূরা আল-আনকাবুত: ৬৯

প্রিয় দ্বীনি ভাই ও বোন, ফিকির (Fikir) পরিবারে আপনাকে স্বাগতম। এই বিশাল বিশ্বজগৎ মহান আল্লাহ তাআলার অসীম কুদরতের এক জীবন্ত নিদর্শন। চিন্তাশীল মানুষের জন্য প্রতিটি সৃষ্টির ভেতরেই লুকিয়ে আছে শিক্ষা ও ভাবনার সুযোগ। মানুষের অদম্য চেষ্টা ও সাধনাই সফলতার চাবি।

আমি মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন। আমার গ্রামের বাড়ি সুনামগঞ্জ জেলার জামালগঞ্জ উপজেলার নয়াহালট (পূর্বপাড়া) গ্রামে। আল্লাহ তাআলার অশেষ মেহেরবানিতে আমার প্রাতিষ্ঠানিক শিক্ষা জীবন কেটেছে সিলেটের বিশ্ববিখ্যাত কওমি বিদ্যাপীঠ ‘জামিয়া ইসলামিয়া আব্বাসিয়া কৌড়িয়া ইসলামাবাদ (বিশ্বনাথ, সিলেট)’–এ। আলহামদুলিল্লাহ, ইবতেদায়ী পঞ্চম শ্রেণী থেকে শুরু করে ২০২৫ সালে এই প্রতিষ্ঠান থেকেই আমি দাওরায়ে হাদীস (মাস্টার্স) সম্পন্ন করেছি। পাশাপাশি সহিহ কুরআন তিলাওয়াতের জন্য দারুল ক্বিরাত থেকে ক্বারী সনদ লাভ করেছি।

আমার এই পথচলায় সম্মানিত ওস্তাদগণের দিকনির্দেশনা ও দোয়া ছিল অপরিসীম। বিশেষ করে মাদ্রাসার আল-আব্বাস ছাত্র সংসদ পাঠাগারে কাটানো সময়গুলো—যেখানে অসংখ্য কিতাব অধ্যয়ন ও গবেষণার মাধ্যমে দ্বীনি ও প্রযুক্তিগত ভাবনায় আত্মনিয়োগের সুযোগ পেয়েছি।

যোগাযোগ ও গঠনমূলক ভাবনার একটি নিরাপদ মাধ্যম হিসেবে তৈরি করা হয়েছে এই ফিকির মেসেঞ্জার। আপনাদের সুবিধার্থে শুধুমাত্র ইংরেজি ভাষায় ‘Fikir’ নামে একটি সোশ্যাল মিডিয়া প্ল্যাটফর্মও রয়েছে, যেখানে বিশ্বজুড়ে ইতিবাচক চিন্তা বিনিময় করা সম্ভব।

আসুন, আমরা প্রযুক্তিকে সৎ ও কল্যাণের কাজে ব্যবহার করি। অহেতুক সময় নষ্ট না করে একে অপরকে ভালো কাজে উৎসাহিত করি এবং জ্ঞান চর্চার মাধ্যমে এগিয়ে যাই। অ্যাপটি ব্যবহার করে আপনার যেকোনো মতামত জানান এবং ভালো কাজের এই প্রচেষ্টায় আমাদের দোয়া ও ভালোবাসায় রাখুন। আল্লাহ তাআলা আমাদের সবাইকে তৌফিক দান করুন। আমিন।

মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন
এডমিন ও খাদিম — Fikir Platform`;

const translations = {
  bn: { chats: "চ্যাট", contacts: "কনট্যাক্ট", calls: "কল", profile: "প্রোফাইল", settings: "সেটিংস", searchChats: "চ্যাট খুঁজুন", searchContacts: "নাম খুঁজুন", newMessage: "নতুন বার্তা", message: "বার্তা লিখুন", attach: "সংযুক্তি", photo: "ছবি", camera: "ক্যামেরা", file: "ফাইল", voice: "ভয়েস", record: "রেকর্ড", pause: "থামান", resume: "আবার চালু", cancel: "বাতিল", send: "পাঠান", edit: "সম্পাদনা", delete: "মুছুন", undo: "ফিরিয়ে আনুন", save: "সেভ করুন", saved: "গ্যালারিতে সংরক্ষিত", sent: "পাঠানো", seen: "দেখা হয়েছে", language: "ভাষা", notifications: "বার্তার নোটিফিকেশন", receipts: "পড়া হয়েছে দেখান", storage: "স্টোরেজ ও ডেটা", privacy: "গোপনীয়তা", local: "এই ডিভাইসে সংরক্ষিত", offline: "অফলাইন-প্রথম সংস্করণ", online: "অনলাইনে", lastSeen: "শেষ দেখা সম্প্রতি", chooseLanguage: "ভাষা নির্বাচন করুন", attachments: "সংযুক্তি যোগ করুন", localOnly: "এই বার্তাটি শুধু এই ডিভাইসে সংরক্ষিত", recording: "ভয়েস রেকর্ড হচ্ছে", editMessage: "বার্তা সম্পাদনা", noChats: "কোনো চ্যাট পাওয়া যায়নি", savedMessage: "বার্তা সংরক্ষিত", deleted: "বার্তা মুছে ফেলা হয়েছে", undoHint: "ফিরিয়ে আনার জন্য চাপুন" },
  ar: { chats: "الدردشات", contacts: "جهات الاتصال", calls: "المكالمات", profile: "الملف الشخصي", settings: "الإعدادات", searchChats: "ابحث في الدردشات", searchContacts: "ابحث بالاسم", newMessage: "رسالة جديدة", message: "اكتب رسالة", attach: "إرفاق", photo: "صورة", camera: "الكاميرا", file: "ملف", voice: "صوت", record: "تسجيل", pause: "إيقاف مؤقت", resume: "استئناف", cancel: "إلغاء", send: "إرسال", edit: "تعديل", delete: "حذف", undo: "استعادة", save: "حفظ", saved: "تم الحفظ في المعرض", sent: "تم الإرسال", seen: "تمت المشاهدة", language: "اللغة", notifications: "إشعارات الرسائل", receipts: "إظهار إيصالات القراءة", storage: "التخزين والبيانات", privacy: "الخصوصية", local: "محفوظ على هذا الجهاز", offline: "إصدار محلي أولي", online: "متصل", lastSeen: "آخر ظهور مؤخراً", chooseLanguage: "اختر اللغة", attachments: "إضافة مرفق", localOnly: "هذه الرسالة محفوظة على هذا الجهاز فقط", recording: "جارٍ تسجيل رسالة صوتية", editMessage: "تعديل الرسالة", noChats: "لا توجد دردشات", savedMessage: "تم حفظ الرسالة", deleted: "تم حذف الرسالة", undoHint: "اضغط للاستعادة" },
  ur: { chats: "چیٹس", contacts: "رابطے", calls: "کالز", profile: "پروفائل", settings: "ترتیبات", searchChats: "چیٹس تلاش کریں", searchContacts: "نام تلاش کریں", newMessage: "نیا پیغام", message: "پیغام لکھیں", attach: "منسلک کریں", photo: "تصویر", camera: "کیمرہ", file: "فائل", voice: "وائس", record: "ریکارڈ", pause: "روکیں", resume: "دوبارہ شروع", cancel: "منسوخ", send: "بھیجیں", edit: "ترمیم", delete: "حذف", undo: "واپس لائیں", save: "محفوظ کریں", saved: "گیلری میں محفوظ", sent: "بھیج دیا", seen: "دیکھ لیا", language: "زبان", notifications: "پیغام اطلاعات", receipts: "رسیدیں دکھائیں", storage: "اسٹوریج اور ڈیٹا", privacy: "رازداری", local: "اسی ڈیوائس پر محفوظ", offline: "آف لائن ابتدائی ورژن", online: "آن لائن", lastSeen: "حال ہی میں دیکھا", chooseLanguage: "زبان منتخب کریں", attachments: "منسلکہ شامل کریں", localOnly: "یہ پیغام صرف اسی ڈیوائس پر محفوظ ہے", recording: "وائس پیغام ریکارڈ ہو رہا ہے", editMessage: "پیغام میں ترمیم", noChats: "کوئی چیٹ نہیں ملی", savedMessage: "پیغام محفوظ ہو گیا", deleted: "پیغام حذف ہو گیا", undoHint: "واپس لانے کیلئے دبائیں" },
  fa: { chats: "گفتگوها", contacts: "مخاطبان", calls: "تماس‌ها", profile: "نمایه", settings: "تنظیمات", searchChats: "جستجوی گفتگو", searchContacts: "جستجوی نام", newMessage: "پیام جدید", message: "پیام بنویسید", attach: "پیوست", photo: "تصویر", camera: "دوربین", file: "فایل", voice: "صوت", record: "ضبط", pause: "توقف", resume: "ادامه", cancel: "لغو", send: "ارسال", edit: "ویرایش", delete: "حذف", undo: "بازگردانی", save: "ذخیره", saved: "در گالری ذخیره شد", sent: "ارسال شد", seen: "دیده شد", language: "زبان", notifications: "اعلان پیام", receipts: "نمایش رسید خواندن", storage: "فضا و داده", privacy: "حریم خصوصی", local: "ذخیره‌شده در این دستگاه", offline: "نسخه محلی اولیه", online: "برخط", lastSeen: "آخرین بازدید اخیر", chooseLanguage: "زبان را انتخاب کنید", attachments: "افزودن پیوست", localOnly: "این پیام فقط در این دستگاه ذخیره شده است", recording: "پیام صوتی در حال ضبط است", editMessage: "ویرایش پیام", noChats: "گفتگویی یافت نشد", savedMessage: "پیام ذخیره شد", deleted: "پیام حذف شد", undoHint: "برای بازگردانی فشار دهید" },
  en: { chats: "Chats", contacts: "Contacts", calls: "Calls", profile: "Profile", settings: "Settings", searchChats: "Search chats", searchContacts: "Search by name", newMessage: "New message", message: "Write a message", attach: "Attach", photo: "Photo", camera: "Camera", file: "File", voice: "Voice", record: "Record", pause: "Pause", resume: "Resume", cancel: "Cancel", send: "Send", edit: "Edit", delete: "Delete", undo: "Restore", save: "Save", saved: "Saved to gallery", sent: "Sent", seen: "Seen", language: "Language", notifications: "Message notifications", receipts: "Show read receipts", storage: "Storage & data", privacy: "Privacy", local: "Saved on this device", offline: "Local-first version", online: "Online", lastSeen: "Last seen recently", chooseLanguage: "Choose a language", attachments: "Add attachment", localOnly: "This message is saved only on this device", recording: "Recording voice message", editMessage: "Edit message", noChats: "No chats found", savedMessage: "Message saved", deleted: "Message deleted", undoHint: "Tap to restore" },
} as const;

const initialConversations: Conversation[] = [
  { id: "founder", name: "মাওলানা মুহিব্বুল মুরসালীন", initials: "মু", tone: "#0B4F9C", online: true, preview: "ফিকির মেসেঞ্জারে আপনাকে স্বাগতম।", updatedAt: "2026-08-20T10:16:00.000Z" },
  { id: "afsan", name: "আফসানা রহমান", initials: "আ", tone: "#5B73B9", online: true, preview: "ছবিটি খুব সুন্দর হয়েছে।", updatedAt: "2026-08-20T09:42:00.000Z" },
  { id: "ridwan", name: "রিদওয়ান আহমেদ", initials: "রি", tone: "#A36A31", online: false, preview: "ভয়েস মেসেজ পাঠিয়েছেন", updatedAt: "2026-08-19T19:10:00.000Z" },
];

const seedMessages: Message[] = [
  { id: "seed-1", chatId: "founder", text: "আসসালামু আলাইকুম।", mine: false, kind: "text", createdAt: "2026-08-20T10:15:00.000Z" },
  { id: "seed-2", chatId: "founder", text: "ওয়ালাইকুম আসসালাম। ফিকির মেসেঞ্জারে স্বাগতম।", mine: true, kind: "text", createdAt: "2026-08-20T10:16:00.000Z", status: "seen" },
  { id: "seed-3", chatId: "founder", text: "লেখা, ছবি, ফাইল এবং ভয়েস বার্তা এই ডিভাইসে ব্যবহার করতে পারবেন।", mine: false, kind: "text", createdAt: "2026-08-20T10:17:00.000Z" },
];

const contacts = [
  { id: "afsan", name: "আফসানা রহমান", initials: "আ", tone: "#5B73B9", online: true },
  { id: "ridwan", name: "রিদওয়ান আহমেদ", initials: "রি", tone: "#A36A31", online: false },
  { id: "sumaiya", name: "সুমাইয়া ইসলাম", initials: "সু", tone: "#8953A8", online: true },
];

function Icon({ name, size = 24, color = "#102A43" }: { name: IconName; size?: number; color?: string }) { return <MaterialIcons name={name} size={size} color={color} />; }
function Avatar({ initials, tone }: { initials: string; tone: string }) { return <View style={[styles.avatar, { backgroundColor: tone }]}><Text style={styles.avatarText}>{initials}</Text></View>; }
function makeId() { return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }

export default function FikirMessenger() {
  const { user, loading: authLoading, updateUser } = useAuth();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder);
  const [screen, setScreen] = useState<Screen>("chats");
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [messages, setMessages] = useState<Message[]>(seedMessages);
  const [activeId, setActiveId] = useState("founder");
  const [language, setLanguage] = useState<Language>("bn");
  const [notifications, setNotifications] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [draft, setDraft] = useState("");
  const [search, setSearch] = useState("");
  const [attachmentOpen, setAttachmentOpen] = useState(false);
  const [languageOpen, setLanguageOpen] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [editing, setEditing] = useState<Message | null>(null);
  const [recordingOpen, setRecordingOpen] = useState(false);
  const [recordingPaused, setRecordingPaused] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [undoMessage, setUndoMessage] = useState<Message | null>(null);
  const [ready, setReady] = useState(false);
  const [signInStarting, setSignInStarting] = useState(false);
  const [founderBioExpanded, setFounderBioExpanded] = useState(false);
  const undoTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioPlayer = useRef<ReturnType<typeof createAudioPlayer> | null>(null);
  const t = translations[language];
  const rtl = language === "ar" || language === "ur" || language === "fa";
  const activeConversation = conversations.find((item) => item.id === activeId) ?? conversations[0];
  const locale = language === "bn" ? "bn-BD" : language === "ar" ? "ar" : language === "ur" ? "ur" : language === "fa" ? "fa" : "en-US";

  useEffect(() => {
    AsyncStorage.getItem(STORE_KEY).then((raw) => {
      if (!raw) return;
      const stored = JSON.parse(raw) as Partial<LocalState>;
      if (stored.conversations?.length) setConversations(stored.conversations);
      if (stored.messages?.length) setMessages(stored.messages);
      if (stored.language) setLanguage(stored.language);
      if (typeof stored.notifications === "boolean") setNotifications(stored.notifications);
      if (typeof stored.readReceipts === "boolean") setReadReceipts(stored.readReceipts);
    }).catch(() => undefined).finally(() => setReady(true));
    return () => { if (undoTimer.current) clearTimeout(undoTimer.current); audioPlayer.current?.remove(); };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const state: LocalState = { conversations, messages, language, notifications, readReceipts };
    AsyncStorage.setItem(STORE_KEY, JSON.stringify(state)).catch(() => undefined);
  }, [conversations, language, messages, notifications, readReceipts, ready]);

  const notify = (text: string) => { setToast(text); setTimeout(() => setToast(null), 2500); };
  const formatTime = (iso: string) => new Intl.DateTimeFormat(locale, { hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
  const formatDate = (iso: string) => new Intl.DateTimeFormat(locale, { day: "numeric", month: "short", year: "numeric" }).format(new Date(iso));
  const direction = rtl ? { textAlign: "right" as const, writingDirection: "rtl" as const } : undefined;
  const conversationMessages = useMemo(() => messages.filter((message) => message.chatId === activeId), [activeId, messages]);
  const filteredConversations = useMemo(() => conversations.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()) || item.preview.toLowerCase().includes(search.toLowerCase())), [conversations, search]);

  const updateConversation = (chatId: string, preview: string, time = new Date().toISOString()) => setConversations((current) => current.map((item) => item.id === chatId ? { ...item, preview, updatedAt: time } : item).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)));
  const addMessage = (message: Omit<Message, "id" | "createdAt"> & Partial<Pick<Message, "id" | "createdAt">>) => {
    const next: Message = { id: message.id ?? makeId(), createdAt: message.createdAt ?? new Date().toISOString(), ...message };
    setMessages((current) => [...current, next]);
    updateConversation(next.chatId, next.kind === "image" ? "📷 ছবি" : next.kind === "voice" ? "🎤 ভয়েস বার্তা" : next.kind === "file" ? `📄 ${next.attachment?.name ?? "ফাইল"}` : next.text, next.createdAt);
  };
  const persistFile = async (uri: string, name: string) => {
    if (!FileSystem.documentDirectory) return uri;
    const safeName = `${Date.now()}-${name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const target = `${FileSystem.documentDirectory}${safeName}`;
    try { await FileSystem.copyAsync({ from: uri, to: target }); return target; } catch { return uri; }
  };
  const openConversation = (id: string) => { setActiveId(id); setScreen("conversation"); setSearch(""); };
  const startConversation = (person: typeof contacts[number]) => {
    const existing = conversations.find((item) => item.id === person.id);
    if (!existing) setConversations((current) => [{ id: person.id, name: person.name, initials: person.initials, tone: person.tone, online: person.online, preview: t.newMessage, updatedAt: new Date().toISOString() }, ...current]);
    openConversation(person.id);
  };
  const sendText = () => {
    const text = draft.trim();
    if (!text) return;
    if (editing) {
      setMessages((current) => current.map((item) => item.id === editing.id ? { ...item, text, editedAt: new Date().toISOString() } : item));
      updateConversation(editing.chatId, text);
      setEditing(null); setDraft(""); notify(t.savedMessage); return;
    }
    addMessage({ chatId: activeId, text, mine: true, kind: "text", status: "sent" });
    setDraft("");
    if (readReceipts) setTimeout(() => setMessages((current) => current.map((item) => item.chatId === activeId && item.mine && item.status === "sent" ? { ...item, status: "seen" } : item)), 1700);
  };
  const deleteMessage = (message: Message) => {
    setMessages((current) => current.filter((item) => item.id !== message.id));
    setSelectedMessage(null); setUndoMessage(message); notify(`${t.deleted} · ${t.undoHint}`);
    if (undoTimer.current) clearTimeout(undoTimer.current);
    undoTimer.current = setTimeout(() => setUndoMessage(null), undoWindowMs);
  };
  const restoreMessage = () => { if (!undoMessage) return; setMessages((current) => [...current, undoMessage].sort((a, b) => a.createdAt.localeCompare(b.createdAt))); setUndoMessage(null); if (undoTimer.current) clearTimeout(undoTimer.current); notify(t.undo); };
  const openEdit = (message: Message) => { setSelectedMessage(null); setEditing(message); setDraft(message.text); };
  const pickImage = async (camera = false) => {
    setAttachmentOpen(false);
    if (camera) { const permission = await ImagePicker.requestCameraPermissionsAsync(); if (!permission.granted) { notify("Camera permission is required"); return; } }
    const result = camera ? await ImagePicker.launchCameraAsync({ allowsEditing: true, quality: 0.82 }) : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.82 });
    if (result.canceled) return;
    const asset = result.assets[0]; const uri = await persistFile(asset.uri, asset.fileName ?? "fikir-photo.jpg");
    addMessage({ chatId: activeId, text: "", mine: true, kind: "image", attachment: { uri, name: asset.fileName ?? "fikir-photo.jpg", size: asset.fileSize, mimeType: asset.mimeType }, status: "sent" });
  };
  const pickFile = async () => {
    setAttachmentOpen(false);
    const result = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0]; const uri = await persistFile(asset.uri, asset.name);
    addMessage({ chatId: activeId, text: "", mine: true, kind: "file", attachment: { uri, name: asset.name, size: asset.size, mimeType: asset.mimeType }, status: "sent" });
  };
  const saveImage = async (uri: string) => {
    const permission = await MediaLibrary.requestPermissionsAsync();
    if (!permission.granted) { notify("Gallery permission is required"); return; }
    try { await MediaLibrary.saveToLibraryAsync(uri); notify(t.saved); } catch { notify("Could not save this image"); }
  };
  const startRecording = async () => {
    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) { notify("Microphone permission is required"); return; }
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
    await recorder.prepareToRecordAsync(); recorder.record(); setRecordingOpen(true); setRecordingPaused(false);
  };
  const toggleRecording = async () => { if (recordingPaused) { recorder.record(); setRecordingPaused(false); } else { await recorder.pause(); setRecordingPaused(true); } };
  const cancelRecording = async () => { if (recorderState.isRecording || recordingPaused) await recorder.stop(); setRecordingOpen(false); setRecordingPaused(false); notify(t.cancel); };
  const sendVoice = async () => {
    await recorder.stop(); const source = recorder.uri; const durationMs = recorderState.durationMillis;
    setRecordingOpen(false); setRecordingPaused(false);
    if (!source) return;
    const uri = await persistFile(source, "voice-message.m4a");
    addMessage({ chatId: activeId, text: "", mine: true, kind: "voice", attachment: { uri, name: "voice-message.m4a" }, durationMs, status: "sent" });
    await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
  };
  const playVoice = (uri: string) => { audioPlayer.current?.remove(); const player = createAudioPlayer(uri); audioPlayer.current = player; player.play(); };
  const formatDuration = (ms = 0) => { const seconds = Math.max(0, Math.floor(ms / 1000)); return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`; };
  const languageNames: Record<Language, string> = { bn: "বাংলা", ar: "العربية", ur: "اردو", fa: "فارسی", en: "English" };
  const beginSignIn = async () => {
    setSignInStarting(true);
    try {
      await startOAuthLogin();
    } finally {
      setSignInStarting(false);
    }
  };

  if (authLoading) {
    return <ScreenContainer edges={["top", "bottom"]} containerClassName="bg-background"><StatusBar style="dark" /><View style={styles.authPage}><ActivityIndicator size="large" color="#0B4F9C" /><Text style={styles.authLoadingText}>ফিকির পরিচয় যাচাই করা হচ্ছে…</Text></View></ScreenContainer>;
  }

  if (!user) {
    return <ScreenContainer edges={["top", "bottom"]} containerClassName="bg-background"><StatusBar style="dark" /><View style={styles.authPage}><View style={styles.authGlobe}><Icon name="public" size={64} color="#DDF0FF" /></View><Text style={styles.authTitle}>ফিকির মেসেঞ্জার</Text><Text style={styles.authSubtitle}>নিরাপদ কমিউনিটি, ব্যক্তিগত চ্যাট ও গ্রুপ বার্তায় যোগ দিতে আপনার Gmail পরিচয় দিয়ে প্রবেশ করুন।</Text><TouchableOpacity style={styles.signInButton} onPress={beginSignIn} disabled={signInStarting}><Icon name="account-circle" size={22} color="#FFFFFF" /><Text style={styles.signInButtonText}>{signInStarting ? "সাইন-ইন শুরু হচ্ছে…" : "Gmail দিয়ে প্রবেশ করুন"}</Text></TouchableOpacity><Text style={styles.authHint}>প্রথমবার প্রবেশের পর একটি স্বতন্ত্র ইউজারনেম নির্বাচন করতে হবে।</Text></View></ScreenContainer>;
  }

  const renderChats = () => <View style={styles.page}>
    <View style={styles.header}><View><Text style={[styles.brand, direction]}>ফিকির মেসেঞ্জার</Text><Text style={[styles.muted, direction]}>অনলাইন কমিউনিটি ও এই ডিভাইসের চ্যাট</Text></View><TouchableOpacity onPress={() => setScreen("community")} accessibilityLabel="অনলাইন কমিউনিটি খুলুন"><Icon name="public" size={30} color="#0B4F9C" /></TouchableOpacity></View>
    <View style={styles.search}><Icon name="search" size={20} color="#607D9C" /><TextInput value={search} onChangeText={setSearch} placeholder={t.searchChats} placeholderTextColor="#607D9C" style={[styles.searchInput, direction]} /></View>
    <FlatList data={filteredConversations} keyExtractor={(item) => item.id} contentContainerStyle={styles.list} renderItem={({ item }) => <TouchableOpacity style={[styles.row, rtl && styles.rowRtl]} onPress={() => openConversation(item.id)}><Avatar initials={item.initials} tone={item.tone} /><View style={[styles.rowBody, rtl && styles.alignRight]}><View style={[styles.between, rtl && styles.rowRtl]}><Text style={[styles.name, direction]}>{item.name}</Text><Text style={styles.time}>{formatTime(item.updatedAt)}</Text></View><Text numberOfLines={1} style={[styles.preview, direction]}>{item.preview}</Text></View>{item.online ? <View style={styles.onlineDot} /> : null}</TouchableOpacity>} ListEmptyComponent={<Text style={styles.empty}>{t.noChats}</Text>} />
    <TouchableOpacity style={styles.fab} onPress={() => setScreen("contacts")}><Icon name="edit" size={21} color="#FFF" /><Text style={styles.fabText}>{t.newMessage}</Text></TouchableOpacity>
  </View>;

  const renderContacts = () => <View style={styles.page}>
    <Text style={[styles.screenTitle, direction]}>{t.contacts}</Text><TextInput value={search} onChangeText={setSearch} placeholder={t.searchContacts} placeholderTextColor="#607D9C" style={[styles.searchSolo, direction]} />
    <FlatList data={contacts.filter((item) => item.name.includes(search))} keyExtractor={(item) => item.id} contentContainerStyle={styles.list} renderItem={({ item }) => <TouchableOpacity style={[styles.row, rtl && styles.rowRtl]} onPress={() => startConversation(item)}><Avatar initials={item.initials} tone={item.tone} /><View style={[styles.rowBody, rtl && styles.alignRight]}><Text style={[styles.name, direction]}>{item.name}</Text><Text style={[styles.preview, direction]}>{item.online ? t.online : t.lastSeen}</Text></View><Icon name="chat-bubble-outline" size={21} color="#0B4F9C" /></TouchableOpacity>} />
  </View>;

  const renderCalls = () => <View style={styles.page}><Text style={[styles.screenTitle, direction]}>{t.calls}</Text><View style={styles.infoCard}><Icon name="wifi-off" size={25} color="#0B4F9C" /><View style={styles.infoCopy}><Text style={[styles.name, direction]}>{t.offline}</Text><Text style={[styles.preview, direction]}>Voice and video calling will activate with secure online accounts.</Text></View></View><View style={styles.callGrid}><TouchableOpacity style={styles.callCard} onPress={() => notify("Voice calling needs online accounts") }><Icon name="call" size={28} color="#0B4F9C" /><Text style={styles.callText}>{t.voice}</Text></TouchableOpacity><TouchableOpacity style={styles.callCard} onPress={() => notify("Video calling needs online accounts") }><Icon name="videocam" size={28} color="#0B4F9C" /><Text style={styles.callText}>Video</Text></TouchableOpacity></View></View>;

  const renderProfile = () => <ScrollView style={styles.page} contentContainerStyle={styles.list}><View style={styles.profileHero}>{user.avatarUrl ? <Image source={{ uri: user.avatarUrl }} style={styles.profileAvatarImage} /> : <View style={styles.globe}><Icon name="person" size={60} color="#BCE0FF" /></View>}<Text style={[styles.profileName, direction]}>{user.name || "ফিকির সদস্য"}</Text><Text style={[styles.profileMeta, direction]}>@{user.username || "username নির্বাচন করুন"}</Text>{user.bio ? <Text style={[styles.profileBio, direction]}>{user.bio}</Text> : <Text style={[styles.profileBio, direction]}>একটি পরিচিতি যোগ করে অন্যদের কাছে নিজেকে পরিচয় করান।</Text>}</View><TouchableOpacity style={[styles.menuRow, rtl && styles.rowRtl]} onPress={() => setScreen("profile-edit")}><Icon name="edit" size={22} color="#0B4F9C" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>প্রোফাইল সম্পাদনা</Text><Text style={[styles.preview, direction]}>নাম, ইউজারনেম, ছবি ও পরিচিতি</Text></View><Icon name="chevron-right" size={22} color="#607D9C" /></TouchableOpacity><TouchableOpacity style={[styles.menuRow, rtl && styles.rowRtl]} onPress={() => setScreen("settings")}><Icon name="settings" size={22} color="#0B4F9C" /><Text style={[styles.menuText, direction]}>{t.settings}</Text><Icon name="chevron-right" size={22} color="#607D9C" /></TouchableOpacity><View style={[styles.infoCard, rtl && styles.rowRtl]}><Icon name="info-outline" size={22} color="#167B65" /><View style={styles.infoCopy}><Text style={[styles.name, direction]}>ফিকির মেসেঞ্জার</Text><Text style={[styles.preview, direction]}>Gmail পরিচয়ে সুরক্ষিত অনলাইন কমিউনিটি</Text></View></View></ScrollView>;

  const renderSettings = () => <ScrollView style={styles.page} contentContainerStyle={styles.list}><View style={[styles.header, rtl && styles.rowRtl]}><TouchableOpacity onPress={() => setScreen("profile")}><Icon name="arrow-back" size={25} color="#0B4F9C" /></TouchableOpacity><Text style={[styles.screenTitle, direction]}>{t.settings}</Text></View><TouchableOpacity style={[styles.menuRow, rtl && styles.rowRtl]} onPress={() => setLanguageOpen(true)}><Icon name="language" size={22} color="#6C4BC3" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>{t.language}</Text><Text style={[styles.preview, direction]}>{languageNames[language]}</Text></View><Icon name="chevron-right" size={22} color="#607D9C" /></TouchableOpacity><View style={[styles.menuRow, rtl && styles.rowRtl]}><Icon name="notifications-none" size={22} color="#0B4F9C" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>{t.notifications}</Text><Text style={[styles.preview, direction]}>{t.local}</Text></View><Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: "#CFDCE9", true: "#8AB8ED" }} thumbColor={notifications ? "#0B4F9C" : "#fff"} /></View><View style={[styles.menuRow, rtl && styles.rowRtl]}><Icon name="done-all" size={22} color="#0B4F9C" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>{t.receipts}</Text><Text style={[styles.preview, direction]}>{t.seen}</Text></View><Switch value={readReceipts} onValueChange={setReadReceipts} trackColor={{ false: "#CFDCE9", true: "#8AB8ED" }} thumbColor={readReceipts ? "#0B4F9C" : "#fff"} /></View><View style={[styles.menuRow, rtl && styles.rowRtl]}><Icon name="storage" size={22} color="#C98500" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>{t.storage}</Text><Text style={[styles.preview, direction]}>{t.local}</Text></View></View><View style={[styles.menuRow, rtl && styles.rowRtl]}><Icon name="lock-outline" size={22} color="#167B65" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>{t.privacy}</Text><Text style={[styles.preview, direction]}>Personal ID security will be added next.</Text></View></View><TouchableOpacity style={[styles.menuRow, rtl && styles.rowRtl]} onPress={() => setScreen("community")}><Icon name="campaign" size={22} color="#0B4F9C" /><View style={styles.flex}><Text style={[styles.menuText, direction]}>প্রতিষ্ঠাতার আপডেট ও কমিউনিটি</Text><Text style={[styles.preview, direction]}>সবার জন্য গুরুত্বপূর্ণ বার্তা, পোস্ট ও গ্রুপ</Text></View><Icon name="chevron-right" size={22} color="#607D9C" /></TouchableOpacity><View style={styles.founderBioCard}><Text style={[styles.founderBioTitle, direction]}>প্রতিষ্ঠাতা পরিচিতি</Text><Text style={[styles.founderBioName, direction]}>মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন</Text><Text style={[styles.founderBioSummary, direction]}>দাওরায়ে হাদীস (মাস্টার্স), ২০২৫ · জামিয়া ইসলামিয়া আব্বাসিয়া কৌড়িয়া ইসলামাবাদ, বিশ্বনাথ, সিলেট</Text><TouchableOpacity onPress={() => setFounderBioExpanded((expanded) => !expanded)} accessibilityLabel="প্রতিষ্ঠাতার বিস্তারিত পরিচিতি"><Text style={styles.founderBioAction}>{founderBioExpanded ? "সংক্ষিপ্ত করুন" : "বিস্তারিত দেখুন"}</Text></TouchableOpacity>{founderBioExpanded ? <Text style={[styles.founderBioText, direction]}>{founderBio}</Text> : null}</View></ScrollView>;

  const renderMessage = ({ item }: { item: Message }) => <TouchableOpacity onLongPress={() => item.mine && setSelectedMessage(item)} activeOpacity={0.82} style={[styles.messageRow, item.mine ? styles.mineRow : styles.otherRow]}><View style={[styles.bubble, item.mine ? styles.mineBubble : styles.otherBubble]}>{item.kind === "image" && item.attachment ? <TouchableOpacity onPress={() => saveImage(item.attachment!.uri)}><Image source={{ uri: item.attachment.uri }} style={styles.imageMessage} /><Text style={[styles.saveHint, item.mine && styles.mineText]}>{t.save}</Text></TouchableOpacity> : null}{item.kind === "file" && item.attachment ? <View style={styles.fileBubble}><Icon name="insert-drive-file" size={27} color="#0B4F9C" /><Text numberOfLines={1} style={styles.fileName}>{item.attachment.name}</Text></View> : null}{item.kind === "voice" && item.attachment ? <TouchableOpacity style={styles.voiceBubble} onPress={() => playVoice(item.attachment!.uri)}><View style={styles.play}><Icon name="play-arrow" size={21} color="#FFF" /></View><View style={styles.wave} /><Text style={[styles.voiceLength, item.mine && styles.mineText]}>{formatDuration(item.durationMs)}</Text></TouchableOpacity> : null}{item.kind === "text" ? <Text style={[styles.messageText, item.mine && styles.mineText, direction]}>{item.text}</Text> : null}<Text style={[styles.messageMeta, item.mine && styles.mineText, direction]}>{formatDate(item.createdAt)} · {formatTime(item.createdAt)}{item.editedAt ? " · edited" : ""}{item.mine ? ` · ${item.status === "seen" && readReceipts ? t.seen : t.sent}` : ""}</Text></View></TouchableOpacity>;

  const renderConversation = () => <View style={styles.conversation}><View style={[styles.conversationHeader, rtl && styles.rowRtl]}><TouchableOpacity onPress={() => setScreen("chats")}><Icon name="arrow-back" size={25} color="#0B4F9C" /></TouchableOpacity><Avatar initials={activeConversation.initials} tone={activeConversation.tone} /><View style={[styles.flex, rtl && styles.alignRight]}><Text style={[styles.name, direction]}>{activeConversation.name}</Text><Text style={[styles.preview, direction]}>{activeConversation.online ? t.online : t.lastSeen}</Text></View><Icon name="more-vert" size={24} color="#0B4F9C" /></View><Text style={[styles.localBanner, direction]}>{t.localOnly}</Text><FlatList data={conversationMessages} keyExtractor={(item) => item.id} renderItem={renderMessage} contentContainerStyle={styles.messageList} />{recordingOpen ? <View style={[styles.recordBar, rtl && styles.rowRtl]}><View style={styles.recordDot} /><View style={styles.flex}><Text style={[styles.recordText, direction]}>{t.recording}</Text><Text style={[styles.preview, direction]}>{formatDuration(recorderState.durationMillis)}</Text></View><TouchableOpacity onPress={toggleRecording}><Icon name={recordingPaused ? "mic" : "pause"} size={25} color="#0B4F9C" /></TouchableOpacity><TouchableOpacity onPress={cancelRecording}><Icon name="delete-outline" size={26} color="#C93636" /></TouchableOpacity><TouchableOpacity style={styles.smallSend} onPress={sendVoice}><Icon name="send" size={18} color="#FFF" /></TouchableOpacity></View> : <View style={[styles.composer, rtl && styles.rowRtl]}><TouchableOpacity style={styles.composerButton} onPress={() => setAttachmentOpen(true)}><Icon name="attach-file" size={23} color="#486B8C" /></TouchableOpacity><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={sendText} placeholder={editing ? t.editMessage : t.message} placeholderTextColor="#64809C" multiline style={[styles.composerInput, direction]} /><TouchableOpacity style={draft.trim() ? styles.send : styles.mic} onPress={draft.trim() ? sendText : startRecording}><Icon name={draft.trim() ? "send" : "mic"} size={20} color="#FFF" /></TouchableOpacity></View>}</View>;

  const renderScreen = () => screen === "chats" ? renderChats() : screen === "contacts" ? renderContacts() : screen === "calls" ? renderCalls() : screen === "profile" ? renderProfile() : screen === "profile-edit" ? <ProfileEditor user={user} onBack={() => setScreen("profile")} onSaved={(changes) => updateUser({ ...user, ...changes })} /> : screen === "settings" ? renderSettings() : screen === "community" ? <OnlineCommunity user={user} onBack={() => setScreen("chats")} /> : renderConversation();
  const tab = (key: Tab, icon: IconName, label: string) => <TouchableOpacity style={styles.tab} onPress={() => { setSearch(""); setScreen(key); }}><Icon name={icon} size={23} color={screen === key ? "#0B4F9C" : "#7890A8"} /><Text style={[styles.tabText, screen === key && styles.tabActive, direction]}>{label}</Text></TouchableOpacity>;

  return <ScreenContainer edges={["top", "bottom"]} containerClassName="bg-background"><StatusBar style="dark" /><View style={styles.shell}>{renderScreen()}{(["chats", "contacts", "calls", "profile"] as Screen[]).includes(screen) ? <View style={styles.tabs}>{tab("chats", "chat-bubble", t.chats)}{tab("contacts", "people-alt", t.contacts)}{tab("calls", "call", t.calls)}{tab("profile", "person", t.profile)}</View> : null}{undoMessage ? <TouchableOpacity style={styles.undo} onPress={restoreMessage}><Text style={styles.undoText}>{t.undo}</Text><Text style={styles.undoHint}>{t.undoHint}</Text></TouchableOpacity> : null}{toast ? <View style={styles.toast}><Text style={styles.toastText}>{toast}</Text></View> : null}</View>
    <Modal transparent animationType="slide" visible={attachmentOpen} onRequestClose={() => setAttachmentOpen(false)}><Pressable style={styles.backdrop} onPress={() => setAttachmentOpen(false)}><Pressable style={styles.sheet} onPress={(event) => event.stopPropagation()}><View style={styles.handle} /><Text style={[styles.sheetTitle, direction]}>{t.attachments}</Text><View style={styles.attachmentGrid}><TouchableOpacity style={styles.attachAction} onPress={() => pickImage(false)}><Icon name="image" size={27} color="#0B4F9C" /><Text style={styles.attachText}>{t.photo}</Text></TouchableOpacity><TouchableOpacity style={styles.attachAction} onPress={() => pickImage(true)}><Icon name="camera-alt" size={27} color="#167B65" /><Text style={styles.attachText}>{t.camera}</Text></TouchableOpacity><TouchableOpacity style={styles.attachAction} onPress={pickFile}><Icon name="insert-drive-file" size={27} color="#C98500" /><Text style={styles.attachText}>{t.file}</Text></TouchableOpacity><TouchableOpacity style={styles.attachAction} onPress={() => { setAttachmentOpen(false); startRecording(); }}><Icon name="mic" size={27} color="#6C4BC3" /><Text style={styles.attachText}>{t.voice}</Text></TouchableOpacity></View></Pressable></Pressable></Modal>
    <Modal transparent animationType="fade" visible={languageOpen} onRequestClose={() => setLanguageOpen(false)}><Pressable style={styles.backdrop} onPress={() => setLanguageOpen(false)}><View style={styles.dialog}><Text style={[styles.sheetTitle, direction]}>{t.chooseLanguage}</Text>{(Object.keys(languageNames) as Language[]).map((code) => <TouchableOpacity key={code} style={styles.languageRow} onPress={() => { setLanguage(code); setLanguageOpen(false); }}><Text style={styles.menuText}>{languageNames[code]}</Text>{language === code ? <Icon name="check" size={22} color="#0B4F9C" /> : null}</TouchableOpacity>)}</View></Pressable></Modal>
    <Modal transparent animationType="fade" visible={!!selectedMessage} onRequestClose={() => setSelectedMessage(null)}><Pressable style={styles.backdrop} onPress={() => setSelectedMessage(null)}><View style={styles.dialog}>{selectedMessage ? <>{selectedMessage.kind === "text" ? <TouchableOpacity style={styles.languageRow} onPress={() => openEdit(selectedMessage)}><Icon name="edit" size={21} color="#0B4F9C" /><Text style={styles.menuText}>{t.edit}</Text></TouchableOpacity> : null}<TouchableOpacity style={styles.languageRow} onPress={() => deleteMessage(selectedMessage)}><Icon name="delete-outline" size={21} color="#C93636" /><Text style={[styles.menuText, { color: "#C93636" }]}>{t.delete}</Text></TouchableOpacity></> : null}</View></Pressable></Modal>
  </ScreenContainer>;
}

const styles = StyleSheet.create({
  shell: { flex: 1, backgroundColor: "#F6F9FE" }, authPage: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 28, backgroundColor: "#F6F9FE" }, authGlobe: { width: 126, height: 126, borderRadius: 63, justifyContent: "center", alignItems: "center", backgroundColor: "#0B4F9C", marginBottom: 22 }, authTitle: { color: "#102A43", fontSize: 27, fontWeight: "800" }, authSubtitle: { color: "#587186", textAlign: "center", fontSize: 15, lineHeight: 23, marginTop: 12, maxWidth: 345 }, signInButton: { marginTop: 28, minHeight: 52, borderRadius: 26, paddingHorizontal: 22, backgroundColor: "#0B4F9C", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, alignSelf: "stretch" }, signInButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "800" }, authHint: { color: "#63809B", textAlign: "center", fontSize: 12, lineHeight: 18, marginTop: 16 }, authLoadingText: { color: "#587186", marginTop: 14, fontSize: 14 }, page: { flex: 1, padding: 18 }, conversation: { flex: 1, backgroundColor: "#EEF5FC" }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }, brand: { color: "#102A43", fontWeight: "800", fontSize: 21 }, muted: { color: "#64809C", fontSize: 12, marginTop: 3 }, screenTitle: { color: "#102A43", fontWeight: "800", fontSize: 23 }, search: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#E7F0F9", borderRadius: 14, paddingHorizontal: 12, marginBottom: 10 }, searchInput: { flex: 1, height: 46, color: "#102A43", fontSize: 15 }, searchSolo: { height: 47, borderRadius: 14, backgroundColor: "#E7F0F9", paddingHorizontal: 14, marginTop: 16, marginBottom: 10, color: "#102A43" }, list: { paddingBottom: 92 }, row: { flexDirection: "row", alignItems: "center", paddingVertical: 12, gap: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#D6E2EE" }, rowRtl: { flexDirection: "row-reverse" }, rowBody: { flex: 1 }, alignRight: { alignItems: "flex-end" }, between: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, name: { color: "#102A43", fontSize: 16, fontWeight: "700" }, preview: { color: "#637D96", fontSize: 13, marginTop: 3 }, time: { color: "#63809B", fontSize: 11 }, avatar: { width: 49, height: 49, borderRadius: 25, justifyContent: "center", alignItems: "center" }, avatarText: { color: "#FFF", fontSize: 18, fontWeight: "800" }, onlineDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#15A568", borderWidth: 2, borderColor: "#F6F9FE", marginLeft: -18, alignSelf: "flex-end", marginBottom: 1 }, fab: { position: "absolute", right: 20, bottom: 20, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 18, height: 48, borderRadius: 24, backgroundColor: "#0B4F9C", elevation: 4 }, fabText: { color: "#FFF", fontWeight: "800" }, empty: { textAlign: "center", marginTop: 55, color: "#63809B" }, infoCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 15, borderRadius: 16, backgroundColor: "#E7F0FA", marginTop: 17 }, infoCopy: { flex: 1 }, callGrid: { flexDirection: "row", gap: 12, marginTop: 18 }, callCard: { flex: 1, backgroundColor: "#FFF", minHeight: 110, borderRadius: 18, alignItems: "center", justifyContent: "center", gap: 8 }, callText: { color: "#102A43", fontWeight: "700" }, profileHero: { backgroundColor: "#0B4F9C", borderRadius: 23, padding: 22, alignItems: "center", marginBottom: 7 }, globe: { width: 94, height: 94, borderRadius: 47, justifyContent: "center", alignItems: "center", backgroundColor: "#135B9F" }, profileAvatarImage: { width: 94, height: 94, borderRadius: 47, borderWidth: 3, borderColor: "#BCE0FF" }, profileName: { color: "#FFF", fontSize: 19, fontWeight: "800", marginTop: 13 }, profileMeta: { color: "#B9D9F7", fontSize: 13, marginTop: 4 }, profileBio: { color: "#D7EAFC", fontSize: 13, lineHeight: 19, marginTop: 10, textAlign: "center" }, menuRow: { flexDirection: "row", alignItems: "center", gap: 13, paddingVertical: 15, paddingHorizontal: 3, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#D6E2EE" }, menuText: { color: "#102A43", fontSize: 16, fontWeight: "700" }, founderBioCard: { marginTop: 12, backgroundColor: "#E8F4FE", borderWidth: 1, borderColor: "#BFDBF3", borderRadius: 18, padding: 16 }, founderBioTitle: { color: "#0B4F9C", fontSize: 17, fontWeight: "800" }, founderBioName: { color: "#102A43", fontSize: 16, fontWeight: "800", marginTop: 7 }, founderBioSummary: { color: "#587186", fontSize: 13, lineHeight: 20, marginTop: 5 }, founderBioAction: { color: "#0B4F9C", fontWeight: "800", fontSize: 14, marginTop: 12 }, founderBioText: { color: "#24435F", fontSize: 14, lineHeight: 22, marginTop: 13 }, flex: { flex: 1 }, tabs: { height: 66, backgroundColor: "#FFF", borderTopWidth: StyleSheet.hairlineWidth, borderColor: "#CEDDEA", flexDirection: "row", justifyContent: "space-around", paddingTop: 8 }, tab: { alignItems: "center", minWidth: 62, gap: 3 }, tabText: { color: "#7890A8", fontSize: 11 }, tabActive: { color: "#0B4F9C", fontWeight: "800" }, conversationHeader: { padding: 13, backgroundColor: "#FFF", flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: "#D4E1ED" }, localBanner: { marginHorizontal: 16, marginTop: 10, padding: 8, borderRadius: 10, backgroundColor: "#DFECF8", color: "#486B8C", fontSize: 12 }, messageList: { padding: 15, gap: 7, paddingBottom: 12 }, messageRow: { flexDirection: "row" }, mineRow: { justifyContent: "flex-end" }, otherRow: { justifyContent: "flex-start" }, bubble: { maxWidth: "82%", padding: 11, borderRadius: 17 }, mineBubble: { backgroundColor: "#0B4F9C", borderBottomRightRadius: 5 }, otherBubble: { backgroundColor: "#FFF", borderBottomLeftRadius: 5 }, messageText: { color: "#102A43", fontSize: 15, lineHeight: 21 }, mineText: { color: "#FFF" }, messageMeta: { color: "#55728D", fontSize: 10, marginTop: 7 }, imageMessage: { width: 190, height: 150, borderRadius: 11, backgroundColor: "#D5E6F6" }, saveHint: { color: "#0B4F9C", fontWeight: "700", fontSize: 12, marginTop: 7 }, fileBubble: { flexDirection: "row", alignItems: "center", gap: 9, minWidth: 185 }, fileName: { flex: 1, color: "#102A43", fontWeight: "700" }, voiceBubble: { flexDirection: "row", alignItems: "center", gap: 9, minWidth: 190 }, play: { width: 33, height: 33, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "#0B4F9C" }, wave: { flex: 1, height: 3, borderRadius: 2, backgroundColor: "#6E9DC9" }, voiceLength: { color: "#102A43", fontSize: 12 }, composer: { flexDirection: "row", gap: 7, alignItems: "flex-end", padding: 10, backgroundColor: "#FFF", borderTopWidth: StyleSheet.hairlineWidth, borderColor: "#D4E1ED" }, composerButton: { height: 42, width: 34, alignItems: "center", justifyContent: "center" }, composerInput: { flex: 1, minHeight: 42, maxHeight: 95, backgroundColor: "#EDF3F9", borderRadius: 21, paddingHorizontal: 14, paddingVertical: 10, color: "#102A43", fontSize: 15 }, send: { width: 43, height: 43, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: "#0B4F9C" }, mic: { width: 43, height: 43, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: "#167B65" }, recordBar: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, backgroundColor: "#FFF", borderTopWidth: StyleSheet.hairlineWidth, borderColor: "#D4E1ED" }, recordDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: "#C93636" }, recordText: { color: "#102A43", fontWeight: "800" }, smallSend: { width: 37, height: 37, backgroundColor: "#0B4F9C", alignItems: "center", justifyContent: "center", borderRadius: 19 }, backdrop: { flex: 1, backgroundColor: "rgba(16,42,67,0.42)", justifyContent: "flex-end" }, sheet: { backgroundColor: "#FFF", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 32 }, handle: { alignSelf: "center", width: 38, height: 4, borderRadius: 3, backgroundColor: "#C2D0DE", marginBottom: 15 }, sheetTitle: { color: "#102A43", fontSize: 18, fontWeight: "800", marginBottom: 16 }, attachmentGrid: { flexDirection: "row", justifyContent: "space-between" }, attachAction: { width: "23%", alignItems: "center", gap: 7, paddingVertical: 9 }, attachText: { color: "#102A43", fontSize: 12, fontWeight: "700" }, dialog: { backgroundColor: "#FFF", marginHorizontal: 22, marginBottom: "45%", borderRadius: 19, padding: 19 }, languageRow: { minHeight: 47, flexDirection: "row", gap: 11, alignItems: "center", justifyContent: "space-between", borderBottomWidth: StyleSheet.hairlineWidth, borderColor: "#D9E4EE" }, undo: { position: "absolute", bottom: 78, left: 18, right: 18, backgroundColor: "#102A43", borderRadius: 13, paddingVertical: 11, paddingHorizontal: 14, flexDirection: "row", justifyContent: "space-between" }, undoText: { color: "#FFF", fontWeight: "800" }, undoHint: { color: "#B9D9F7", fontSize: 12 }, toast: { position: "absolute", top: 10, alignSelf: "center", backgroundColor: "#173954", borderRadius: 18, paddingVertical: 9, paddingHorizontal: 15 }, toastText: { color: "#FFF", fontSize: 13 },
});
