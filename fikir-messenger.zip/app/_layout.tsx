import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import { Platform } from "react-native";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import {
  SafeAreaFrameContext,
  SafeAreaInsetsContext,
  SafeAreaProvider,
  initialWindowMetrics,
} from "react-native-safe-area-context";
import type { EdgeInsets, Metrics, Rect } from "react-native-safe-area-context";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { initManusRuntime, subscribeSafeAreaInsets } from "@/lib/_core/manus-runtime";
import "@/lib/livekit-register";
import { useAuth } from "@/hooks/use-auth";
import { requestPushNavigation, type PushDestination } from "@/lib/push-navigation";
import { configureAndroidNotificationChannels, getNotificationSettings } from "@/lib/notification-settings";

if (Platform.OS !== "web") {
  Notifications.setNotificationHandler({
    handleNotification: async () => {
      const settings = await getNotificationSettings();
      return {
        // Android channel settings decide native sound; keeping this true preserves a foreground banner.
        shouldPlaySound: Platform.OS === "android" ? true : settings.soundEnabled,
        shouldSetBadge: false,
        shouldShowBanner: true,
        shouldShowList: true,
      };
    },
  });
}

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };

export const unstable_settings = {
  anchor: "(tabs)",
};

function readPushDestination(notification: Notifications.Notification, actionIdentifier?: string): PushDestination | null {
  const data = notification.request.content.data;
  const type = data?.type;
  if (type === "dm" && typeof data.peerId === "number" && Number.isInteger(data.peerId) && data.peerId > 0) {
    return { type, peerId: data.peerId };
  }
  if (type === "group" && typeof data.groupId === "number" && Number.isInteger(data.groupId) && data.groupId > 0) {
    return { type, groupId: data.groupId };
  }
  if (type === "call" && typeof data.sessionId === "number" && Number.isInteger(data.sessionId) && data.sessionId > 0) {
    const action = actionIdentifier === "accept_call" ? "accept" : actionIdentifier === "decline_call" ? "decline" : "open";
    return { type, sessionId: data.sessionId, action };
  }
  if (type === "founder-update" && typeof data.updateId === "number" && Number.isInteger(data.updateId) && data.updateId > 0) {
    return { type, updateId: data.updateId };
  }
  return type === "announcement" ? { type } : null;
}

/** Registers the current native device only after its Gmail-backed session is available. */
function PushNotificationRegistrar() {
  const { user } = useAuth();
  const { mutateAsync: registerPushToken } = trpc.notifications.registerPushToken.useMutation();
  const registeredDevice = useRef<string | null>(null);

  useEffect(() => {
    if (Platform.OS === "web" || !user) return;

    let cancelled = false;
    const registerDevice = async () => {
      try {
        if (Platform.OS === "android") {
          await configureAndroidNotificationChannels(await getNotificationSettings());
        }

        await Notifications.setNotificationCategoryAsync("incoming_call", [
          { identifier: "accept_call", buttonTitle: "গ্রহণ", options: { opensAppToForeground: true } },
          { identifier: "decline_call", buttonTitle: "প্রত্যাখ্যান", options: { opensAppToForeground: true, isDestructive: true } },
        ]);

        const existing = await Notifications.getPermissionsAsync();
        const permission = existing.status === "granted" ? existing : await Notifications.requestPermissionsAsync();
        if (permission.status !== "granted") {
          console.info("[Push] Notification permission was not granted.");
          return;
        }

        const projectId = Constants.easConfig?.projectId ?? Constants.expoConfig?.extra?.eas?.projectId;
        if (!projectId) {
          console.warn("[Push] EAS project ID is unavailable; device token registration was skipped.");
          return;
        }
        const response = await Notifications.getExpoPushTokenAsync({ projectId });
        const token = response.data.trim();
        const registrationKey = `${user.id}:${token}`;
        if (cancelled || !token || registeredDevice.current === registrationKey) return;

        await registerPushToken({
          token,
          platform: Platform.OS === "ios" ? "ios" : "android",
        });
        if (!cancelled) registeredDevice.current = registrationKey;
      } catch (error) {
        // The messenger remains usable if a device's Push service is temporarily unavailable.
        console.warn("[Push] Token registration failed:", error);
      }
    };

    void registerDevice();
    return () => {
      cancelled = true;
    };
  }, [registerPushToken, user]);

  return null;
}

/** Handles a notification interaction whether the app was closed or already open. */
function PushNotificationObserver() {
  useEffect(() => {
    if (Platform.OS === "web") return;
    const handleResponse = (response: Notifications.NotificationResponse | null) => {
      if (!response) return;
      const destination = readPushDestination(response.notification, response.actionIdentifier);
      if (destination) requestPushNavigation(destination);
    };
    handleResponse(Notifications.getLastNotificationResponse());
    const subscription = Notifications.addNotificationResponseReceivedListener(handleResponse);
    return () => subscription.remove();
  }, []);

  return null;
}

export default function RootLayout() {
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;

  const [insets, setInsets] = useState<EdgeInsets>(initialInsets);
  const [frame, setFrame] = useState<Rect>(initialFrame);

  // Initialize Manus runtime for cookie injection from parent container
  useEffect(() => {
    initManusRuntime();
  }, []);

  const handleSafeAreaUpdate = useCallback((metrics: Metrics) => {
    setInsets(metrics.insets);
    setFrame(metrics.frame);
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web") return;
    const unsubscribe = subscribeSafeAreaInsets(handleSafeAreaUpdate);
    return () => unsubscribe();
  }, [handleSafeAreaUpdate]);

  // Create clients once and reuse them
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Disable automatic refetching on window focus for mobile
            refetchOnWindowFocus: false,
            // Retry failed requests once
            retry: 1,
          },
        },
      }),
  );
  const [trpcClient] = useState(() => createTRPCClient());

  // Ensure minimum 8px padding for top and bottom on mobile
  const providerInitialMetrics = useMemo(() => {
    const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame };
    return {
      ...metrics,
      insets: {
        ...metrics.insets,
        top: Math.max(metrics.insets.top, 16),
        bottom: Math.max(metrics.insets.bottom, 12),
      },
    };
  }, [initialInsets, initialFrame]);

  const content = (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          <PushNotificationRegistrar />
          <PushNotificationObserver />
          {/* Default to hiding native headers so raw route segments don't appear (e.g. "(tabs)", "products/[id]"). */}
          {/* If a screen needs the native header, explicitly enable it and set a human title via Stack.Screen options. */}
          {/* in order for ios apps tab switching to work properly, use presentation: "fullScreenModal" for login page, whenever you decide to use presentation: "modal*/}
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="oauth/callback" />
          </Stack>
          <StatusBar style="auto" />
        </QueryClientProvider>
      </trpc.Provider>
    </GestureHandlerRootView>
  );

  const shouldOverrideSafeArea = Platform.OS === "web";

  if (shouldOverrideSafeArea) {
    return (
      <ThemeProvider>
        <SafeAreaProvider initialMetrics={providerInitialMetrics}>
          <SafeAreaFrameContext.Provider value={frame}>
            <SafeAreaInsetsContext.Provider value={insets}>
              {content}
            </SafeAreaInsetsContext.Provider>
          </SafeAreaFrameContext.Provider>
        </SafeAreaProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <SafeAreaProvider initialMetrics={providerInitialMetrics}>{content}</SafeAreaProvider>
    </ThemeProvider>
  );
}
