import { AccessToken } from "livekit-server-sdk";
import type { CallSession, User } from "../drizzle/schema";
import { ENV } from "./_core/env";

type CallRoomSession = Pick<CallSession, "id" | "groupId">;
type TokenUser = Pick<User, "id" | "name" | "username" | "avatarUrl">;

function getLiveKitServerConfig() {
  const url = ENV.livekitUrl.trim().replace(/\/+$/, "");
  const apiKey = ENV.livekitApiKey.trim();
  const apiSecret = ENV.livekitApiSecret.trim();

  if (!url || !apiKey || !apiSecret) {
    throw new Error("LiveKit server credentials are not configured");
  }
  if (!/^wss:\/\/[a-z0-9.-]+\.livekit\.cloud$/i.test(url)) {
    throw new Error("LiveKit URL must be a secure LiveKit Cloud WebSocket URL");
  }

  return { url, apiKey, apiSecret };
}

export function getLiveKitRoomName(session: CallRoomSession) {
  const kind = session.groupId ? "group" : "direct";
  return `fikir-${kind}-call-${session.id}`;
}

/** Creates a short-lived credential only after the router has verified call membership. */
export async function issueLiveKitCallToken(session: CallRoomSession, user: TokenUser) {
  const { url, apiKey, apiSecret } = getLiveKitServerConfig();
  const roomName = getLiveKitRoomName(session);
  const token = new AccessToken(apiKey, apiSecret, {
    identity: `fikir-user-${user.id}`,
    name: user.username || user.name || `Fikir user ${user.id}`,
    metadata: JSON.stringify({
      userId: user.id,
      avatarUrl: user.avatarUrl ?? null,
    }),
    ttl: "10m",
  });

  token.addGrant({
    roomJoin: true,
    room: roomName,
    canPublish: true,
    canSubscribe: true,
    canPublishData: true,
  });

  return {
    token: await token.toJwt(),
    url,
    roomName,
  };
}
