import { TRPCError } from "@trpc/server";
import { normalizeExpoPushTokens } from "../../lib/push-notifications";
import { ENV } from "./env";

export type NotificationPayload = {
  title: string;
  content: string;
};

export type ExpoPushPayload = {
  title: string;
  body: string;
  data: Record<string, string | number | boolean>;
  channelId?: "messages" | "audio-calls" | "video-calls";
  categoryId?: "incoming_call";
  priority?: "default" | "normal" | "high";
  ttl?: number;
  sound?: "message_alert.wav" | "audio_call_ring.wav" | "video_call_ring.wav";
};

const TITLE_MAX_LENGTH = 1200;
const CONTENT_MAX_LENGTH = 20000;
const EXPO_PUSH_ENDPOINT = "https://exp.host/--/api/v2/push/send";
const EXPO_PUSH_BATCH_SIZE = 100;

const trimValue = (value: string): string => value.trim();
const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;

const buildEndpointUrl = (baseUrl: string): string => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL("webdevtoken.v1.WebDevService/SendNotification", normalizedBase).toString();
};

const validatePayload = (input: NotificationPayload): NotificationPayload => {
  if (!isNonEmptyString(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required.",
    });
  }
  if (!isNonEmptyString(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required.",
    });
  }

  const title = trimValue(input.title);
  const content = trimValue(input.content);

  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`,
    });
  }

  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`,
    });
  }

  return { title, content };
};

/**
 * Dispatches a project-owner notification through the Manus Notification Service.
 * Returns `true` if the request was accepted, `false` when the upstream service
 * cannot be reached (callers can fall back to email/slack). Validation errors
 * bubble up as TRPC errors so callers can fix the payload.
 */
export async function notifyOwner(payload: NotificationPayload): Promise<boolean> {
  const { title, content } = validatePayload(payload);

  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured.",
    });
  }

  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured.",
    });
  }

  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1",
      },
      body: JSON.stringify({ title, content }),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${
          detail ? `: ${detail}` : ""
        }`,
      );
      return false;
    }

    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

/**
 * Sends a notification to the supplied Expo device tokens. The Expo Push Service
 * accepts a maximum of one hundred notifications per request, so tokens are
 * de-duplicated and chunked. Any delivery failure is logged and reported to the
 * caller without interrupting the underlying chat or announcement operation.
 */
export async function sendExpoPushNotifications(tokens: string[], payload: ExpoPushPayload): Promise<boolean> {
  const title = payload.title.trim().slice(0, 120);
  const body = payload.body.trim().slice(0, 500);
  if (!title || !body) {
    console.warn("[Push] Ignored a notification without a title or body.");
    return false;
  }

  const uniqueTokens = normalizeExpoPushTokens(tokens);
  if (uniqueTokens.length === 0) return true;

  const batches = Array.from({ length: Math.ceil(uniqueTokens.length / EXPO_PUSH_BATCH_SIZE) }, (_, index) =>
    uniqueTokens.slice(index * EXPO_PUSH_BATCH_SIZE, (index + 1) * EXPO_PUSH_BATCH_SIZE),
  );

  try {
    const responses = await Promise.all(batches.map(async (batch) => {
      const response = await fetch(EXPO_PUSH_ENDPOINT, {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
        },
        body: JSON.stringify(batch.map((to) => ({
          to,
          sound: payload.sound ?? "message_alert.wav",
          title,
          body,
          data: payload.data,
          channelId: payload.channelId ?? "messages",
          categoryId: payload.categoryId,
          priority: payload.priority ?? "high",
          ttl: payload.ttl,
        }))),
      });
      if (!response.ok) {
        const detail = await response.text().catch(() => "");
        console.warn(`[Push] Expo Push Service rejected a batch (${response.status})${detail ? `: ${detail}` : ""}`);
        return false;
      }
      return true;
    }));
    return responses.every(Boolean);
  } catch (error) {
    console.warn("[Push] Expo Push Service request failed:", error);
    return false;
  }
}
