import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getGroupCallRecipientIds, getIncomingCallPushOptions } from "./call-notification";
import { COOKIE_NAME } from "../shared/const.js";
import * as db from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { sendExpoPushNotifications } from "./_core/notification";
import { issueLiveKitCallToken } from "./livekit";
import { storagePut } from "./storage";
import { isExpoPushToken } from "../lib/push-notifications";
import { canFounderBanUser, hasFounderUpdateContent } from "./admin-rules";

const usernameSchema = z.string().trim().min(3, "ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে").max(32).regex(/^[a-z0-9._]+$/i, "ইউজারনেমে শুধু ইংরেজি অক্ষর, সংখ্যা, ডট ও আন্ডারস্কোর ব্যবহার করুন");
const groupRoleSchema = z.enum(["owner", "admin", "moderator", "member"]);
const groupStateSchema = z.enum(["active", "pending", "invited", "removed"]);
const expoPushTokenSchema = z.string().trim().max(255).refine(isExpoPushToken, "বৈধ Expo Push Token দিন।");
const founderUpdateImageSchema = z.object({
  base64: z.string().min(16).max(5_500_000),
  contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
});
const founderUpdateVoiceContentTypeSchema = z.enum(["audio/mp4", "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm"]);
const founderUpdateVoiceSchema = z.object({
  base64: z.string().min(16).max(5_500_000),
  contentType: founderUpdateVoiceContentTypeSchema,
  durationSeconds: z.number().finite().min(0).max(7_200),
});
/** Founder updates are broadcast-only: every viewer may only toggle one like reaction. */
const founderUpdateReactionEmojiSchema = z.literal("👍");
const chatAttachmentContentTypeSchema = z.enum([
  "image/jpeg",
  "image/png",
  "image/webp",
  "audio/mp4",
  "audio/mpeg",
  "audio/wav",
  "audio/ogg",
  "audio/webm",
  "application/pdf",
  "text/plain",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/zip",
  "application/octet-stream",
]);
const chatAttachmentSchema = z.object({
  base64: z.string().min(16).max(5_500_000),
  contentType: chatAttachmentContentTypeSchema,
  filename: z.string().trim().min(1).max(160),
});

function chatAttachmentExtension(contentType: z.infer<typeof chatAttachmentContentTypeSchema>) {
  const extensions: Record<z.infer<typeof chatAttachmentContentTypeSchema>, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "audio/mp4": "m4a",
    "audio/mpeg": "mp3",
    "audio/wav": "wav",
    "audio/ogg": "ogg",
    "audio/webm": "webm",
    "application/pdf": "pdf",
    "text/plain": "txt",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.ms-excel": "xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/zip": "zip",
    "application/octet-stream": "bin",
  };
  return extensions[contentType];
}

async function storeChatAttachment(userId: number, attachment: z.infer<typeof chatAttachmentSchema>, req: { get(name: string): string | undefined; protocol: string }) {
  const base64 = attachment.base64.replace(/^data:[^;]+;base64,/, "");
  const bytes = Buffer.from(base64, "base64");
  if (bytes.length === 0 || bytes.length > 4 * 1024 * 1024) {
    throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "ছবি, ফাইল বা ভয়েস বার্তার আকার ৪ মেগাবাইটের মধ্যে রাখুন।" });
  }
  const cleanedFilename = attachment.filename
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .replace(/^\.+/, "")
    .slice(0, 100) || `attachment.${chatAttachmentExtension(attachment.contentType)}`;
  const filename = cleanedFilename.includes(".") ? cleanedFilename : `${cleanedFilename}.${chatAttachmentExtension(attachment.contentType)}`;
  const stored = await storagePut(`chat-attachments/${userId}/${Date.now()}-${filename}`, bytes, attachment.contentType);
  const forwardedProtocol = req.get("x-forwarded-proto")?.split(",")[0] || req.protocol || "https";
  const forwardedHost = req.get("x-forwarded-host") || req.get("host");
  return {
    url: forwardedHost ? `${forwardedProtocol}://${forwardedHost}${stored.url}` : stored.url,
    filename: attachment.filename,
    contentType: attachment.contentType,
  };
}

async function storeFounderUpdateImages(userId: number, images: Array<z.infer<typeof founderUpdateImageSchema>>, req: { get(name: string): string | undefined; protocol: string }) {
  if (images.length > 4) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "একটি আপডেটে সর্বোচ্চ ৪টি ছবি যুক্ত করা যাবে।" });
  const forwardedProtocol = req.get("x-forwarded-proto")?.split(",")[0] || req.protocol || "https";
  const forwardedHost = req.get("x-forwarded-host") || req.get("host");
  const uploaded: string[] = [];
  for (const [index, image] of images.entries()) {
    const bytes = Buffer.from(image.base64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, ""), "base64");
    if (bytes.length === 0 || bytes.length > 4 * 1024 * 1024) {
      throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "প্রতিটি ছবির আকার ৪ মেগাবাইটের মধ্যে রাখুন।" });
    }
    const extension = image.contentType === "image/png" ? "png" : image.contentType === "image/webp" ? "webp" : "jpg";
    const stored = await storagePut(`founder-updates/${userId}/${Date.now()}-${index}.${extension}`, bytes, image.contentType);
    uploaded.push(forwardedHost ? `${forwardedProtocol}://${forwardedHost}${stored.url}` : stored.url);
  }
  return uploaded;
}

function founderUpdateVoiceExtension(contentType: z.infer<typeof founderUpdateVoiceContentTypeSchema>) {
  return ({ "audio/mp4": "m4a", "audio/mpeg": "mp3", "audio/wav": "wav", "audio/ogg": "ogg", "audio/webm": "webm" } as const)[contentType];
}

async function storeFounderUpdateVoice(userId: number, voice: z.infer<typeof founderUpdateVoiceSchema>, req: { get(name: string): string | undefined; protocol: string }) {
  const bytes = Buffer.from(voice.base64.replace(/^data:audio\/[a-zA-Z0-9.+-]+;base64,/, ""), "base64");
  if (bytes.length === 0 || bytes.length > 4 * 1024 * 1024) {
    throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "ভয়েস-সংযুক্তির আকার ৪ মেগাবাইটের মধ্যে রাখুন।" });
  }
  const stored = await storagePut(`founder-updates/${userId}/${Date.now()}-voice.${founderUpdateVoiceExtension(voice.contentType)}`, bytes, voice.contentType);
  const forwardedProtocol = req.get("x-forwarded-proto")?.split(",")[0] || req.protocol || "https";
  const forwardedHost = req.get("x-forwarded-host") || req.get("host");
  return forwardedHost ? `${forwardedProtocol}://${forwardedHost}${stored.url}` : stored.url;
}

function requireGmail(email: string | null) {
  if (!db.isGmailEmail(email)) throw new TRPCError({ code: "FORBIDDEN", message: "ফিকির মেসেঞ্জারে শুধু Gmail পরিচয় ব্যবহার করা যায়।" });
}

function requireFounder(role: string) {
  if (role !== "founder") throw new TRPCError({ code: "FORBIDDEN", message: "এই কাজটি শুধু প্রতিষ্ঠাতা-মালিকের জন্য।" });
}

function canManageGroup(role: string | undefined) {
  return role === "owner" || role === "admin";
}

function notificationPreview(body: string, kind: "text" | "image" | "file" | "voice") {
  if (kind === "image") return "একটি ছবি পাঠিয়েছেন";
  if (kind === "file") return "একটি ফাইল পাঠিয়েছেন";
  if (kind === "voice") return "একটি ভয়েস বার্তা পাঠিয়েছেন";
  return body.trim().replace(/\s+/g, " ").slice(0, 160) || "নতুন বার্তা";
}

function queuePushNotification(
  tokens: string[],
  title: string,
  body: string,
  data: Record<string, string | number | boolean>,
  options: Pick<Parameters<typeof sendExpoPushNotifications>[1], "channelId" | "categoryId" | "priority" | "ttl"> = {},
) {
  void sendExpoPushNotifications(tokens, { title, body, data, ...options }).then((sent) => {
    if (!sent) console.warn("[Push] A notification batch was not accepted for delivery.");
  }).catch((error) => {
    console.warn("[Push] Unable to prepare a notification batch:", error);
  });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  profile: router({
    me: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      return ctx.user;
    }),
    usernameAvailable: protectedProcedure.input(z.object({ username: usernameSchema })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return { available: await db.isUsernameAvailable(input.username, ctx.user.id) };
    }),
    update: protectedProcedure.input(z.object({
      name: z.string().trim().min(1).max(100).optional(),
      username: usernameSchema.optional(),
      avatarUrl: z.string().url().nullable().optional(),
      bio: z.string().max(600).nullable().optional(),
    })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      if (input.username && !(await db.isUsernameAvailable(input.username, ctx.user.id))) {
        throw new TRPCError({ code: "CONFLICT", message: "এই ইউজারনেমটি ইতিমধ্যে ব্যবহৃত হচ্ছে।" });
      }
      return db.updateUserProfile(ctx.user.id, input);
    }),
    uploadAvatar: protectedProcedure.input(z.object({
      base64: z.string().min(16).max(5_500_000),
      contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
    })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const bytes = Buffer.from(input.base64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, ""), "base64");
      if (bytes.length === 0 || bytes.length > 4 * 1024 * 1024) {
        throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "প্রোফাইল ছবির আকার ৪ মেগাবাইটের মধ্যে রাখুন।" });
      }
      const extension = input.contentType === "image/png" ? "png" : input.contentType === "image/webp" ? "webp" : "jpg";
      const stored = await storagePut(`avatars/${ctx.user.id}/profile.${extension}`, bytes, input.contentType);
      const forwardedProtocol = ctx.req.get("x-forwarded-proto")?.split(",")[0] || ctx.req.protocol || "https";
      const forwardedHost = ctx.req.get("x-forwarded-host") || ctx.req.get("host");
      const avatarUrl = forwardedHost ? `${forwardedProtocol}://${forwardedHost}${stored.url}` : stored.url;
      return { avatarUrl };
    }),
    search: protectedProcedure.input(z.object({ query: z.string().trim().min(1).max(100) })).query(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.searchProfiles(input.query, ctx.user.id);
    }),
    byId: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const profile = await db.getProfileById(input.userId);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      return profile;
    }),
  }),

  presence: router({
    heartbeat: protectedProcedure.mutation(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.heartbeatPresence(ctx.user.id);
    }),
    offline: protectedProcedure.mutation(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.setPresenceOffline(ctx.user.id);
    }),
    byUsers: protectedProcedure.input(z.object({ userIds: z.array(z.number().int().positive()).min(1).max(100) })).query(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.listPresenceByUserIds(input.userIds);
    }),
  }),

  notifications: router({
    registerPushToken: protectedProcedure.input(z.object({
      token: expoPushTokenSchema,
      platform: z.enum(["android", "ios"]),
    })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.savePushToken(ctx.user.id, input.token, input.platform);
    }),
    unregisterPushToken: protectedProcedure.input(z.object({ token: expoPushTokenSchema })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.removePushToken(ctx.user.id, input.token);
    }),
  }),

  chat: router({
    uploadAttachment: protectedProcedure.input(chatAttachmentSchema).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return storeChatAttachment(ctx.user.id, input, ctx.req);
    }),
  }),

  groups: router({
    mine: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.listMyGroups(ctx.user.id);
    }),
    discover: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.listDiscoverableGroups();
    }),
    detail: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপের চ্যাট খোলার অনুমতি নেই।" });
      const group = await db.getGroupById(input.groupId);
      if (!group) throw new TRPCError({ code: "NOT_FOUND", message: "গ্রুপটি পাওয়া যায়নি।" });
      return group;
    }),
    create: protectedProcedure.input(z.object({
      name: z.string().trim().min(3).max(100),
      handle: usernameSchema.max(40),
      description: z.string().max(1500).optional(),
      imageUrl: z.string().url().nullable().optional(),
      privacy: z.enum(["public", "private", "approval"]),
      isAnnouncementsOnly: z.boolean().default(false),
    })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.createGroup({ ...input, ownerId: ctx.user.id });
    }),
    join: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const group = await db.getGroupById(input.groupId);
      if (!group || group.privacy === "private") throw new TRPCError({ code: "NOT_FOUND", message: "গ্রুপটি পাওয়া যায়নি বা এটি শুধুমাত্র আমন্ত্রণভিত্তিক।" });
      return db.joinOrRequestGroup(group, ctx.user.id);
    }),
    members: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "সদস্যদের তালিকা দেখতে আপনাকে গ্রুপের সক্রিয় সদস্য হতে হবে।" });
      return db.listGroupMembers(input.groupId);
    }),
    settings: protectedProcedure.input(z.object({
      groupId: z.number().int().positive(),
      name: z.string().trim().min(3).max(100).optional(),
      description: z.string().max(1500).nullable().optional(),
      imageUrl: z.string().url().nullable().optional(),
      privacy: z.enum(["public", "private", "approval"]).optional(),
      isAnnouncementsOnly: z.boolean().optional(),
    })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!canManageGroup(membership?.role) || membership?.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "শুধু গ্রুপ মালিক বা অ্যাডমিন সেটিংস সম্পাদনা করতে পারেন।" });
      const { groupId, ...data } = input;
      return db.updateGroup(groupId, data);
    }),
    delete: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (membership?.role !== "owner" || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "শুধু গ্রুপ মালিক গ্রুপটি মুছে ফেলতে পারেন।" });
      await db.deleteGroupForOwner(input.groupId);
      return { success: true };
    }),
    manageMember: protectedProcedure.input(z.object({ groupId: z.number().int().positive(), userId: z.number().int().positive(), role: groupRoleSchema.optional(), state: groupStateSchema.optional() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const actor = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!canManageGroup(actor?.role) || actor?.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "শুধু গ্রুপ মালিক বা অ্যাডমিন সদস্য নিয়ন্ত্রণ করতে পারেন।" });
      const target = await db.getGroupMembership(input.groupId, input.userId);
      if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "সদস্যটি পাওয়া যায়নি।" });
      if (target.role === "owner" && actor.role !== "owner") throw new TRPCError({ code: "FORBIDDEN", message: "শুধু মালিক অন্য মালিকের ভূমিকা পরিবর্তন করতে পারেন।" });
      const { groupId, userId, ...data } = input;
      return db.updateMembership(groupId, userId, data);
    }),
    invite: protectedProcedure.input(z.object({ groupId: z.number().int().positive(), userId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const actor = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!canManageGroup(actor?.role) || actor?.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "শুধু গ্রুপ মালিক বা অ্যাডমিন সদস্য যোগ করতে পারেন।" });
      const [group, target] = await Promise.all([db.getGroupById(input.groupId), db.getUserById(input.userId)]);
      if (!group || !target) throw new TRPCError({ code: "NOT_FOUND", message: "গ্রুপ বা ব্যবহারকারীকে পাওয়া যায়নি।" });
      const membership = await db.inviteGroupMember(input.groupId, input.userId);
      if (input.userId !== ctx.user.id) {
        void (async () => {
          const tokens = await db.getPushTokensForUser(input.userId);
          queuePushNotification(
            tokens.map((entry) => entry.token),
            `${group.name} গ্রুপে যোগ করা হয়েছে`,
            `${ctx.user.name?.trim() || ctx.user.username || "একজন অ্যাডমিন"} আপনাকে গ্রুপের সদস্য করেছেন।`,
            { type: "group", groupId: input.groupId },
          );
        })().catch((error) => console.warn("[Push] Group-invite notification preparation failed:", error));
      }
      return membership;
    }),
  }),

  posts: router({
    feed: protectedProcedure.input(z.object({ groupId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.listFeed(input?.groupId, ctx.user.id);
    }),
    create: protectedProcedure.input(z.object({
      body: z.string().trim().max(5000).default(""),
      imageUrls: z.array(z.string().url()).max(4).default([]),
      voiceUrl: z.string().url().nullable().optional(),
      voiceDurationSeconds: z.number().finite().min(0).max(7200).nullable().optional(),
      linkUrl: z.string().url().nullable().optional(),
      groupId: z.number().int().positive().nullable().optional(),
      visibility: z.enum(["profile", "community", "founder"]).default("profile"),
    }).refine((value) => value.body.length > 0 || !!value.linkUrl || value.imageUrls.length > 0 || !!value.voiceUrl, { message: "লেখা, ছবি, ভয়েস বা একটি লিংক দিন।" })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      if (input.visibility === "founder") requireFounder(ctx.user.role);
      if (input.groupId) {
        const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
        const group = await db.getGroupById(input.groupId);
        if (!group || !membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপে পোস্ট করার অনুমতি নেই।" });
        if (group.isAnnouncementsOnly && !canManageGroup(membership.role)) throw new TRPCError({ code: "FORBIDDEN", message: "এটি শুধু অ্যাডমিনের ঘোষণা দেওয়ার গ্রুপ।" });
      }
      const postId = await db.createPost({ ...input, authorId: ctx.user.id, groupId: input.groupId ?? null });
      return { id: postId };
    }),
    edit: protectedProcedure.input(z.object({ postId: z.number().int().positive(), body: z.string().trim().max(5000).default(""), linkUrl: z.string().url().nullable().optional() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      if (!input.body.trim() && !input.linkUrl) throw new TRPCError({ code: "BAD_REQUEST", message: "লেখা বা লিংক রাখুন।" });
      return db.updatePost(input.postId, ctx.user.id, input);
    }),
    delete: protectedProcedure.input(z.object({ postId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.deletePost(input.postId, ctx.user.id);
    }),
    react: protectedProcedure.input(z.object({ postId: z.number().int().positive(), emoji: z.enum(["👍", "❤️", "👎"]) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.togglePostReaction(input.postId, ctx.user.id, input.emoji);
    }),
    follow: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.toggleFollow(ctx.user.id, input.userId);
    }),
    following: protectedProcedure.query(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.listFollowingIds(ctx.user.id);
    }),
  }),

  activity: router({
    set: protectedProcedure.input(z.object({ recipientId: z.number().int().positive().nullable().optional(), groupId: z.number().int().positive().nullable().optional(), activity: z.enum(["typing", "uploading_image", "uploading_file", "recording_voice"]) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.setChatActivity({ ...input, actorId: ctx.user.id });
    }),
    clear: protectedProcedure.input(z.object({ recipientId: z.number().int().positive().nullable().optional(), groupId: z.number().int().positive().nullable().optional() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.clearChatActivity({ ...input, actorId: ctx.user.id });
    }),
    incoming: protectedProcedure.input(z.object({ actorId: z.number().int().positive(), groupId: z.number().int().positive().nullable().optional() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.listChatActivities({ actorId: input.actorId, recipientId: ctx.user.id, groupId: input.groupId });
    }),
  }),

  messages: router({
    recent: protectedProcedure.query(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.getRecentConversations(ctx.user.id);
    }),
    direct: protectedProcedure.input(z.object({ peerId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const peer = await db.getUserById(input.peerId);
      if (!peer) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      await db.markDirectMessagesSeen(ctx.user.id, input.peerId);
      return db.listDirectMessages(ctx.user.id, input.peerId);
    }),
    sendDirect: protectedProcedure.input(z.object({
      recipientId: z.number().int().positive(),
      body: z.string().trim().max(5000).default(""),
      kind: z.enum(["text", "image", "file", "voice"]).default("text"),
      attachmentUrl: z.string().url().nullable().optional(),
    }).refine((value) => value.body.length > 0 || !!value.attachmentUrl, { message: "বার্তা বা সংযুক্তি দিন।" })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const recipient = await db.getUserById(input.recipientId);
      if (!recipient) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      if (await db.isDirectMessagingBlocked(ctx.user.id, input.recipientId)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "এই ব্যবহারকারীর সঙ্গে বর্তমানে ব্যক্তিগত বার্তা আদান-প্রদান করা যাবে না।" });
      }
      const id = await db.createMessage({ senderId: ctx.user.id, recipientId: input.recipientId, body: input.body, kind: input.kind, attachmentUrl: input.attachmentUrl ?? null });
      void (async () => {
        const tokens = await db.getPushTokensForUser(input.recipientId);
        queuePushNotification(
          tokens.map((entry) => entry.token),
          ctx.user.name?.trim() || ctx.user.username || "ফিকির মেসেঞ্জার",
          notificationPreview(input.body, input.kind),
          { type: "dm", peerId: ctx.user.id },
        );
      })().catch((error) => console.warn("[Push] Direct-message notification preparation failed:", error));
      return { id };
    }),
    group: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপের বার্তা দেখতে আপনাকে সক্রিয় সদস্য হতে হবে।" });
      await db.markGroupMessagesSeen(input.groupId, ctx.user.id);
      const [groupMessages, receiptSummaries] = await Promise.all([
        db.listGroupMessages(input.groupId),
        db.listGroupMessageReceiptSummaries(input.groupId, ctx.user.id),
      ]);
      return groupMessages.map((row) => ({
        ...row,
        receipt: receiptSummaries.get(row.message.id) ?? null,
      }));
    }),
    sendGroup: protectedProcedure.input(z.object({
      groupId: z.number().int().positive(),
      body: z.string().trim().max(5000).default(""),
      kind: z.enum(["text", "image", "file", "voice"]).default("text"),
      attachmentUrl: z.string().url().nullable().optional(),
    }).refine((value) => value.body.length > 0 || !!value.attachmentUrl, { message: "বার্তা বা সংযুক্তি দিন।" })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      const group = await db.getGroupById(input.groupId);
      if (!group || !membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপে বার্তা পাঠানোর অনুমতি নেই।" });
      if (group.isAnnouncementsOnly && !canManageGroup(membership.role)) throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপে শুধু অ্যাডমিন বার্তা পাঠাতে পারেন।" });
      const id = await db.createMessage({ senderId: ctx.user.id, groupId: input.groupId, body: input.body, kind: input.kind, attachmentUrl: input.attachmentUrl ?? null });
      void (async () => {
        const members = await db.listGroupMembers(input.groupId);
        const recipientIds = members
          .filter((member) => member.membership.state === "active" && member.user.id !== ctx.user.id)
          .map((member) => member.user.id);
        const tokens = await db.getPushTokensForUsers(recipientIds);
        queuePushNotification(
          tokens.map((entry) => entry.token),
          `${group.name} · ${ctx.user.name?.trim() || ctx.user.username || "নতুন বার্তা"}`,
          notificationPreview(input.body, input.kind),
          { type: "group", groupId: input.groupId },
        );
      })().catch((error) => console.warn("[Push] Group-message notification preparation failed:", error));
      return { id };
    }),
    edit: protectedProcedure.input(z.object({ messageId: z.number().int().positive(), body: z.string().trim().min(1).max(5000) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.editMessageForSender(input.messageId, ctx.user.id, input.body);
    }),
    delete: protectedProcedure.input(z.object({ messageId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.deleteMessageForSender(input.messageId, ctx.user.id);
    }),
    clearDirect: protectedProcedure.input(z.object({ peerId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const peer = await db.getUserById(input.peerId);
      if (!peer) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      if (await db.isDirectMessagingBlocked(ctx.user.id, input.peerId)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "এই কথোপকথন এখন পরিষ্কার করা যাবে না।" });
      }
      return db.clearDirectMessages(ctx.user.id, input.peerId);
    }),
  }),

  offline: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.getOfflineInboxSummary(ctx.user.id);
    }),
    chatBadges: protectedProcedure.query(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.getUnreadChatBadgeCounts(ctx.user.id);
    }),
    listMissedCalls: protectedProcedure.query(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.listMissedCallsForRecipient(ctx.user.id);
    }),
    markMissedCallsSeen: protectedProcedure.mutation(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.markMissedCallsSeen(ctx.user.id);
    }),
    deleteMissedCall: protectedProcedure.input(z.object({ callId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.deleteMissedCallForRecipient(input.callId, ctx.user.id);
    }),
    clearMissedCallHistory: protectedProcedure.mutation(async ({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.clearMissedCallHistoryForRecipient(ctx.user.id);
    }),
  }),

  calls: router({
    mine: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.listDirectCallSessions(ctx.user.id);
    }),
    deleteHistoryEntry: protectedProcedure.input(z.object({ sessionId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.deleteDirectCallHistoryEntry(input.sessionId, ctx.user.id);
    }),
    clearHistory: protectedProcedure.mutation(({ ctx }) => {
      requireGmail(ctx.user.email);
      return db.clearDirectCallHistory(ctx.user.id);
    }),
    group: protectedProcedure.input(z.object({ groupId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপের কল-সেশন দেখতে আপনাকে সক্রিয় সদস্য হতে হবে।" });
      return db.listGroupCallSessions(input.groupId);
    }),
    byId: protectedProcedure.input(z.object({ sessionId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const session = await db.getCallSessionById(input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND", message: "কল-সেশনটি পাওয়া যায়নি।" });
      if (session.groupId) {
        const membership = await db.getGroupMembership(session.groupId, ctx.user.id);
        if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপ কলে যোগ দেওয়ার অনুমতি নেই।" });
      } else if (session.initiatorId !== ctx.user.id && session.recipientId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "এই ব্যক্তিগত কল-সেশন দেখার অনুমতি নেই।" });
      }
      return session;
    }),
    startDirect: protectedProcedure.input(z.object({ recipientId: z.number().int().positive(), kind: z.enum(["audio", "video"]) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const recipient = await db.getUserById(input.recipientId);
      if (!recipient) throw new TRPCError({ code: "NOT_FOUND", message: "কলের প্রাপককে পাওয়া যায়নি।" });
      if (await db.isDirectMessagingBlocked(ctx.user.id, input.recipientId)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "এই ব্যবহারকারীর সঙ্গে বর্তমানে কল করা যাবে না।" });
      }
      const id = await db.createCallSession({ initiatorId: ctx.user.id, recipientId: input.recipientId, kind: input.kind });
      void (async () => {
        const tokens = await db.getPushTokensForUser(input.recipientId);
        queuePushNotification(
          tokens.map((entry) => entry.token),
          `${ctx.user.name?.trim() || ctx.user.username || "ফিকির ব্যবহারকারী"} কল করছেন`,
          input.kind === "video" ? "ভিডিও কল গ্রহণ বা প্রত্যাখ্যান করুন।" : "অডিও কল গ্রহণ বা প্রত্যাখ্যান করুন।",
          { type: "call", sessionId: id },
          getIncomingCallPushOptions(input.kind),
        );
      })().catch((error) => console.warn("[Push] Call notification preparation failed:", error));
      return { id };
    }),
    startGroup: protectedProcedure.input(z.object({ groupId: z.number().int().positive(), kind: z.enum(["audio", "video"]) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const membership = await db.getGroupMembership(input.groupId, ctx.user.id);
      if (!membership || membership.state !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপে কল শুরু করতে আপনাকে সক্রিয় সদস্য হতে হবে।" });
      const id = await db.createCallSession({ initiatorId: ctx.user.id, groupId: input.groupId, kind: input.kind, status: "active" });
      void (async () => {
        const members = await db.listGroupMembers(input.groupId);
        const recipientIds = getGroupCallRecipientIds(members, ctx.user.id);
        const tokens = await db.getPushTokensForUsers(recipientIds);
        queuePushNotification(
          tokens.map((entry) => entry.token),
          `${ctx.user.name?.trim() || ctx.user.username || "ফিকির ব্যবহারকারী"} গ্রুপ কল শুরু করেছেন`,
          input.kind === "video" ? "ভিডিও গ্রুপ কলে যোগ দিন।" : "অডিও গ্রুপ কলে যোগ দিন।",
          { type: "call", sessionId: id },
          getIncomingCallPushOptions(input.kind),
        );
      })().catch((error) => console.warn("[Push] Group-call notification preparation failed:", error));
      return { id };
    }),
    respondDirect: protectedProcedure.input(z.object({ sessionId: z.number().int().positive(), status: z.enum(["active", "declined"]) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.respondToDirectCall(input.sessionId, ctx.user.id, input.status);
    }),
    end: protectedProcedure.input(z.object({ sessionId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.endCallSession(input.sessionId, ctx.user.id);
    }),
    getLivekitToken: protectedProcedure.input(z.object({ sessionId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      const session = await db.getCallSessionById(input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND", message: "কল-সেশনটি পাওয়া যায়নি।" });
      if (session.status !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "এই কলটি এখন সংযোগের জন্য প্রস্তুত নয়।" });

      if (session.groupId) {
        const membership = await db.getGroupMembership(session.groupId, ctx.user.id);
        if (!membership || membership.state !== "active") {
          throw new TRPCError({ code: "FORBIDDEN", message: "এই গ্রুপ কলে যোগ দেওয়ার অনুমতি নেই।" });
        }
      } else if (session.initiatorId !== ctx.user.id && session.recipientId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "এই ব্যক্তিগত কলে যোগ দেওয়ার অনুমতি নেই।" });
      }

      try {
        return await issueLiveKitCallToken(session, ctx.user);
      } catch (error) {
        console.error("[LiveKit] Could not issue call token", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "কল সংযোগ প্রস্তুত করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।" });
      }
    }),
  }),

  founder: router({
    profile: publicProcedure.query(() => ({
      name: "মাওলানা মোহাম্মদ মুহিব্বুল মুরসালীন",
      shortBio: "ফিকির প্ল্যাটফর্মের প্রতিষ্ঠাতা, মালিক ও প্রধান এডমিন।",
      role: "এডমিন ও খাদিম — Fikir Platform",
    })),
    updates: router({
      list: protectedProcedure.query(({ ctx }) => {
        requireGmail(ctx.user.email);
        return db.listFounderUpdates(ctx.user.role === "founder", ctx.user.id);
      }),
      stats: protectedProcedure.query(async ({ ctx }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        return db.getFounderUpdateStats();
      }),
      create: protectedProcedure.input(z.object({
        body: z.string().trim().max(20_000).default(""),
        linkUrl: z.string().url().max(4_000).nullable().optional(),
        images: z.array(founderUpdateImageSchema).max(4).default([]),
        voice: founderUpdateVoiceSchema.nullable().optional(),
        scheduledFor: z.coerce.date().nullable().optional(),
      }).refine((value) => value.body.length > 0 || !!value.linkUrl || value.images.length > 0 || !!value.voice, { message: "লেখা, লিংক, ছবি বা ভয়েস দিন।" })).mutation(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        if (!hasFounderUpdateContent(input.body, input.images.length, input.linkUrl, !!input.voice)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "প্রকাশের জন্য লেখা, ছবি, লিংক বা ভয়েসের অন্তত একটি দিন।" });
        }
        const imageUrls = await storeFounderUpdateImages(ctx.user.id, input.images, ctx.req);
        const voiceUrl = input.voice ? await storeFounderUpdateVoice(ctx.user.id, input.voice, ctx.req) : null;
        return { id: await db.createFounderUpdate({ authorId: ctx.user.id, body: input.body, linkUrl: input.linkUrl ?? null, imageUrls, voiceUrl, voiceDurationSeconds: input.voice?.durationSeconds ?? null, scheduledFor: input.scheduledFor ?? null }) };
      }),
      edit: protectedProcedure.input(z.object({
        updateId: z.number().int().positive(),
        body: z.string().trim().max(20_000).optional(),
        linkUrl: z.string().url().max(4_000).nullable().optional(),
        newImages: z.array(founderUpdateImageSchema).max(4).default([]),
        retainedImageUrls: z.array(z.string().url()).max(4).optional(),
        voice: founderUpdateVoiceSchema.nullable().optional(),
        scheduledFor: z.coerce.date().nullable().optional(),
      })).mutation(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        const current = await db.getFounderUpdateById(input.updateId);
        if (!current || current.update.authorId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "শুধু নিজের খসড়া বা আপডেট সম্পাদনা করা যাবে।" });
        const uploaded = await storeFounderUpdateImages(ctx.user.id, input.newImages, ctx.req);
        const retained = input.retainedImageUrls ?? current.update.imageUrls;
        if (retained.length + uploaded.length > 4) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "একটি আপডেটে সর্বোচ্চ ৪টি ছবি যুক্ত করা যাবে।" });
        const voiceUrl = input.voice === undefined ? undefined : input.voice ? await storeFounderUpdateVoice(ctx.user.id, input.voice, ctx.req) : null;
        const nextBody = input.body ?? current.update.body;
        const nextLink = input.linkUrl === undefined ? current.update.linkUrl : input.linkUrl;
        const hasVoice = voiceUrl === undefined ? !!current.update.voiceUrl : !!voiceUrl;
        if (!hasFounderUpdateContent(nextBody, retained.length + uploaded.length, nextLink, hasVoice)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "লেখা, ছবি, লিংক বা ভয়েসের অন্তত একটি রাখুন।" });
        }
        return db.updateFounderUpdate(input.updateId, ctx.user.id, {
          body: input.body,
          linkUrl: input.linkUrl,
          imageUrls: [...retained, ...uploaded],
          voiceUrl,
          voiceDurationSeconds: input.voice === undefined ? undefined : input.voice?.durationSeconds ?? null,
          scheduledFor: input.scheduledFor,
        });
      }),
      publish: protectedProcedure.input(z.object({ updateId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        const update = await db.publishFounderUpdate(input.updateId, ctx.user.id);
        if (!update || update.update.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "প্রকাশযোগ্য খসড়াটি পাওয়া যায়নি।" });
        void (async () => {
          const tokens = await db.getAllPushTokens(ctx.user.id);
          queuePushNotification(tokens.map((entry) => entry.token), "প্রতিষ্ঠাতার নতুন আপডেট", update.update.body.trim().replace(/\s+/g, " ").slice(0, 180) || "নতুন ছবি বা লিংক প্রকাশ করা হয়েছে", { type: "founder-update", updateId: update.update.id });
        })().catch((error) => console.warn("[Push] Founder-update notification preparation failed:", error));
        return update;
      }),
      delete: protectedProcedure.input(z.object({ updateId: z.number().int().positive() })).mutation(({ ctx, input }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        return db.deleteFounderUpdate(input.updateId, ctx.user.id);
      }),
      react: protectedProcedure.input(z.object({ updateId: z.number().int().positive(), emoji: founderUpdateReactionEmojiSchema })).mutation(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        const update = await db.getFounderUpdateById(input.updateId, ctx.user.id);
        if (!update || update.update.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "প্রকাশিত আপডেটটি পাওয়া যায়নি।" });
        return db.toggleFounderUpdateReaction(input.updateId, ctx.user.id, input.emoji);
      }),
      markViewed: protectedProcedure.input(z.object({ updateId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        const update = await db.getFounderUpdateById(input.updateId, ctx.user.id);
        if (!update || update.update.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "প্রকাশিত আপডেটটি পাওয়া যায়নি।" });
        return db.recordUpdateView(input.updateId, ctx.user.id);
      }),
      reactors: protectedProcedure.input(z.object({ updateId: z.number().int().positive() })).query(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        const update = await db.getFounderUpdateById(input.updateId, ctx.user.id);
        if (!update || update.update.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "প্রকাশিত আপডেটটি পাওয়া যায়নি।" });
        return db.listFounderUpdateReactors(input.updateId);
      }),
      viewers: protectedProcedure.input(z.object({ updateId: z.number().int().positive() })).query(async ({ ctx, input }) => {
        requireGmail(ctx.user.email);
        requireFounder(ctx.user.role);
        const update = await db.getFounderUpdateById(input.updateId, ctx.user.id);
        if (!update || update.update.status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "প্রকাশিত আপডেটটি পাওয়া যায়নি।" });
        return db.getUpdateViewers(input.updateId);
      }),
    }),
    publishUpdate: protectedProcedure.input(z.object({ body: z.string().trim().min(1).max(5000), linkUrl: z.string().url().nullable().optional() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      const id = await db.createFounderUpdate({ authorId: ctx.user.id, body: input.body, linkUrl: input.linkUrl ?? null });
      return db.publishFounderUpdate(id, ctx.user.id);
    }),
  }),

  moderation: router({
    reportUser: protectedProcedure.input(z.object({ reportedUserId: z.number().int().positive(), reason: z.string().trim().min(3).max(2_000) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      if (input.reportedUserId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "নিজের অ্যাকাউন্ট রিপোর্ট করা যাবে না।" });
      if (!(await db.getUserById(input.reportedUserId))) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      return { id: await db.reportUser(ctx.user.id, input.reportedUserId, input.reason) };
    }),
    blockUser: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      if (input.userId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "নিজের অ্যাকাউন্ট ব্লক করা যাবে না।" });
      return db.blockUser(ctx.user.id, input.userId);
    }),
    unblockUser: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      return db.unblockUser(ctx.user.id, input.userId);
    }),
  }),

  admin: router({
    users: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.listAdminUsers();
    }),
    usageStats: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.getAdminUsageStats(ctx.user.id);
    }),
    blockedByMe: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.listBlockedUserIds(ctx.user.id);
    }),
    reports: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.listUserReports();
    }),
    resolveReport: protectedProcedure.input(z.object({ reportId: z.number().int().positive(), status: z.enum(["reviewed", "resolved"]) })).mutation(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.resolveUserReport(input.reportId, ctx.user.id, input.status);
    }),
    banned: protectedProcedure.query(({ ctx }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.listBannedUsers();
    }),
    banUser: protectedProcedure.input(z.object({ userId: z.number().int().positive(), reason: z.string().trim().min(3).max(2_000) })).mutation(async ({ ctx, input }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      const target = await db.getUserById(input.userId);
      if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "ব্যবহারকারীকে পাওয়া যায়নি।" });
      if (!canFounderBanUser({ actorId: ctx.user.id, targetId: target.id, targetRole: target.role, targetEmail: target.email })) {
        throw new TRPCError({ code: "FORBIDDEN", message: "নিজের বা অন্য কোনো প্রতিষ্ঠাতা অ্যাকাউন্ট নিষিদ্ধ করা যাবে না।" });
      }
      return db.banUser(input.userId, ctx.user.id, input.reason);
    }),
    unbanUser: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      requireGmail(ctx.user.email);
      requireFounder(ctx.user.role);
      return db.unbanUser(input.userId);
    }),
  }),
});

export type AppRouter = typeof appRouter;
