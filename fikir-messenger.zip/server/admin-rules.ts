import { isFounderEmail } from "./db";

/** A founder update must contain at least one visible item after it is published. */
export function hasFounderUpdateContent(body: string, imageCount: number, linkUrl?: string | null, hasVoice = false) {
  return body.trim().length > 0 || imageCount > 0 || Boolean(linkUrl?.trim()) || hasVoice;
}

/** Founder identities are protected from founder-issued bans, including self-bans. */
export function canFounderBanUser(input: {
  actorId: number;
  targetId: number;
  targetRole: "user" | "admin" | "founder";
  targetEmail: string | null;
}) {
  if (input.actorId === input.targetId) return false;
  if (input.targetRole === "founder") return false;
  return !isFounderEmail(input.targetEmail);
}
