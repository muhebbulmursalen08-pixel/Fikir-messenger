export type CallNotificationMember = {
  membership: { state: string };
  user: { id: number };
};

/** A short-lived, high-priority native alert is used so stale calls do not ring later. */
export function getIncomingCallPushOptions(kind: "audio" | "video") {
  return {
  channelId: kind === "video" ? "video-calls" as const : "audio-calls" as const,
  categoryId: "incoming_call" as const,
  priority: "high" as const,
  ttl: 60,
  sound: kind === "video" ? "video_call_ring.wav" as const : "audio_call_ring.wav" as const,
  };
}

/** Returns the unique active group members who should receive a call invitation. */
export function getGroupCallRecipientIds(members: CallNotificationMember[], initiatorId: number) {
  return [...new Set(
    members
      .filter((entry) => entry.membership.state === "active" && entry.user.id !== initiatorId)
      .map((entry) => entry.user.id),
  )];
}
