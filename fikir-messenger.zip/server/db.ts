import { and, desc, eq, inArray, isNull, like, lt, ne, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { callSessions, chatActivities, founderUpdateReactions, founderUpdateViewers, founderUpdates, Group, groupMembers, groupMessageReceipts, groups, InsertUser, messages, postReactions, posts, pushTokens, userBans, userBlocks, userFollows, userPresence, userReports, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

/** The founder accounts explicitly approved by the app owner. This list is checked only on the server. */
const founderEmails = new Set([
  "muhebbulmursalenm@gmail.com",
  "muhebbulmursalen2@gmail.com",
  "murchalinmia016@gmail.com",
  "muhebbulmursalen04@gmail.com",
  "muhebbulmursalen05@gmail.com",
  "muhebbulmursalen08@gmail.com",
]);

export const normalizeEmail = (email?: string | null) => email?.trim().toLowerCase() ?? "";
export const normalizeUsername = (username: string) => username.trim().toLowerCase().replace(/^@+/, "");
export const isGmailEmail = (email?: string | null) => /^[a-z0-9._%+-]+@gmail\.com$/i.test(normalizeEmail(email));
export const isFounderEmail = (email?: string | null) => founderEmails.has(normalizeEmail(email));
export const PRESENCE_TIMEOUT_MS = 75_000;

export function isPresenceOnline(lastActiveAt?: Date | null, now = new Date()) {
  return !!lastActiveAt && now.getTime() - lastActiveAt.getTime() <= PRESENCE_TIMEOUT_MS;
}

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "username", "avatarUrl", "bio", "loginMethod"] as const;

    textFields.forEach((field) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = field === "username" && value ? normalizeUsername(value) : value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    });

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }

    const role = isFounderEmail(user.email) ? "founder" : user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : undefined);
    if (role) {
      values.role = role;
      updateSet.role = role;
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result[0];
}

export async function isUsernameAvailable(username: string, exceptUserId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const normalized = normalizeUsername(username);
  const result = await db.select({ id: users.id }).from(users).where(eq(users.username, normalized)).limit(1);
  return result.length === 0 || result[0].id === exceptUserId;
}

export async function updateUserProfile(userId: number, data: { name?: string; username?: string; avatarUrl?: string | null; bio?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const values: Record<string, unknown> = {};
  if (data.name !== undefined) values.name = data.name.trim();
  if (data.username !== undefined) values.username = normalizeUsername(data.username);
  if (data.avatarUrl !== undefined) values.avatarUrl = data.avatarUrl;
  if (data.bio !== undefined) values.bio = data.bio;
  await db.update(users).set(values).where(eq(users.id, userId));
  return getUserById(userId);
}

export async function searchProfiles(query: string, currentUserId: number) {
  const db = await getDb();
  if (!db || !query.trim()) return [];
  const pattern = `%${query.trim()}%`;
  return db.select({ id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, bio: users.bio, role: users.role })
    .from(users)
    .where(and(ne(users.id, currentUserId), or(like(users.username, pattern), like(users.name, pattern))))
    .limit(30);
}

/** Retrieves the shareable profile fields needed to open a direct conversation. */
export async function getProfileById(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const [profile] = await db.select({
    id: users.id,
    name: users.name,
    username: users.username,
    avatarUrl: users.avatarUrl,
    bio: users.bio,
    role: users.role,
  }).from(users).where(eq(users.id, userId)).limit(1);
  return profile ?? null;
}

export async function createGroup(data: { ownerId: number; name: string; handle: string; description?: string; imageUrl?: string | null; privacy: "public" | "private" | "approval"; isAnnouncementsOnly: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(groups).values({ ...data, handle: normalizeUsername(data.handle) });
  const groupId = Number(result[0].insertId);
  await db.insert(groupMembers).values({ groupId, userId: data.ownerId, role: "owner", state: "active" });
  return getGroupById(groupId);
}

export async function getGroupById(groupId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
  return result[0];
}

export async function getGroupMembership(groupId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(groupMembers).where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId))).limit(1);
  return result[0];
}

export async function listMyGroups(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ group: groups, membership: groupMembers })
    .from(groupMembers)
    .innerJoin(groups, eq(groups.id, groupMembers.groupId))
    .where(and(eq(groupMembers.userId, userId), ne(groupMembers.state, "removed")))
    .orderBy(desc(groups.updatedAt));
}

export async function listDiscoverableGroups() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(groups).where(or(eq(groups.privacy, "public"), eq(groups.privacy, "approval"))).orderBy(desc(groups.updatedAt)).limit(50);
}

export async function joinOrRequestGroup(group: Group, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const state = group.privacy === "public" ? "active" : "pending";
  await db.insert(groupMembers).values({ groupId: group.id, userId, role: "member", state }).onDuplicateKeyUpdate({ set: { state } });
  return getGroupMembership(group.id, userId);
}

export async function listGroupMembers(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ membership: groupMembers, user: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, role: users.role } })
    .from(groupMembers)
    .innerJoin(users, eq(users.id, groupMembers.userId))
    .where(eq(groupMembers.groupId, groupId));
}

/** Adds a selected profile to a managed group, reactivating a previously removed invite safely. */
export async function inviteGroupMember(groupId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(groupMembers).values({ groupId, userId, role: "member", state: "active" }).onDuplicateKeyUpdate({
    set: { state: "active" },
  });
  return getGroupMembership(groupId, userId);
}

export async function heartbeatPresence(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = new Date();
  await db.insert(userPresence).values({ userId, isOnline: true, lastActiveAt: now }).onDuplicateKeyUpdate({
    set: { isOnline: true, lastActiveAt: now },
  });
  await db.update(messages).set({ status: "delivered" }).where(and(eq(messages.recipientId, userId), eq(messages.status, "sent")));
  return { isOnline: true, lastActiveAt: now } as const;
}

export async function setPresenceOffline(userId: number) {
  const db = await getDb();
  if (!db) return { success: false } as const;
  await db.update(userPresence).set({ isOnline: false }).where(eq(userPresence.userId, userId));
  return { success: true } as const;
}

export async function listPresenceByUserIds(userIds: number[]) {
  const db = await getDb();
  if (!db || userIds.length === 0) return [];
  const now = new Date();
  const rows = await db.select().from(userPresence).where(inArray(userPresence.userId, userIds));
  const byId = new Map(rows.map((row) => [row.userId, row]));
  return [...new Set(userIds)].map((userId) => {
    const presence = byId.get(userId);
    return {
      userId,
      online: !!presence?.isOnline && isPresenceOnline(presence.lastActiveAt, now),
      lastSeenAt: presence?.lastActiveAt ?? null,
    };
  });
}

/** Stores one Expo Push Token per signed-in device without duplicating repeat registrations. */
export async function savePushToken(userId: number, token: string, platform: "android" | "ios") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(pushTokens).values({ userId, token, platform }).onDuplicateKeyUpdate({
    set: { platform, updatedAt: new Date() },
  });
  return { success: true } as const;
}

/** Returns a user's current device tokens. A user may safely register more than one device. */
export async function getPushTokensForUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pushTokens).where(eq(pushTokens.userId, userId));
}

/** Returns all current device tokens for a de-duplicated group of users. */
export async function getPushTokensForUsers(userIds: number[]) {
  const db = await getDb();
  const uniqueUserIds = [...new Set(userIds)];
  if (!db || uniqueUserIds.length === 0) return [];
  return db.select().from(pushTokens).where(inArray(pushTokens.userId, uniqueUserIds));
}

/** Returns tokens for a broadcast while omitting the account that created it. */
export async function getAllPushTokens(excludingUserId?: number) {
  const db = await getDb();
  if (!db) return [];
  return excludingUserId
    ? db.select().from(pushTokens).where(ne(pushTokens.userId, excludingUserId))
    : db.select().from(pushTokens);
}

/** Allows an authenticated device to remove its own stale or revoked token. */
export async function removePushToken(userId: number, token: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(pushTokens).where(and(eq(pushTokens.userId, userId), eq(pushTokens.token, token)));
  return { success: true } as const;
}

export async function updateGroup(groupId: number, data: Partial<{ name: string; description: string | null; imageUrl: string | null; privacy: "public" | "private" | "approval"; isAnnouncementsOnly: boolean }>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groups).set(data).where(eq(groups.id, groupId));
  return getGroupById(groupId);
}

export async function deleteGroupForOwner(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.transaction(async (tx) => {
    await tx.delete(groupMembers).where(eq(groupMembers.groupId, groupId));
    await tx.delete(messages).where(eq(messages.groupId, groupId));
    await tx.delete(posts).where(eq(posts.groupId, groupId));
    await tx.delete(callSessions).where(eq(callSessions.groupId, groupId));
    await tx.delete(groups).where(eq(groups.id, groupId));
  });
}

export async function updateMembership(groupId: number, userId: number, data: Partial<{ role: "owner" | "admin" | "moderator" | "member"; state: "active" | "pending" | "invited" | "removed" }>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groupMembers).set(data).where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)));
  return getGroupMembership(groupId, userId);
}

export function parsePostImages(value: string | null) {
  if (!value) return [] as string[];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) && parsed.every((item) => typeof item === "string") ? parsed : [];
  } catch { return [] as string[]; }
}

export async function createPost(data: { authorId: number; groupId?: number | null; body: string; imageUrls?: string[]; voiceUrl?: string | null; voiceDurationSeconds?: number | null; linkUrl?: string | null; visibility: "profile" | "community" | "founder" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(posts).values({ ...data, imageUrls: data.imageUrls?.length ? JSON.stringify(data.imageUrls) : null });
  return Number(result[0].insertId);
}

async function enrichCommunityPosts(rows: Array<{ post: typeof posts.$inferSelect; author: { id: number; name: string | null; username: string | null; avatarUrl: string | null; role: string | null } }>, userId: number) {
  const db = await getDb();
  if (!db || rows.length === 0) return [];
  const ids = rows.map((row) => row.post.id);
  const reactions = await db.select({ postId: postReactions.postId, emoji: postReactions.emoji, count: sql<number>`count(${postReactions.id})` })
    .from(postReactions).where(inArray(postReactions.postId, ids)).groupBy(postReactions.postId, postReactions.emoji);
  const mine = await db.select({ postId: postReactions.postId, emoji: postReactions.emoji }).from(postReactions)
    .where(and(inArray(postReactions.postId, ids), eq(postReactions.userId, userId)));
  const mineMap = new Map(mine.map((row) => [row.postId, row.emoji]));
  const summary = new Map<number, Array<{ emoji: string; count: number }>>();
  for (const row of reactions) summary.set(row.postId, [...(summary.get(row.postId) ?? []), { emoji: row.emoji, count: Number(row.count) }]);
  return rows.map(({ post, author }) => ({ post: { ...post, imageUrls: parsePostImages(post.imageUrls), reactionCounts: summary.get(post.id) ?? [], myReaction: mineMap.get(post.id) ?? null }, author }));
}

export async function listFeed(groupId: number | undefined, userId: number) {
  const db = await getDb();
  if (!db) return [];
  const where = groupId ? eq(posts.groupId, groupId) : or(eq(posts.visibility, "community"), eq(posts.visibility, "founder"));
  const rows = await db.select({ post: posts, author: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, role: users.role } })
    .from(posts)
    .innerJoin(users, eq(users.id, posts.authorId))
    .where(where)
    .orderBy(desc(posts.createdAt))
    .limit(100);
  const following = await db.select({ id: userFollows.followingId }).from(userFollows).where(eq(userFollows.followerId, userId));
  const followed = new Set(following.map((row) => row.id));
  rows.sort((a, b) => (Number(followed.has(b.post.authorId)) - Number(followed.has(a.post.authorId))) || (b.post.createdAt.getTime() - a.post.createdAt.getTime()));
  return enrichCommunityPosts(rows, userId);
}

export async function updatePost(postId: number, authorId: number, data: { body?: string; linkUrl?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(posts).set({ ...data, updatedAt: new Date() }).where(and(eq(posts.id, postId), eq(posts.authorId, authorId)));
  return { success: true } as const;
}

export async function deletePost(postId: number, authorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(postReactions).where(eq(postReactions.postId, postId));
  await db.delete(posts).where(and(eq(posts.id, postId), eq(posts.authorId, authorId)));
  return { success: true } as const;
}

export async function togglePostReaction(postId: number, userId: number, emoji: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [existing] = await db.select().from(postReactions).where(and(eq(postReactions.postId, postId), eq(postReactions.userId, userId))).limit(1);
  if (existing?.emoji === emoji) { await db.delete(postReactions).where(eq(postReactions.id, existing.id)); return { active: false, emoji: null }; }
  if (existing) await db.update(postReactions).set({ emoji, createdAt: new Date() }).where(eq(postReactions.id, existing.id));
  else await db.insert(postReactions).values({ postId, userId, emoji });
  return { active: true, emoji };
}

export async function toggleFollow(followerId: number, followingId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (followerId === followingId) throw new Error("নিজেকে অনুসরণ করা যাবে না।");
  const [existing] = await db.select().from(userFollows).where(and(eq(userFollows.followerId, followerId), eq(userFollows.followingId, followingId))).limit(1);
  if (existing) { await db.delete(userFollows).where(eq(userFollows.id, existing.id)); return { following: false }; }
  await db.insert(userFollows).values({ followerId, followingId }); return { following: true };
}

export async function listFollowingIds(followerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ userId: userFollows.followingId }).from(userFollows).where(eq(userFollows.followerId, followerId));
}

export async function setChatActivity(data: { actorId: number; recipientId?: number | null; groupId?: number | null; activity: "typing" | "uploading_image" | "uploading_file" | "recording_voice" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(chatActivities).values({ ...data, recipientId: data.recipientId ?? null, groupId: data.groupId ?? null, updatedAt: new Date() }).onDuplicateKeyUpdate({ set: { activity: data.activity, updatedAt: new Date() } });
  return { success: true } as const;
}

export async function clearChatActivity(data: { actorId: number; recipientId?: number | null; groupId?: number | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(chatActivities).where(and(eq(chatActivities.actorId, data.actorId), data.recipientId ? eq(chatActivities.recipientId, data.recipientId) : isNull(chatActivities.recipientId), data.groupId ? eq(chatActivities.groupId, data.groupId) : isNull(chatActivities.groupId)));
  return { success: true } as const;
}

export async function listChatActivities(data: { actorId: number; recipientId?: number | null; groupId?: number | null }) {
  const db = await getDb();
  if (!db) return [];
  const cutoff = new Date(Date.now() - 12_000);
  return db.select({ activity: chatActivities.activity, updatedAt: chatActivities.updatedAt }).from(chatActivities).where(and(eq(chatActivities.actorId, data.actorId), data.recipientId ? eq(chatActivities.recipientId, data.recipientId) : isNull(chatActivities.recipientId), data.groupId ? eq(chatActivities.groupId, data.groupId) : isNull(chatActivities.groupId), sql`${chatActivities.updatedAt} >= ${cutoff}`)).limit(1);
}

export function parseFounderUpdateImages(value: string | null) {
  if (!value) return [] as string[];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) && parsed.every((item) => typeof item === "string") ? parsed : [];
  } catch {
    return [] as string[];
  }
}

export async function createFounderUpdate(data: {
  authorId: number;
  body: string;
  imageUrls?: string[];
  voiceUrl?: string | null;
  voiceDurationSeconds?: number | null;
  linkUrl?: string | null;
  status?: "draft" | "published";
  scheduledFor?: Date | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const status = data.status ?? "draft";
  const result = await db.insert(founderUpdates).values({
    authorId: data.authorId,
    body: data.body,
    imageUrls: data.imageUrls?.length ? JSON.stringify(data.imageUrls) : null,
    voiceUrl: data.voiceUrl ?? null,
    voiceDurationSeconds: data.voiceDurationSeconds ?? null,
    linkUrl: data.linkUrl ?? null,
    status,
    scheduledFor: data.scheduledFor ?? null,
    publishedAt: status === "published" ? new Date() : null,
  });
  return Number(result[0].insertId);
}

type FounderUpdateReactionSummary = {
  reactionCounts: Array<{ emoji: string; count: number }>;
  myReaction: string | null;
};

async function getFounderUpdateReactionSummaries(updateIds: number[], userId?: number) {
  const summaries = new Map<number, FounderUpdateReactionSummary>();
  if (updateIds.length === 0) return summaries;
  const db = await getDb();
  if (!db) return summaries;
  const counts = await db.select({
    updateId: founderUpdateReactions.updateId,
    emoji: founderUpdateReactions.emoji,
    count: sql<number>`count(${founderUpdateReactions.id})`,
  }).from(founderUpdateReactions)
    .where(inArray(founderUpdateReactions.updateId, updateIds))
    .groupBy(founderUpdateReactions.updateId, founderUpdateReactions.emoji);
  for (const item of counts) {
    const current = summaries.get(item.updateId) ?? { reactionCounts: [], myReaction: null };
    current.reactionCounts.push({ emoji: item.emoji, count: Number(item.count) });
    summaries.set(item.updateId, current);
  }
  if (userId) {
    const mine = await db.select({ updateId: founderUpdateReactions.updateId, emoji: founderUpdateReactions.emoji })
      .from(founderUpdateReactions)
      .where(and(inArray(founderUpdateReactions.updateId, updateIds), eq(founderUpdateReactions.userId, userId)));
    for (const item of mine) {
      const current = summaries.get(item.updateId) ?? { reactionCounts: [], myReaction: null };
      current.myReaction = item.emoji;
      summaries.set(item.updateId, current);
    }
  }
  return summaries;
}

async function getFounderUpdateViewCounts(updateIds: number[]) {
  const viewCounts = new Map<number, number>();
  if (updateIds.length === 0) return viewCounts;
  const db = await getDb();
  if (!db) return viewCounts;
  const rows = await db.select({
    updateId: founderUpdateViewers.updateId,
    count: sql<number>`count(${founderUpdateViewers.id})`,
  }).from(founderUpdateViewers)
    .where(inArray(founderUpdateViewers.updateId, updateIds))
    .groupBy(founderUpdateViewers.updateId);
  for (const row of rows) viewCounts.set(row.updateId, Number(row.count));
  return viewCounts;
}

export async function getUpdateViewCount(updateId: number) {
  const viewCounts = await getFounderUpdateViewCounts([updateId]);
  return viewCounts.get(updateId) ?? 0;
}

export async function listFounderUpdates(includeDrafts = false, userId?: number) {
  const db = await getDb();
  if (!db) return [];
  const where = includeDrafts ? undefined : eq(founderUpdates.status, "published");
  const rows = await db.select({
    update: founderUpdates,
    author: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, role: users.role },
  }).from(founderUpdates)
    .innerJoin(users, eq(users.id, founderUpdates.authorId))
    .where(where)
    .orderBy(desc(founderUpdates.publishedAt), desc(founderUpdates.updatedAt))
    .limit(200);
  const summaries = await getFounderUpdateReactionSummaries(rows.map((row) => row.update.id), userId);
  const viewCounts = await getFounderUpdateViewCounts(rows.map((row) => row.update.id));
  return rows.map(({ update, author }) => {
    const reaction = summaries.get(update.id) ?? { reactionCounts: [], myReaction: null };
    return { update: { ...update, imageUrls: parseFounderUpdateImages(update.imageUrls), ...reaction, viewCount: viewCounts.get(update.id) ?? 0 }, author };
  });
}

export async function getFounderUpdateById(updateId: number, userId?: number) {
  const db = await getDb();
  if (!db) return null;
  const [row] = await db.select({
    update: founderUpdates,
    author: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, role: users.role },
  }).from(founderUpdates)
    .innerJoin(users, eq(users.id, founderUpdates.authorId))
    .where(eq(founderUpdates.id, updateId))
    .limit(1);
  if (!row) return null;
  const summaries = await getFounderUpdateReactionSummaries([updateId], userId);
  const viewCount = await getUpdateViewCount(updateId);
  const reaction = summaries.get(updateId) ?? { reactionCounts: [], myReaction: null };
  return { update: { ...row.update, imageUrls: parseFounderUpdateImages(row.update.imageUrls), ...reaction, viewCount }, author: row.author };
}

export async function updateFounderUpdate(updateId: number, authorId: number, data: {
  body?: string;
  imageUrls?: string[];
  voiceUrl?: string | null;
  voiceDurationSeconds?: number | null;
  linkUrl?: string | null;
  scheduledFor?: Date | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const values: Record<string, unknown> = { updatedAt: new Date() };
  if (data.body !== undefined) values.body = data.body;
  if (data.imageUrls !== undefined) values.imageUrls = data.imageUrls.length ? JSON.stringify(data.imageUrls) : null;
  if (data.voiceUrl !== undefined) values.voiceUrl = data.voiceUrl;
  if (data.voiceDurationSeconds !== undefined) values.voiceDurationSeconds = data.voiceDurationSeconds;
  if (data.linkUrl !== undefined) values.linkUrl = data.linkUrl;
  if (data.scheduledFor !== undefined) values.scheduledFor = data.scheduledFor;
  await db.update(founderUpdates).set(values).where(and(eq(founderUpdates.id, updateId), eq(founderUpdates.authorId, authorId)));
  return getFounderUpdateById(updateId);
}

export async function publishFounderUpdate(updateId: number, authorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = new Date();
  await db.update(founderUpdates).set({ status: "published", publishedAt: now, scheduledFor: null, updatedAt: now })
    .where(and(eq(founderUpdates.id, updateId), eq(founderUpdates.authorId, authorId), eq(founderUpdates.status, "draft")));
  return getFounderUpdateById(updateId);
}

export async function toggleFounderUpdateReaction(updateId: number, userId: number, emoji: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [existing] = await db.select({ id: founderUpdateReactions.id, emoji: founderUpdateReactions.emoji })
    .from(founderUpdateReactions)
    .where(and(eq(founderUpdateReactions.updateId, updateId), eq(founderUpdateReactions.userId, userId)))
    .limit(1);
  if (existing?.emoji === emoji) {
    await db.delete(founderUpdateReactions).where(eq(founderUpdateReactions.id, existing.id));
    return { active: false, emoji: null };
  }
  if (existing) {
    await db.update(founderUpdateReactions).set({ emoji, createdAt: new Date() }).where(eq(founderUpdateReactions.id, existing.id));
  } else {
    await db.insert(founderUpdateReactions).values({ updateId, userId, emoji });
  }
  return { active: true, emoji };
}

/** Records the first time an authenticated user opens a published founder update. */
export async function recordUpdateView(updateId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(founderUpdateViewers).values({ updateId, userId }).onDuplicateKeyUpdate({
    set: { viewedAt: sql`${founderUpdateViewers.viewedAt}` },
  });
  return { success: true } as const;
}

/** Viewer identities are intentionally returned only through a founder-protected route. */
export async function getUpdateViewers(updateId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    userId: founderUpdateViewers.userId,
    name: users.name,
    username: users.username,
    avatarUrl: users.avatarUrl,
    viewedAt: founderUpdateViewers.viewedAt,
  }).from(founderUpdateViewers)
    .innerJoin(users, eq(users.id, founderUpdateViewers.userId))
    .where(eq(founderUpdateViewers.updateId, updateId))
    .orderBy(desc(founderUpdateViewers.viewedAt))
    .limit(200);
}

export async function listFounderUpdateReactors(updateId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    userId: users.id,
    name: users.name,
    username: users.username,
    avatarUrl: users.avatarUrl,
    emoji: founderUpdateReactions.emoji,
    reactedAt: founderUpdateReactions.createdAt,
  }).from(founderUpdateReactions)
    .innerJoin(users, eq(users.id, founderUpdateReactions.userId))
    .where(eq(founderUpdateReactions.updateId, updateId))
    .orderBy(desc(founderUpdateReactions.createdAt))
    .limit(200);
}

export async function deleteFounderUpdate(updateId: number, authorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(founderUpdates).where(and(eq(founderUpdates.id, updateId), eq(founderUpdates.authorId, authorId)));
  return { success: true } as const;
}

export async function getFounderUpdateStats() {
  const db = await getDb();
  if (!db) return { publishedCount: 0, draftCount: 0, lastPublishedAt: null };
  const [published] = await db.select({ count: sql<number>`count(${founderUpdates.id})`, lastPublishedAt: sql<Date | null>`max(${founderUpdates.publishedAt})` })
    .from(founderUpdates).where(eq(founderUpdates.status, "published"));
  const [drafts] = await db.select({ count: sql<number>`count(${founderUpdates.id})` }).from(founderUpdates).where(eq(founderUpdates.status, "draft"));
  return {
    publishedCount: Number(published?.count ?? 0),
    draftCount: Number(drafts?.count ?? 0),
    lastPublishedAt: published?.lastPublishedAt ?? null,
  };
}

export async function isUserBanned(userId: number) {
  const db = await getDb();
  if (!db) return false;
  const [ban] = await db.select({ id: userBans.id }).from(userBans).where(and(eq(userBans.userId, userId), eq(userBans.isActive, true))).limit(1);
  return !!ban;
}

export async function banUser(userId: number, bannedBy: number, reason: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = new Date();
  await db.insert(userBans).values({ userId, bannedBy, reason, isActive: true, bannedAt: now, unbannedAt: null }).onDuplicateKeyUpdate({
    set: { bannedBy, reason, isActive: true, bannedAt: now, unbannedAt: null },
  });
  return { success: true } as const;
}

export async function unbanUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(userBans).set({ isActive: false, unbannedAt: new Date() }).where(and(eq(userBans.userId, userId), eq(userBans.isActive, true)));
  return { success: true } as const;
}

export async function listBannedUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ ban: userBans, user: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, email: users.email, role: users.role } })
    .from(userBans).innerJoin(users, eq(users.id, userBans.userId))
    .where(eq(userBans.isActive, true)).orderBy(desc(userBans.bannedAt)).limit(200);
}

export async function listAdminUsers() {
  const db = await getDb();
  if (!db) return [];
  const now = new Date();
  const rows = await db.select({ id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl, email: users.email, role: users.role, createdAt: users.createdAt, lastSignedIn: users.lastSignedIn, lastActiveAt: userPresence.lastActiveAt, presenceOnline: userPresence.isOnline })
    .from(users).leftJoin(userPresence, eq(userPresence.userId, users.id)).orderBy(desc(users.lastSignedIn)).limit(200);
  return rows.map(({ presenceOnline, ...user }) => ({
    ...user,
    isOnline: !!presenceOnline && isPresenceOnline(user.lastActiveAt, now),
  }));
}

/** Founder dashboard metrics. The block figure is scoped to the viewing founder's personal DM/call block list. */
export async function getAdminUsageStats(founderId: number) {
  const db = await getDb();
  if (!db) return { totalUsers: 0, signedInLast24Hours: 0, onlineNow: 0, bannedCount: 0, blockedByFounderCount: 0, openReportCount: 0 };
  const since = new Date(Date.now() - 24 * 60 * 60 * 1_000);
  const presenceSince = new Date(Date.now() - PRESENCE_TIMEOUT_MS);
  const [[total], [signedIn], [online], [banned], [blocked], [openReports]] = await Promise.all([
    db.select({ count: sql<number>`count(${users.id})` }).from(users),
    db.select({ count: sql<number>`count(${users.id})` }).from(users).where(sql`${users.lastSignedIn} >= ${since}`),
    db.select({ count: sql<number>`count(${userPresence.userId})` }).from(userPresence).where(and(
      eq(userPresence.isOnline, true),
      sql`${userPresence.lastActiveAt} >= ${presenceSince}`,
    )),
    db.select({ count: sql<number>`count(${userBans.id})` }).from(userBans).where(eq(userBans.isActive, true)),
    db.select({ count: sql<number>`count(${userBlocks.id})` }).from(userBlocks).where(eq(userBlocks.blockerId, founderId)),
    db.select({ count: sql<number>`count(${userReports.id})` }).from(userReports).where(eq(userReports.status, "open")),
  ]);
  return {
    totalUsers: Number(total?.count ?? 0),
    signedInLast24Hours: Number(signedIn?.count ?? 0),
    onlineNow: Number(online?.count ?? 0),
    bannedCount: Number(banned?.count ?? 0),
    blockedByFounderCount: Number(blocked?.count ?? 0),
    openReportCount: Number(openReports?.count ?? 0),
  };
}

export async function listBlockedUserIds(blockerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ blockedUserId: userBlocks.blockedUserId }).from(userBlocks).where(eq(userBlocks.blockerId, blockerId)).limit(200);
}

export async function reportUser(reporterId: number, reportedUserId: number, reason: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(userReports).values({ reporterId, reportedUserId, reason });
  return Number(result[0].insertId);
}

export async function listUserReports() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userReports).orderBy(desc(userReports.createdAt)).limit(200);
}

export async function resolveUserReport(reportId: number, reviewerId: number, status: "reviewed" | "resolved") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(userReports).set({ status, reviewedBy: reviewerId, resolvedAt: status === "resolved" ? new Date() : null }).where(eq(userReports.id, reportId));
  return { success: true } as const;
}

export async function blockUser(blockerId: number, blockedUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(userBlocks).values({ blockerId, blockedUserId }).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  return { success: true } as const;
}

export async function unblockUser(blockerId: number, blockedUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(userBlocks).where(and(eq(userBlocks.blockerId, blockerId), eq(userBlocks.blockedUserId, blockedUserId)));
  return { success: true } as const;
}

export async function isDirectMessagingBlocked(senderId: number, recipientId: number) {
  const db = await getDb();
  if (!db) return false;
  const [block] = await db.select({ id: userBlocks.id }).from(userBlocks).where(or(
    and(eq(userBlocks.blockerId, senderId), eq(userBlocks.blockedUserId, recipientId)),
    and(eq(userBlocks.blockerId, recipientId), eq(userBlocks.blockedUserId, senderId)),
  )).limit(1);
  return !!block;
}

export async function createMessage(data: { senderId: number; recipientId?: number | null; groupId?: number | null; body: string; kind: "text" | "image" | "file" | "voice"; attachmentUrl?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (!data.recipientId && !data.groupId) throw new Error("A message needs a recipient or group");
  const result = await db.insert(messages).values({ ...data, recipientId: data.recipientId ?? null, groupId: data.groupId ?? null });
  return Number(result[0].insertId);
}

export async function listDirectMessages(userId: number, peerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ message: messages, sender: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl } })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.senderId))
    .where(or(and(eq(messages.senderId, userId), eq(messages.recipientId, peerId)), and(eq(messages.senderId, peerId), eq(messages.recipientId, userId))))
    .orderBy(desc(messages.createdAt))
    .limit(200);
}

/** Permanently removes both sides of a private conversation after the caller is authenticated. */
export async function clearDirectMessages(userId: number, peerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(messages).where(or(
    and(eq(messages.senderId, userId), eq(messages.recipientId, peerId)),
    and(eq(messages.senderId, peerId), eq(messages.recipientId, userId)),
  ));
  return { success: true } as const;
}

export async function listGroupMessages(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ message: messages, sender: { id: users.id, name: users.name, username: users.username, avatarUrl: users.avatarUrl } })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.senderId))
    .where(eq(messages.groupId, groupId))
    .orderBy(desc(messages.createdAt))
    .limit(200);
}

export async function markDirectMessagesSeen(userId: number, peerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages).set({ status: "seen" }).where(and(eq(messages.senderId, peerId), eq(messages.recipientId, userId), ne(messages.status, "seen")));
  return { success: true } as const;
}

export async function markGroupMessagesSeen(groupId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const unread = await db.select({ id: messages.id }).from(messages).where(and(
    eq(messages.groupId, groupId),
    ne(messages.senderId, userId),
  ));
  if (unread.length > 0) {
    await db.insert(groupMessageReceipts).values(unread.map((message) => ({ messageId: message.id, userId }))).onDuplicateKeyUpdate({
      set: { seenAt: sql`${groupMessageReceipts.seenAt}` },
    });
  }
  return { success: true } as const;
}

export async function listGroupMessageReceiptSummaries(groupId: number, senderId: number) {
  const db = await getDb();
  if (!db) return new Map<number, { seenCount: number; recipientCount: number }>();
  const activeMembers = await db.select({ userId: groupMembers.userId }).from(groupMembers).where(and(
    eq(groupMembers.groupId, groupId),
    eq(groupMembers.state, "active"),
  ));
  const recipientCount = Math.max(0, activeMembers.filter((member) => member.userId !== senderId).length);
  const rows = await db.select({ messageId: groupMessageReceipts.messageId, seenCount: sql<number>`count(${groupMessageReceipts.id})` })
    .from(groupMessageReceipts)
    .innerJoin(messages, eq(messages.id, groupMessageReceipts.messageId))
    .where(and(eq(messages.groupId, groupId), eq(messages.senderId, senderId)))
    .groupBy(groupMessageReceipts.messageId);
  return new Map(rows.map((row) => [row.messageId, { seenCount: Number(row.seenCount), recipientCount }]));
}

/** Only the original sender may alter the body of an online message. */
export async function editMessageForSender(messageId: number, senderId: number, body: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages).set({ body, editedAt: new Date() }).where(and(eq(messages.id, messageId), eq(messages.senderId, senderId)));
  return { success: true } as const;
}

/** Soft deletion keeps the conversation history intact without retaining the original body or attachment. */
export async function deleteMessageForSender(messageId: number, senderId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages).set({ body: "বার্তাটি মুছে ফেলা হয়েছে", attachmentUrl: null, deletedAt: new Date() }).where(and(eq(messages.id, messageId), eq(messages.senderId, senderId)));
  return { success: true } as const;
}

export async function createCallSession(data: { initiatorId: number; recipientId?: number | null; groupId?: number | null; kind: "audio" | "video"; status?: "requested" | "active" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(callSessions).values({ ...data, recipientId: data.recipientId ?? null, groupId: data.groupId ?? null, status: data.status ?? "requested", acceptedAt: data.status === "active" ? new Date() : null });
  return Number(result[0].insertId);
}

export async function listDirectCallSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(callSessions).where(and(or(eq(callSessions.initiatorId, userId), eq(callSessions.recipientId, userId)), isNull(callSessions.groupId))).orderBy(desc(callSessions.createdAt)).limit(50);
}
const removableCallStatuses = ["declined", "missed", "ended"] as const;
export async function deleteDirectCallHistoryEntry(sessionId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(callSessions).where(and(
    eq(callSessions.id, sessionId),
    isNull(callSessions.groupId),
    or(eq(callSessions.initiatorId, userId), eq(callSessions.recipientId, userId)),
    inArray(callSessions.status, removableCallStatuses),
  ));
  return { success: true } as const;
}
export async function clearDirectCallHistory(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(callSessions).where(and(
    isNull(callSessions.groupId),
    or(eq(callSessions.initiatorId, userId), eq(callSessions.recipientId, userId)),
    inArray(callSessions.status, removableCallStatuses),
  ));
  return { success: true } as const;
}
export async function listGroupCallSessions(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(callSessions).where(eq(callSessions.groupId, groupId)).orderBy(desc(callSessions.createdAt)).limit(50);
}

export async function getCallSessionById(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [session] = await db.select().from(callSessions).where(eq(callSessions.id, sessionId)).limit(1);
  return session ?? null;
}

export async function respondToDirectCall(sessionId: number, recipientId: number, status: "active" | "declined") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(callSessions).set({ status, acceptedAt: status === "active" ? new Date() : null }).where(and(eq(callSessions.id, sessionId), eq(callSessions.recipientId, recipientId), eq(callSessions.status, "requested")));
  return { success: true } as const;
}

export async function endCallSession(sessionId: number, actorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(callSessions).set({ status: "ended", endedAt: new Date() }).where(and(
    eq(callSessions.id, sessionId),
    or(eq(callSessions.initiatorId, actorId), eq(callSessions.recipientId, actorId)),
    or(eq(callSessions.status, "requested"), eq(callSessions.status, "active")),
  ));
  return { success: true } as const;
}

/** A live ringing call is intentionally short-lived. On the recipient's next sync, stale requests become missed calls. */
export async function expireUnansweredDirectCallsForRecipient(recipientId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = new Date();
  const ringDeadline = new Date(now.getTime() - 60_000);
  await db.update(callSessions).set({ status: "missed", missedAt: now }).where(and(
    eq(callSessions.recipientId, recipientId),
    eq(callSessions.status, "requested"),
    isNull(callSessions.groupId),
    lt(callSessions.createdAt, ringDeadline),
  ));
}

/** Returns the events a user must be able to discover after regaining a data connection. */
export async function getOfflineInboxSummary(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await expireUnansweredDirectCallsForRecipient(userId);

  const [directMessages, groupMessages, missedCalls] = await Promise.all([
    db.select({
      id: messages.id,
      senderId: users.id,
      senderName: users.name,
      senderUsername: users.username,
      createdAt: messages.createdAt,
    }).from(messages).innerJoin(users, eq(users.id, messages.senderId)).where(and(
      eq(messages.recipientId, userId),
      ne(messages.status, "seen"),
      isNull(messages.deletedAt),
    )).orderBy(desc(messages.createdAt)).limit(20),
    db.select({
      id: messages.id,
      senderId: users.id,
      senderName: users.name,
      senderUsername: users.username,
      groupId: groups.id,
      groupName: groups.name,
      createdAt: messages.createdAt,
    }).from(messages)
      .innerJoin(groupMembers, and(eq(groupMembers.groupId, messages.groupId), eq(groupMembers.userId, userId), eq(groupMembers.state, "active")))
      .innerJoin(groups, eq(groups.id, messages.groupId))
      .innerJoin(users, eq(users.id, messages.senderId))
      .leftJoin(groupMessageReceipts, and(eq(groupMessageReceipts.messageId, messages.id), eq(groupMessageReceipts.userId, userId)))
      .where(and(isNull(groupMessageReceipts.id), ne(messages.senderId, userId), isNull(messages.deletedAt)))
      .orderBy(desc(messages.createdAt)).limit(20),
    db.select({
      id: callSessions.id,
      kind: callSessions.kind,
      createdAt: callSessions.createdAt,
      missedAt: callSessions.missedAt,
      initiatorId: users.id,
      initiatorName: users.name,
      initiatorUsername: users.username,
    }).from(callSessions).innerJoin(users, eq(users.id, callSessions.initiatorId)).where(and(
      eq(callSessions.recipientId, userId),
      eq(callSessions.status, "missed"),
      isNull(callSessions.missedSeenAt),
    )).orderBy(desc(callSessions.missedAt)).limit(20),
  ]);

  return { directMessages, groupMessages, missedCalls };
}

/** Counts unread messages per accessible private or group conversation for the chat list. */
export async function getUnreadChatBadgeCounts(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const unreadCount = sql<number>`count(*)`.mapWith(Number).as("unreadCount");
  const [direct, groupsWithUnread] = await Promise.all([
    db.select({
      userId: users.id,
      name: users.name,
      username: users.username,
      avatarUrl: users.avatarUrl,
      unreadCount,
    }).from(messages).innerJoin(users, eq(users.id, messages.senderId)).where(and(
      eq(messages.recipientId, userId),
      ne(messages.status, "seen"),
      isNull(messages.deletedAt),
    )).groupBy(users.id, users.name, users.username, users.avatarUrl).orderBy(desc(unreadCount)),
    db.select({
      groupId: groups.id,
      name: groups.name,
      handle: groups.handle,
      unreadCount,
    }).from(messages)
      .innerJoin(groupMembers, and(eq(groupMembers.groupId, messages.groupId), eq(groupMembers.userId, userId), eq(groupMembers.state, "active")))
      .innerJoin(groups, eq(groups.id, messages.groupId))
      .leftJoin(groupMessageReceipts, and(eq(groupMessageReceipts.messageId, messages.id), eq(groupMessageReceipts.userId, userId)))
      .where(and(isNull(groupMessageReceipts.id), ne(messages.senderId, userId), isNull(messages.deletedAt)))
      .groupBy(groups.id, groups.name, groups.handle).orderBy(desc(unreadCount)),
  ]);
  return { direct, groups: groupsWithUnread };
}

/** Lists the latest accessible private and group conversations for the home screen. */
export async function getRecentConversations(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [directRows, groupRows] = await Promise.all([
    db.select({
      id: messages.id,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      body: messages.body,
      kind: messages.kind,
      attachmentUrl: messages.attachmentUrl,
      createdAt: messages.createdAt,
    }).from(messages).where(and(
      isNull(messages.groupId),
      isNull(messages.deletedAt),
      or(eq(messages.senderId, userId), eq(messages.recipientId, userId)),
    )).orderBy(desc(messages.createdAt)).limit(200),
    db.select({
      id: messages.id,
      senderId: messages.senderId,
      body: messages.body,
      kind: messages.kind,
      attachmentUrl: messages.attachmentUrl,
      createdAt: messages.createdAt,
      groupId: groups.id,
      groupName: groups.name,
      groupHandle: groups.handle,
    }).from(messages)
      .innerJoin(groupMembers, and(eq(groupMembers.groupId, messages.groupId), eq(groupMembers.userId, userId), eq(groupMembers.state, "active")))
      .innerJoin(groups, eq(groups.id, messages.groupId))
      .where(isNull(messages.deletedAt))
      .orderBy(desc(messages.createdAt)).limit(200),
  ]);

  const latestDirectRows = new Map<number, typeof directRows[number]>();
  for (const row of directRows) {
    const peerId = row.senderId === userId ? row.recipientId : row.senderId;
    if (peerId && !latestDirectRows.has(peerId)) latestDirectRows.set(peerId, row);
  }
  const peerIds = [...latestDirectRows.keys()];
    const peerRows = peerIds.length ? await db.select({
      id: users.id,
      name: users.name,
      username: users.username,
      avatarUrl: users.avatarUrl,
      lastActiveAt: userPresence.lastActiveAt,
    }).from(users).leftJoin(userPresence, eq(userPresence.userId, users.id)).where(inArray(users.id, peerIds)) : [];
  const peersById = new Map(peerRows.map((row) => [row.id, row]));

  const latestGroupRows = new Map<number, typeof groupRows[number]>();
  for (const row of groupRows) {
    if (!latestGroupRows.has(row.groupId)) latestGroupRows.set(row.groupId, row);
  }

  const direct = [...latestDirectRows.entries()].flatMap(([peerId, row]) => {
    const peer = peersById.get(peerId);
    return peer ? [{
      kind: "direct" as const,
      id: peer.id,
      name: peer.name,
      username: peer.username,
      avatarUrl: peer.avatarUrl,
      online: isPresenceOnline(peer.lastActiveAt),
      lastMessage: { body: row.body, kind: row.kind, attachmentUrl: row.attachmentUrl, senderId: row.senderId, createdAt: row.createdAt },
    }] : [];
  });
  const groupsList = [...latestGroupRows.values()].map((row) => ({
    kind: "group" as const,
    id: row.groupId,
    name: row.groupName,
    handle: row.groupHandle,
    lastMessage: { body: row.body, kind: row.kind, attachmentUrl: row.attachmentUrl, senderId: row.senderId, createdAt: row.createdAt },
  }));

  const unreadSummary = await getUnreadChatBadgeCounts(userId);
  const directUnread = new Map(unreadSummary.direct.map((row) => [row.userId, row.unreadCount]));
  const groupUnread = new Map(unreadSummary.groups.map((row) => [row.groupId, row.unreadCount]));
  const directWithUnread = direct.map((row) => ({ ...row, unreadCount: directUnread.get(row.id) ?? 0 }));
  const groupsWithUnread = groupsList.map((row) => ({ ...row, unreadCount: groupUnread.get(row.id) ?? 0 }));

  return [...directWithUnread, ...groupsWithUnread].sort((a, b) => b.lastMessage.createdAt.getTime() - a.lastMessage.createdAt.getTime()).slice(0, 50);
}

export async function markMissedCallsSeen(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(callSessions).set({ missedSeenAt: new Date() }).where(and(
    eq(callSessions.recipientId, userId),
    eq(callSessions.status, "missed"),
    isNull(callSessions.missedSeenAt),
  ));
  return { success: true } as const;
}

/** Lists all retained missed calls for the recipient, including entries already viewed. */
export async function listMissedCallsForRecipient(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select({
    id: callSessions.id,
    kind: callSessions.kind,
    createdAt: callSessions.createdAt,
    missedAt: callSessions.missedAt,
    initiatorId: users.id,
    initiatorName: users.name,
    initiatorUsername: users.username,
  }).from(callSessions).innerJoin(users, eq(users.id, callSessions.initiatorId)).where(and(
    eq(callSessions.recipientId, userId),
    eq(callSessions.status, "missed"),
  )).orderBy(desc(callSessions.missedAt)).limit(100);
}

/** Permanently removes one missed-call record only when it belongs to the signed-in recipient. */
export async function deleteMissedCallForRecipient(callId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [record] = await db.select({ id: callSessions.id }).from(callSessions).where(and(
    eq(callSessions.id, callId),
    eq(callSessions.recipientId, userId),
    eq(callSessions.status, "missed"),
  )).limit(1);
  if (!record) return { success: false } as const;
  await db.delete(callSessions).where(eq(callSessions.id, callId));
  return { success: true } as const;
}

/** Permanently removes only the signed-in recipient's retained missed-call history. */
export async function clearMissedCallHistoryForRecipient(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(callSessions).where(and(
    eq(callSessions.recipientId, userId),
    eq(callSessions.status, "missed"),
  ));
  return { success: true } as const;
}
